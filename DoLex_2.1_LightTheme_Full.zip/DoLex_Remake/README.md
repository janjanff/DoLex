# DoLex 2.1 – Complete Feature Update

Roblox-inspired creative 3D platform with Studio, Marketplace, Friends, Hotbar, and Material tools.

## New in 2.1

1. **Buy Item Frame** – Roblox-style purchase popup for Dlex items and Game Passes (confirmation, ownership check, insufficient balance messages, inventory + hotbar integration).
2. **About DoLex page** – Full description, feature list, online/Wi-Fi connectivity notes, credits.
3. **In-Game Hotbar** – Auto-appears when tools are purchased/picked up. Keyboard 1–9 + touch. Equip / unequip.
4. **Material Panel** – Draggable floating panel. Apply Brick, Pebble, Wood, Metal, Glass, Neon, Concrete textures to selected Parts.
5. **Friends upgrades** – “Is playing [Game]” status, Join button, View profile button (requires internet).
6. **Online / Wi-Fi first** – Designed for real internet connectivity. Offline Studio editing still works; friends status, marketplace sync and multiplayer need online.

## Run (important)

```bash
cd DoLex_Remake
python -m http.server 8080
# open http://localhost:8080
```

**Do not** open via `file://`. Use a local server so modules, Gun.js and assets load correctly over HTTP.

## Demo currency

All Dlex pack and item purchases are **local demo credits only**. No real money is charged.

## Assets

- `Assets/Brick.jpg` and `Assets/Pebble.jpg` – used by the Material Panel.
- Studio Smooth Icons, ClassIcons, character models (Boy.obj, etc.), Dlex coin icons.

## Tech

- Three.js (via CDN import map)
- Gun.js (for future online / multiplayer)
- Vanilla HTML / CSS / JS
- Responsive: portrait for Home, landscape preferred for Studio & gameplay

## Credits

DoLex · Three.js · Studio Smooth Icons · AERØHEAD looped BGM

Version **2.1** – Buy Item Frame · Hotbar · Material Panel · Friends · About · Online focus
