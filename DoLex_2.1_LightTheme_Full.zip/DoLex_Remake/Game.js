import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';

const ASSETS = {
  icon: 'Assets/DoLex.png',
  dolex: 'Assets/DoLex.png',
  profilePic: 'Assets/ProfilePic.png',
  dlexCoin: 'Assets/Dlex_Coin.png',
  dlex: 'Assets/Dlex_Coin.png',
  jump: 'Assets/Jump.png',
  baseplateObj: 'Assets/Baseplate.obj',
  baseplateTex: 'Assets/Baseplate.png',
  boy: 'Assets/R6_Boy.gltf',
  girl: 'Assets/Girl.gltf',
  friends: 'Assets/Friends.png',
  addFriend: 'Assets/AddFriend.png',
  gameSettings: 'Assets/GameSettings.png',
  fullScreen: 'Assets/FullScreen.png',
  home: 'Assets/Home.png',
  group: 'Assets/group.png',
  backpack: 'Assets/Backpack.png',
  voice: 'Assets/Voice.png',
  create: 'Assets/Create.png',
  // Studio tool icons
  toolAdd: 'Studio_Smooth_Icons/plus.png',
  toolSelect: 'Studio_Smooth_Icons/hand_pointer.png',
  toolMove: 'Studio_Smooth_Icons/arrow_pointer.png',
  toolRotate: 'Studio_Smooth_Icons/arrows_rotate.png',
  toolScale: 'Studio_Smooth_Icons/expand.png',
  toolAnchor: 'Assets/ToolAnchor.png',
  toolPart: 'Studio_Smooth_Icons/cube.png',
  toolBall: 'Studio_Smooth_Icons/circle_nodes.svg',
  toolWedge: 'Assets/ToolWedge.png',
  toolPlay: 'Studio_Smooth_Icons/play.png',
  toolPause: 'Studio_Smooth_Icons/pause.png',
  toolDelete: 'Studio_Smooth_Icons/trash.png',
  toolTrash: 'Studio_Smooth_Icons/trash.png',
  toolGroup: 'Studio_Smooth_Icons/layer_group.png',
  toolSelectMulti: 'Studio_Smooth_Icons/crosshairs.png',
  toolTransform: 'Studio_Smooth_Icons/rotate.png',
  toolForward: 'Assets/ToolForward.png',
  toolPlayer: 'Assets/ToolPlayer.png',
  toolShare: 'Studio_Smooth_Icons/share_nodes.png',
  themeHalloween: 'Assets/ThemeHalloween.png',
  themeHalloween2: 'Assets/ThemeHalloween2.png',
  idleAnim: 'Assets/Idle.anim',
};

const SAVE_KEY = 'dolex_save_v5';
const ACCOUNTS_KEY = 'dolex_accounts_v1';
const SESSION_KEY = 'dolex_session_v1';
const ACTIVE_ACCOUNT_KEY = 'dolex_active_account_v2';
const NAME_COLORS = ['#5b9dff', '#ff6b9d', '#50e3a2', '#ffc846', '#c77dff', '#ff8c5a', '#4ecdc4', '#f7a8ff'];

function colorForName(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return NAME_COLORS[h % NAME_COLORS.length];
}

function defaultAccount() {
  return {
    user_id: '', username: '', password: '', email: '', gender: 'boy', birthDate: '',
    avatarColor: '#5b9dff',
    profilePicData: '', // custom uploaded profile picture (data URL)
    profilePicRot: 0,
    profilePicZoom: 1,
    dlex: 0, liked: false, likes: 0, rating: 0, rating_count: 0,
    transactions: [], inventory: [], owned: [], equippedAccessories: [], equippedFace: null,
    friends: [], followers: 0, following: 0, groups_joined: [],
    about: '', game_visits: 0, joined: new Date().toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    settings: {
      sound: true, music: false, theme: 'light', joystick: true, chat: true,
      graphics: 'medium', fov: 60, sensitivity: 1, showNames: true, volume: 0.7,
      musicVol: 0.5, qol: 100, desktopMode: false
    }
  };
}

function loadAccounts() {
  try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '[]'); } catch { return []; }
}
function saveAccounts(list) {
  try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list)); } catch {}
}

function accountStorageKey(uid) {
  return uid ? `dolex_account_data_v2_${uid}` : SAVE_KEY;
}
function getActiveAccountId() {
  try { return localStorage.getItem(ACTIVE_ACCOUNT_KEY) || ''; } catch { return ''; }
}
function setActiveAccountId(uid) {
  try { if (uid) localStorage.setItem(ACTIVE_ACCOUNT_KEY, uid); else localStorage.removeItem(ACTIVE_ACCOUNT_KEY); } catch {}
}
function hydrateAccount(raw) {
  const d = defaultAccount();
  const s = raw && typeof raw === 'object' ? raw : {};
  return { ...d, ...s, settings: { ...d.settings, ...(s.settings || {}) } };
}
function loadAccountById(uid) {
  const d = defaultAccount();
  if (!uid) return d;
  try {
    const raw = localStorage.getItem(accountStorageKey(uid));
    if (raw) return hydrateAccount(JSON.parse(raw));
  } catch {}
  // Recover from the saved account index if the full record is missing.
  try {
    const found = loadAccounts().find(a => a.user_id === uid);
    if (found) return hydrateAccount(found);
  } catch {}
  return d;
}
function loadSave() {
  try {
    const uid = getActiveAccountId();
    if (uid) return loadAccountById(uid);
    const raw = localStorage.getItem(SAVE_KEY);
    return hydrateAccount(JSON.parse(raw || '{}'));
  } catch { return defaultAccount(); }
}
function save(acc) {
  try {
    if (acc.user_id) localStorage.setItem(accountStorageKey(acc.user_id), JSON.stringify(acc));
    localStorage.setItem(SAVE_KEY, JSON.stringify(acc)); // legacy backup
    setActiveAccountId(acc.user_id);
  } catch {}
  // Keep a complete account index entry so accounts remain visible after refresh.
  const list = loadAccounts();
  const idx = list.findIndex(a => a.user_id === acc.user_id);
  const entry = {
    user_id: acc.user_id, username: acc.username, password: acc.password,
    email: acc.email, gender: acc.gender, birthDate: acc.birthDate, dlex: acc.dlex,
    avatarColor: acc.avatarColor, joined: acc.joined
  };
  if (idx >= 0) list[idx] = { ...list[idx], ...entry };
  else if (acc.user_id && acc.password) list.push(entry);
  saveAccounts(list);
}

let account = loadSave();
// Migrate only the current account ID. Do not reset player data.
if (account.user_id) account.user_id = migrateUserId(account.user_id);
let isLoggedIn = false;
try { isLoggedIn = localStorage.getItem(SESSION_KEY) === '1' && !!account.username && !!account.password; } catch {}
account.chatColor = colorForName(account.username || 'Player');

const PACKS = [
  { dlex: 100, usd: 0.99, label: 'Starter' },
  { dlex: 550, usd: 4.99, label: 'Popular', bonus: true },
  { dlex: 1200, usd: 9.99, label: 'Pro' },
  { dlex: 3000, usd: 19.99, label: 'Mega' },
];
const GROUPS_KEY = 'dolex_groups_v1';
function loadGroups() {
  try { return JSON.parse(localStorage.getItem(GROUPS_KEY) || '[]'); } catch { return []; }
}
function saveGroups(list) {
  try { localStorage.setItem(GROUPS_KEY, JSON.stringify(list)); } catch {}
}

function nextUserId() {
  // Sequential numeric IDs like 0000000001
  const KEY = 'dolex_uid_seq';
  let n = 1;
  try { n = parseInt(localStorage.getItem(KEY) || '1', 10) || 1; } catch {}
  const id = String(n).padStart(10, '0');
  try { localStorage.setItem(KEY, String(n + 1)); } catch {}
  return id;
}

function migrateUserId(uid) {
  if (!uid) return nextUserId();
  if (/^\d{10}$/.test(uid)) return uid;
  // Keep legacy non-numeric IDs mapped once
  const mapKey = 'dolex_uid_map';
  let map = {};
  try { map = JSON.parse(localStorage.getItem(mapKey) || '{}'); } catch {}
  if (map[uid]) return map[uid];
  const neu = nextUserId();
  map[uid] = neu;
  try { localStorage.setItem(mapKey, JSON.stringify(map)); } catch {}
  return neu;
}

function addTx(desc, amount) {
  account.transactions = account.transactions || [];
  account.transactions.push({
    time: new Date().toISOString().slice(0, 16).replace('T', ' '),
    desc, amount
  });
  account.dlex = (account.dlex || 0) + amount;
  save(account);
  updateDlexUI();
}

function addDlex(amount, label) {
  amount = Number(amount) || 0;
  account.transactions = account.transactions || [];
  account.transactions.push({
    amount, label: label || (amount >= 0 ? 'Credit' : 'Debit'),
    date: new Date().toLocaleString(), type: amount >= 0 ? 'credit' : 'debit'
  });
  account.dlex = Math.max(0, (account.dlex || 0) + amount);
  try { save(account); } catch(_){}
  updateDlexUI();
}
function updateDlexUI() {
  document.querySelectorAll('.dlex-val').forEach(el => { el.textContent = account.dlex; });
}
function applyTheme(theme) {
  let t = theme || 'light';
  // Halloween theme removed — force to light
  if (t === 'halloween') t = 'light';
  document.body.classList.remove('theme-light', 'theme-dark', 'theme-halloween', 'theme-purewhite');
  if (t === 'purewhite' || t === 'white') {
    document.body.classList.add('theme-purewhite', 'theme-light');
  } else if (t === 'dark') {
    document.body.classList.add('theme-dark');
  } else {
    document.body.classList.add('theme-light');
    t = 'light';
  }
  const bg = document.getElementById('theme-bg-layer');
  if (bg) {
    bg.style.display = 'none';
    bg.style.backgroundImage = 'none';
  }
  if (account && account.settings) account.settings.theme = t;
  if (account && account.user_id) save(account);
  const st = document.getElementById('set-theme');
  if (st) st.value = t;
  const hs = document.getElementById('hs-theme');
  if (hs) hs.value = t;
}

function applyDesktopMode(on) {
  document.body.classList.toggle('desktop-mode', !!on);
  if (account && account.settings) account.settings.desktopMode = !!on;
}

// ---------- AUTH ----------
let authMode = 'signin'; // signin | signup

function showAuthScreen(id) {
  ['auth-landing', 'auth-form', 'auth-accounts'].forEach(x => {
    document.getElementById(x)?.classList.add('hidden');
  });
  document.getElementById(id)?.classList.remove('hidden');
}

function hideAllAuth() {
  ['auth-landing', 'auth-form', 'auth-accounts'].forEach(x => {
    document.getElementById(x)?.classList.add('hidden');
  });
}

function enterLobby() {
  isLoggedIn = true;
  try { localStorage.setItem(SESSION_KEY, '1'); } catch {}
  hideAllAuth();
  document.getElementById('ui-root')?.classList.remove('hidden');
  document.getElementById('loading-screen')?.classList.add('hidden');
  applyTheme(account.settings?.theme || 'light');
  updateDlexUI();
  renderHome();
  document.querySelectorAll('#sidebar .nav-btn[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === 'home'));
  document.querySelectorAll('#bottom-tabs .btab[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === 'home'));
  document.getElementById('content')?.classList.add('has-bottom-tabs');
  const title = document.getElementById('top-bar-title');
  if (title) title.textContent = 'Home';
  if (typeof updateAuthLabels === 'function') updateAuthLabels();
  lockOrientation('portrait');
  try { syncBgMusic(); } catch(_){}
}

function signOut() {
  isLoggedIn = false;
  try { localStorage.removeItem(SESSION_KEY); } catch {}
  document.getElementById('ui-root')?.classList.add('hidden');
  closeDrawer();
  showAuthScreen('auth-landing');
}

function openAuthForm(mode) {
  authMode = mode;
  const title = document.getElementById('auth-form-title');
  const sub = document.getElementById('auth-form-sub');
  const submit = document.getElementById('auth-submit');
  const gender = document.getElementById('auth-gender-wrap');
  const birth = document.getElementById('auth-birth-wrap');
  const err = document.getElementById('auth-error');
  const forgot = document.getElementById('auth-forgot');
  err?.classList.add('hidden');
  forgot?.classList.add('hidden');
  if (mode === 'signup') {
    if (title) title.textContent = 'Sign Up';
    if (sub) sub.textContent = 'Create your DoLex account';
    if (submit) submit.textContent = 'Sign Up';
    gender?.classList.remove('hidden');
    birth?.classList.remove('hidden');
  } else {
    if (title) title.textContent = 'Sign In';
    if (sub) sub.textContent = 'Enter your details to continue';
    if (submit) submit.textContent = 'Sign In';
    gender?.classList.add('hidden');
    birth?.classList.add('hidden');
  }
  document.getElementById('auth-username').value = '';
  document.getElementById('auth-password').value = '';
  document.getElementById('auth-email').value = '';
  document.getElementById('auth-gender').value = '';
  document.getElementById('auth-birth').value = '';
  document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('selected'));
  showAuthScreen('auth-form');
}

function renderSavedAccountCard() {
  const box = document.getElementById('saved-account-card');
  if (!box) return;
  const list = loadAccounts();
  const active = getActiveAccountId();
  const current = list.find(a => a.user_id === active) || (account.username ? account : null);
  if (!current) {
    box.innerHTML = `
      <div class="saved-account-empty">
        <div class="saved-account-title">No account signed in</div>
        <div class="muted">Create an account or open Saved Accounts to continue.</div>
      </div>`;
    return;
  }
  box.innerHTML = `
    <div class="saved-account-card">
      <img src="Assets/DoLex.png" alt="" />
      <div class="saved-account-info">
        <div class="saved-account-title">${escapeHtml(current.username || 'Player')}</div>
        <div class="muted">User ID: ${escapeHtml(current.user_id || '—')}</div>
        <div class="muted">${escapeHtml(current.email || '')}</div>
      </div>
      <div class="saved-account-status">✓ SAVED</div>
    </div>`;
}

function renderAccountsList() {
  renderSavedAccountCard();
  const list = loadAccounts();
  const box = document.getElementById('accounts-list');
  if (!box) return;
  if (!list.length) {
    box.innerHTML = '<p class="muted">No saved accounts yet.</p>';
    return;
  }
  box.innerHTML = list.map(a => `
    <div class="account-row" data-uid="${escapeHtml(a.user_id)}">
      <img src="Assets/DoLex.png" alt="" onerror="this.style.display='none'" />
      <div>
        <div style="font-weight:800">${escapeHtml(a.username)}</div>
        <div class="muted" style="font-size:0.8rem">${escapeHtml(a.email || '')}</div>
      </div>
    </div>
  `).join('');
  box.querySelectorAll('.account-row').forEach(row => {
    row.onclick = () => {
      const uid = row.dataset.uid;
      const found = loadAccounts().find(a => a.user_id === uid);
      if (!found) return;
      // Always load the selected account's own full saved record.
      // Never replace it with the currently active account's data.
      let full = loadAccountById(found.user_id);
      full = { ...full, ...found, settings: { ...defaultAccount().settings, ...(full.settings || {}) } };
      account = full;
      account.chatColor = colorForName(account.username);
      if (account.gender === 'male' || account.gender === 'Male') account.gender = 'boy';
      if (account.gender === 'female' || account.gender === 'Female') account.gender = 'girl';
      if (!account.gender) account.gender = 'boy';
      save(account);
      loadCharacter().then(() => enterLobby());
    };
  });
}

function handleAuthSubmit(e) {
  e.preventDefault();
  const username = (document.getElementById('auth-username').value || '').trim().slice(0, 20);
  const password = (document.getElementById('auth-password').value || '').trim();
  const email = (document.getElementById('auth-email').value || '').trim().toLowerCase();
  const gender = document.getElementById('auth-gender').value || '';
  const birthDate = document.getElementById('auth-birth').value || '';
  const err = document.getElementById('auth-error');
  const forgot = document.getElementById('auth-forgot');
  err.classList.add('hidden');
  forgot.classList.add('hidden');

  if (!username || !password || !email) {
    err.textContent = 'Please fill in username, password, and email.';
    err.classList.remove('hidden');
    return;
  }

  const list = loadAccounts();

  if (authMode === 'signup') {
    if (!gender || (gender !== 'boy' && gender !== 'girl')) {
      err.textContent = 'Please choose Boy or Girl character.';
      err.classList.remove('hidden');
      return;
    }
    if (list.some(a => a.username.toLowerCase() === username.toLowerCase())) {
      err.textContent = 'Username already taken.';
      err.classList.remove('hidden');
      return;
    }
    if (list.some(a => a.email && a.email.toLowerCase() === email)) {
      err.textContent = 'Email already registered.';
      err.classList.remove('hidden');
      return;
    }
    account = defaultAccount();
    account.user_id = nextUserId();
    account.username = username;
    account.password = password;
    account.email = email;
    account.gender = gender;
    account.birthDate = birthDate;
    account.chatColor = colorForName(username);
    save(account);
    // reload character for chosen gender
    loadCharacter().then(() => enterLobby());
    return;
  }

  // Sign in
  const found = list.find(a =>
    a.username.toLowerCase() === username.toLowerCase() &&
    a.password === password &&
    (!a.email || a.email.toLowerCase() === email)
  );
  if (!found) {
    // also try email match with password
    const byEmail = list.find(a => a.email && a.email.toLowerCase() === email && a.password === password && a.username.toLowerCase() === username.toLowerCase());
    if (!byEmail) {
      err.textContent = 'Incorrect username, password, or email.';
      err.classList.remove('hidden');
      forgot.classList.remove('hidden');
      return;
    }
  }
  const match = found || list.find(a => a.username.toLowerCase() === username.toLowerCase());
  // Load the complete saved profile for the account being signed into.
  let full = loadAccountById(match.user_id);
  full = { ...full, ...match, settings: { ...defaultAccount().settings, ...(full.settings || {}) } };
  account = full;
  account.chatColor = colorForName(account.username);
  // normalize legacy gender values
  if (account.gender === 'male' || account.gender === 'Male') account.gender = 'boy';
  if (account.gender === 'female' || account.gender === 'Female') account.gender = 'girl';
  if (!account.gender) account.gender = 'boy';
  save(account);
  loadCharacter().then(() => enterLobby());
}

function initAuthUI() {
  renderSavedAccountCard();
  document.getElementById('btn-goto-signin')?.addEventListener('click', () => openAuthForm('signin'));
  document.getElementById('btn-goto-signup')?.addEventListener('click', () => openAuthForm('signup'));
  document.getElementById('btn-goto-accounts')?.addEventListener('click', () => {
    renderAccountsList();
    showAuthScreen('auth-accounts');
  });
  document.getElementById('auth-back')?.addEventListener('click', () => showAuthScreen('auth-landing'));
  document.getElementById('accounts-back')?.addEventListener('click', () => showAuthScreen('auth-landing'));
  document.getElementById('accounts-new')?.addEventListener('click', () => openAuthForm('signup'));
  document.getElementById('auth-fields')?.addEventListener('submit', handleAuthSubmit);
  document.getElementById('auth-forgot')?.addEventListener('click', () => {
    alert('Password recovery is demo-only. Create a new account or check your saved Accounts list.');
  });
  document.getElementById('drawer-signout')?.addEventListener('click', signOut);
  // Gender / character pick (Boy or Girl)
  document.querySelectorAll('.gender-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      const g = btn.dataset.gender || '';
      const inp = document.getElementById('auth-gender');
      if (inp) inp.value = g;
    });
  });
}

// Extra persistence guards: save the active account whenever the page is hidden/closed.
function persistActiveAccount() {
  if (account && account.user_id && account.username) {
    save(account);
  }
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persistActiveAccount(); });
window.addEventListener('pagehide', persistActiveAccount);
window.addEventListener('beforeunload', persistActiveAccount);

function openDrawer() {
  document.getElementById('side-drawer')?.classList.add('open');
}
function closeDrawer() {
  document.getElementById('side-drawer')?.classList.remove('open');
}
function updateAuthLabels() {
  const label = isLoggedIn ? 'Sign Out' : 'Sign In';
  const a = document.getElementById('sidebar-auth-label');
  const b = document.getElementById('drawer-auth-label');
  if (a) a.textContent = label;
  if (b) b.textContent = label;
  const du = document.getElementById('drawer-username');
  const di = document.getElementById('drawer-userid');
  if (du) du.textContent = account.username || 'Player';
  if (di) di.textContent = account.user_id ? ('ID ' + account.user_id) : 'ID —';
}

function navigateTo(key) {
  stopAvatarPreview();
  try { if (typeof disposeProfileViewport === 'function') disposeProfileViewport(); } catch (_) {}
  closeDrawer();
  document.getElementById('search-panel')?.classList.add('hidden');
  document.getElementById('notif-panel')?.classList.add('hidden');

  if (key === 'auth') {
    if (isLoggedIn) signOut();
    else {
      document.getElementById('ui-root')?.classList.add('hidden');
      showAuthScreen('auth-landing');
    }
    return;
  }
  if (key === 'switch-account') {
    renderAccountsList();
    document.getElementById('ui-root')?.classList.add('hidden');
    showAuthScreen('auth-accounts');
    return;
  }
  if (key === 'marketplace') {
    showScreen('lobby');
    if (typeof renderMarketplace === 'function') renderMarketplace();
    currentNav = 'marketplace';
    document.querySelectorAll('#sidebar .nav-btn[data-nav]').forEach(b => {
      b.classList.toggle('active', b.dataset.nav === 'marketplace');
    });
    return;
  }
  if (key === 'dlex' || key === 'buy-dlex' || key === 'wallet') {
    if (key === 'wallet') {
      showScreen('wallet');
      const wb = document.getElementById('wallet-balance');
      if (wb) wb.textContent = (account.dlex || 0).toLocaleString();
      const list = document.getElementById('wallet-tx-list');
      if (list) {
        const txs = (account.transactions || []).slice().reverse().slice(0, 20);
        list.innerHTML = txs.length ? txs.map(tx => `
          <div class="tx-row" style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06)">
            <div>
              <div style="font-weight:700">${tx.label || tx.type || 'Transaction'}</div>
              <div class="muted" style="font-size:0.8rem">${tx.date || ''}</div>
            </div>
            <div style="font-weight:800;color:${(tx.amount||0)>=0?'#5dfe8a':'#ff6b9d'}">${(tx.amount||0)>=0?'+':''}${tx.amount||0} Dlex</div>
          </div>`).join('') : '<p class="muted">No transactions yet.</p>';
      }
      // wire buttons
      setTimeout(() => {
        document.getElementById('wallet-buy-dlex')?.addEventListener('click', () => navigate('dlex'));
        document.getElementById('wallet-go-market')?.addEventListener('click', () => navigate('marketplace'));
        document.getElementById('wallet-tx')?.addEventListener('click', () => navigate('tx'));
        document.getElementById('wallet-back')?.addEventListener('click', () => navigate('home'));
      }, 0);
      return;
    }
    // Purchase page – clearly demo
    document.getElementById('buy-balance').textContent = account.dlex;
    const packs = document.getElementById('packs');
    packs.innerHTML = `<div class="pack" style="cursor:default;background:rgba(140,80,255,0.12);border:1px solid rgba(140,80,255,0.3)">
      <div class="left"><img src="${ASSETS.dlex}" class="theme-icon" onerror="this.style.display='none'"/><div>
        <div style="font-weight:800">Demo Purchases</div>
        <div class="muted">These are local demo credits only. No real money is charged.</div></div></div>
      <div style="font-weight:800;color:#8c50ff">DEMO</div></div>`;
    PACKS.forEach(p => {
      const d = document.createElement('div');
      d.className = 'pack';
      d.innerHTML = `
        <div class="left"><img src="${ASSETS.dlex}" class="theme-icon" onerror="this.style.display='none'"/><div>
          <div style="font-weight:800">${p.dlex.toLocaleString()} Dlex ${p.bonus ? '<span class="badge">BEST</span>' : ''}</div>
          <div class="muted">${p.label} pack</div></div></div>
        <div style="font-weight:800">$${p.usd.toFixed(2)}</div>`;
      d.onclick = () => {
        if (!confirm(`Add ${p.dlex} Dlex for $${p.usd.toFixed(2)}?\n\nThis is a DEMO transaction. No real payment is processed.`)) return;
        addDlex(p.dlex, `Demo purchase: ${p.label} pack`);
        document.getElementById('buy-balance').textContent = account.dlex;
        alert(`Demo success! +${p.dlex} Dlex added to your balance.`);
      };
      packs.appendChild(d);
    });
    showScreen('buy-dlex');
    return;
  }

  document.querySelectorAll('#sidebar .nav-btn[data-nav]').forEach(b => {
    b.classList.toggle('active', b.dataset.nav === key);
  });
  // Bottom tab bar (icons only)
  document.querySelectorAll('#bottom-tabs .btab[data-nav]').forEach(b => {
    b.classList.toggle('active', b.dataset.nav === key);
  });
  currentNav = key;
  showScreen('lobby');
  if (navRender[key]) navRender[key]();
  const title = document.getElementById('top-bar-title');
  const labels = {
    home: 'Home', create: 'Create', avatar: 'Avatar', inventory: 'Inventory',
    profile: 'Profile', friends: 'Friends', community: 'Community',
    settings: 'Settings', about: 'About', groups: 'Community', marketplace: 'Marketplace'
  };
  if (title) title.textContent = labels[key] || key;
  updateAuthLabels();
  // Keep content clear of bottom tabs
  document.getElementById('content')?.classList.add('has-bottom-tabs');
}

function initDrawer() {
  document.getElementById('hamburger')?.addEventListener('click', () => {
    updateAuthLabels();
    openDrawer();
  });
  document.getElementById('drawer-close')?.addEventListener('click', closeDrawer);
  document.getElementById('drawer-backdrop')?.addEventListener('click', closeDrawer);
  document.querySelectorAll('.drawer-item[data-drawer]').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.drawer));
  });
  // sidebar nav
  document.querySelectorAll('#sidebar .nav-btn[data-nav]').forEach(btn => {
    btn.onclick = () => navigateTo(btn.dataset.nav);
  });
  // bottom tab bar (Home · Friends · Create · Profile · Settings)
  document.querySelectorAll('#bottom-tabs .btab[data-nav]').forEach(btn => {
    btn.onclick = () => navigateTo(btn.dataset.nav);
  });
  // search + notifications
  document.getElementById('btn-search-games')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('notif-panel')?.classList.add('hidden');
    const p = document.getElementById('search-panel');
    p?.classList.toggle('hidden');
    if (p && !p.classList.contains('hidden')) {
      document.getElementById('game-search-input')?.focus();
      runGameSearch('');
    }
  });
  document.getElementById('btn-notifications')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('search-panel')?.classList.add('hidden');
    const p = document.getElementById('notif-panel');
    p?.classList.toggle('hidden');
    renderNotifications();
  });
  document.getElementById('game-search-input')?.addEventListener('input', (e) => {
    runGameSearch(e.target.value || '');
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#search-panel') && !e.target.closest('#btn-search-games')) {
      document.getElementById('search-panel')?.classList.add('hidden');
    }
    if (!e.target.closest('#notif-panel') && !e.target.closest('#btn-notifications')) {
      document.getElementById('notif-panel')?.classList.add('hidden');
    }
  });
  updateAuthLabels();
}

function runGameSearch(q) {
  const box = document.getElementById('game-search-results');
  if (!box) return;
  const query = (q || '').trim().toLowerCase();
  const studioGames = (() => { try { return JSON.parse(localStorage.getItem('dolex_studio_games') || '[]'); } catch { return []; } })();
  const catalog = studioGames
    .filter(g => g && g.public !== false)
    .map((g, i) => ({ title: g.title || 'Untitled', type: 'studio', gi: i, thumb: g.thumbnail || null, category: g.category, public: true }));
  const hits = catalog.filter(g => !query || (g.title || '').toLowerCase().includes(query));
  if (!hits.length) {
    box.innerHTML = '<p class="muted" style="padding:8px">No games found.</p>';
    return;
  }
  box.innerHTML = hits.map(g => `
    <div class="search-result-item" data-type="${g.type}" data-gi="${g.gi != null ? g.gi : ''}">
      <div style="width:40px;height:30px;border-radius:6px;overflow:hidden;background:#120e1c;flex-shrink:0">
        ${g.thumb ? `<img src="${g.thumb}" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML=''"/>` : ''}
      </div>
      <div>
        <div style="font-weight:700;font-size:0.9rem">${escapeHtml(g.title)}</div>
        <div class="muted" style="font-size:0.75rem">${g.type === 'official' ? 'Official' : (g.category || 'Studio')}</div>
      </div>
    </div>`).join('');
  box.querySelectorAll('.search-result-item').forEach(el => {
    el.onclick = () => {
      document.getElementById('search-panel')?.classList.add('hidden');
      if (el.dataset.type === 'official') {
        document.getElementById('detail-stats').textContent = `${account.likes} likes · Rating ${account.rating.toFixed(1)}`;
        document.getElementById('detail-id').textContent = `ID ${account.user_id}`;
        showScreen('detail');
      } else if (el.dataset.gi !== '') {
        openGameDetail(+el.dataset.gi);
      }
    };
  });
}

function renderNotifications() {
  const list = document.getElementById('notif-list');
  const badge = document.getElementById('notif-badge');
  if (!list) return;
  const notes = account.notifications || [
    { t: 'Welcome to DoLex!', d: 'Explore Home, Create, and Avatar.' },
    { t: 'Tip', d: 'Publish games from DLStudio with a custom thumbnail.' }
  ];
  account.notifications = notes;
  list.innerHTML = notes.map(n => `
    <div class="notif-item">
      <div style="font-weight:700">${escapeHtml(n.t)}</div>
      <div class="muted" style="font-size:0.8rem;margin-top:2px">${escapeHtml(n.d)}</div>
    </div>`).join('');
  if (badge) {
    badge.textContent = '0';
    badge.classList.add('hidden');
  }
}

// ---------- ONLINE / MULTIPLAYER (Gun.js) ----------
const GUN_PEERS = [
  'https://gun-manhattan.herokuapp.com/gun',
  'https://peer.wallie.io/gun'
];
let gun = null;
let isOnline = false;
let netConnected = false;
let globalOnlineCount = 0;
let inGameCount = 0;
const remotePlayers = new Map(); // id -> { root, nameTag, data, lastSeen }
const PLAYER_TIMEOUT = 8000;
let lastPresencePush = 0;
let heartbeatTimer = null;

const ERROR_CODES = {
  OFFLINE: 'E1001',
  GUN_FAIL: 'E1002',
  TIMEOUT: 'E1003',
  KICKED: 'E1004',
  UNKNOWN: 'E1999'
};

function setNetBadge(state, label) {
  const el = document.getElementById('net-status');
  if (!el) return;
  el.className = 'net-badge ' + state;
  el.textContent = '● ' + label;
}

function updateOnlineCounts() {
  const g = document.getElementById('home-online-count');
  if (g) g.textContent = String(globalOnlineCount);
  const d = document.getElementById('detail-online-count');
  if (d) d.textContent = String(Math.max(inGameCount, globalOnlineCount > 0 ? inGameCount : 0));
  // In-game online bar removed by design
}

function showOfflineGate(detail) {
  const gate = document.getElementById('offline-gate');
  gate.classList.remove('hidden');
  document.getElementById('offline-detail').textContent = detail || 'Check your connection and try again.';
  setNetBadge('offline', 'Offline');
  isOnline = false;
  netConnected = false;
}

function hideOfflineGate() {
  document.getElementById('offline-gate').classList.add('hidden');
}

function showDisconnect(reason, errorNo) {
  document.getElementById('dc-reason').textContent = reason || 'Connection lost';
  document.getElementById('dc-error').textContent = errorNo || ERROR_CODES.UNKNOWN;
  document.getElementById('disconnect-overlay').classList.remove('hidden');
  if (gameRunning) {
    gameRunning = false;
  }
  setNetBadge('offline', 'Disconnected');
  netConnected = false;
}

function hideDisconnect() {
  document.getElementById('disconnect-overlay').classList.add('hidden');
}

function initGun() {
  if (typeof Gun === 'undefined') {
    showOfflineGate('Multiplayer library failed to load.');
    return false;
  }
  try {
    gun = Gun({ peers: GUN_PEERS, localStorage: false, radisk: false });
    return true;
  } catch (e) {
    console.warn(e);
    showOfflineGate('Could not start multiplayer.');
    return false;
  }
}

function checkBrowserOnline() {
  return navigator.onLine !== false;
}

function connectNetwork() {
  setNetBadge('connecting', 'Connecting…');
  document.getElementById('load-status').textContent = 'Connecting to network…';

  if (!checkBrowserOnline()) {
    showOfflineGate('No internet connection detected.');
    return;
  }

  if (!gun && !initGun()) return;

  // Presence: lobby + in-game
  const presence = gun.get('dolex').get('presence');
  const myId = account.user_id;

  presence.get(myId).put({
    id: myId,
    username: account.username,
    color: account.chatColor,
    inGame: false,
    t: Date.now()
  });

  presence.map().on((data, id) => {
    if (!data || !id) return;
    if (data === null) return;
    // recount
    recountPresence();
  });

  // Chat stream
  gun.get('dolex').get('chat').map().on((msg, id) => {
    if (!msg || !msg.text || !msg.user) return;
    if (msg.t && Date.now() - msg.t > 120000) return; // ignore old
    appendChat(msg.user, msg.text, msg.color || colorForName(msg.user), id, msg.t);
    if (msg.uid && msg.uid !== account.user_id) {
      showChatBubble(msg.uid, msg.text, false);
    }
  });

  // Mark online after short delay if browser is online
  setTimeout(() => {
    if (!checkBrowserOnline()) {
      showOfflineGate('No internet connection detected.');
      return;
    }
    isOnline = true;
    netConnected = true;
    hideOfflineGate();
    setNetBadge('online', 'Online');
    document.getElementById('load-status').textContent = 'Connected';
    startHeartbeat();
    recountPresence();
  }, 1200);
}

function recountPresence() {
  if (!gun) return;
  const now = Date.now();
  let total = 0;
  let playing = 0;
  gun.get('dolex').get('presence').once(obj => {
    if (!obj) { globalOnlineCount = 0; inGameCount = gameRunning ? 1 : 0; updateOnlineCounts(); return; }
    Object.keys(obj).forEach(k => {
      if (k === '_' ) return;
      const p = obj[k];
      if (!p || typeof p !== 'object') return;
      if (p.t && now - p.t < PLAYER_TIMEOUT) {
        total++;
        if (p.inGame) playing++;
      }
    });
    // ensure at least self
    if (isOnline && total < 1) total = 1;
    if (gameRunning && playing < 1) playing = 1;
    globalOnlineCount = total;
    inGameCount = playing;
    updateOnlineCounts();
  });
}

function startHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (!checkBrowserOnline()) {
      if (gameRunning) {
        showDisconnect('Internet connection lost', ERROR_CODES.OFFLINE);
        leaveMultiplayerPresence();
      } else {
        showOfflineGate('Internet connection lost.');
      }
      stopHeartbeat();
      return;
    }
    if (!gun || !netConnected) return;
    gun.get('dolex').get('presence').get(account.user_id).put({
      id: account.user_id,
      username: account.username,
      color: account.chatColor,
      inGame: !!gameRunning,
      t: Date.now()
    });
    recountPresence();
    // prune remote players
    const now = Date.now();
    for (const [id, rp] of remotePlayers) {
      if (now - (rp.lastSeen || 0) > PLAYER_TIMEOUT) {
        removeRemotePlayer(id);
      }
    }
  }, 2500);
}

function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

function leaveMultiplayerPresence() {
  if (!gun) return;
  gun.get('dolex').get('presence').get(account.user_id).put(null);
  gun.get('dolex').get('players').get(account.user_id).put(null);
}

function pushPlayerState() {
  if (!gun || !gameRunning || !netConnected) return;
  const now = Date.now();
  if (now - lastPresencePush < 80) return;
  lastPresencePush = now;
  gun.get('dolex').get('players').get(account.user_id).put({
    id: account.user_id,
    username: account.username,
    color: account.chatColor,
    x: +player.x.toFixed(3),
    y: +player.y.toFixed(3),
    z: +player.z.toFixed(3),
    yaw: +player.yaw.toFixed(3),
    health: player.health,
    t: now
  });
}

function subscribePlayers() {
  if (!gun) return;
  gun.get('dolex').get('players').map().on((data, id) => {
    if (!id || id === account.user_id) return;
    if (!data || data === null) {
      removeRemotePlayer(id);
      return;
    }
    if (data.t && Date.now() - data.t > PLAYER_TIMEOUT) {
      removeRemotePlayer(id);
      return;
    }
    upsertRemotePlayer(id, data);
  });
}

function upsertRemotePlayer(id, data) {
  let rp = remotePlayers.get(id);
  if (!rp) {
    const root = new THREE.Group();
    // simple body clone-ish
    const body = createSimpleAvatar(data.color || '#5b9dff');
    root.add(body);
    const nt = createNameSprite(data.username || 'Player', data.color || '#5b9dff');
    nt.position.y = 2.55;
    root.add(nt);
    scene.add(root);
    rp = { root, body, nameTag: nt, data, lastSeen: Date.now() };
    remotePlayers.set(id, rp);
  }
  rp.data = data;
  rp.lastSeen = Date.now();
  rp.root.position.set(data.x || 0, data.y || 0, data.z || 0);
  rp.root.rotation.y = data.yaw || 0;
  if (rp.nameTag && data.username) {
    // name already set at create; skip redraw for perf
  }
}

function removeRemotePlayer(id) {
  const rp = remotePlayers.get(id);
  if (!rp) return;
  scene.remove(rp.root);
  remotePlayers.delete(id);
}

function clearRemotePlayers() {
  for (const id of [...remotePlayers.keys()]) removeRemotePlayer(id);
}

function createSimpleAvatar(color) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(color) });
  const blue = new THREE.MeshStandardMaterial({ color: 0x2266cc });
  const green = new THREE.MeshStandardMaterial({ color: 0x33aa44 });
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.65, 0.65), mat);
  head.position.y = 1.5;
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.85, 0.4), blue);
  torso.position.y = 0.9;
  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.65, 0.32), green);
  legL.position.set(-0.18, 0.32, 0);
  const legR = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.65, 0.32), green);
  legR.position.set(0.18, 0.32, 0);
  [head, torso, legL, legR].forEach(m => { m.castShadow = true; g.add(m); });
  return g;
}

function createNameSprite(name, color, fat) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const ctx = c.getContext('2d');
  // transparent background — text only
  ctx.clearRect(0, 0, 256, 64);
  ctx.fillStyle = color || '#fff';
  ctx.font = fat
    ? '900 32px Impact, Haettenschweiler, "Arial Black", system-ui, sans-serif'
    : 'bold 26px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = fat ? 4 : 3;
  ctx.strokeStyle = 'rgba(0,0,0,0.75)';
  ctx.strokeText(name, 128, 32);
  ctx.fillText(name, 128, 32);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const spr = new THREE.Sprite(mat);
  spr.scale.set(fat ? 2.6 : 2.2, fat ? 0.65 : 0.55, 1);
  return spr;
}

function createChatBubble(text) {
  const c = document.createElement('canvas');
  c.width = 320; c.height = 80;
  const ctx = c.getContext('2d');
  ctx.fillStyle = 'rgba(20,18,30,0.85)';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(8, 8, 304, 56, 12); else ctx.rect(8, 8, 304, 56);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.font = '20px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const t = text.length > 36 ? text.slice(0, 34) + '…' : text;
  ctx.fillText(t, 160, 36);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const spr = new THREE.Sprite(mat);
  spr.scale.set(2.6, 0.65, 1);
  return spr;
}

const chatBubbles = new Map(); // id -> { sprite, until }
let localChatBubble = null;
let localChatUntil = 0;

function showChatBubble(playerId, text, isLocal) {
  if (isLocal) {
    if (localChatBubble) {
      characterRoot.remove(localChatBubble);
      localChatBubble.material.map?.dispose();
      localChatBubble.material.dispose();
    }
    localChatBubble = createChatBubble(text);
    localChatBubble.position.y = 2.9;
    characterRoot.add(localChatBubble);
    localChatUntil = performance.now() + 5000;
  } else {
    const rp = remotePlayers.get(playerId);
    if (!rp) return;
    if (chatBubbles.has(playerId)) {
      const old = chatBubbles.get(playerId);
      rp.root.remove(old.sprite);
      old.sprite.material.map?.dispose();
      old.sprite.material.dispose();
    }
    const spr = createChatBubble(text);
    spr.position.y = 3.1;
    rp.root.add(spr);
    chatBubbles.set(playerId, { sprite: spr, until: performance.now() + 5000 });
  }
}

function updateChatBubbles(now) {
  if (localChatBubble && now > localChatUntil) {
    characterRoot.remove(localChatBubble);
    localChatBubble.material.map?.dispose();
    localChatBubble.material.dispose();
    localChatBubble = null;
  }
  for (const [id, b] of [...chatBubbles.entries()]) {
    if (now > b.until) {
      const rp = remotePlayers.get(id);
      if (rp) rp.root.remove(b.sprite);
      b.sprite.material.map?.dispose();
      b.sprite.material.dispose();
      chatBubbles.delete(id);
    }
  }
}

// Chat
const seenChat = new Set();
function formatChatTime(ts) {
  const d = ts ? new Date(ts) : new Date();
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (sameDay) return time;
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + time;
}
function showChatNotification(user, text) {
  // Only when player is online (browser online) and not currently in the 3D game view
  const inGame = document.getElementById('game-hud') && !document.getElementById('game-hud').classList.contains('hidden');
  if (!navigator.onLine || inGame) return;
  let n = document.getElementById('chat-notif');
  if (!n) {
    n = document.createElement('div');
    n.id = 'chat-notif';
    n.className = 'chat-notification';
    document.body.appendChild(n);
  }
  n.innerHTML = `<strong style="color:#8c50ff">${escapeHtml(user)}</strong><div style="margin-top:4px;font-size:0.88rem">${escapeHtml(text.slice(0, 80))}</div><div class="chat-time" style="margin-top:6px">${formatChatTime()}</div>`;
  n.style.display = 'block';
  clearTimeout(n._hide);
  n._hide = setTimeout(() => { n.style.display = 'none'; }, 4500);
}
function appendChat(user, text, color, id, ts) {
  const key = id || (user + '|' + text + '|' + (text.length));
  if (seenChat.has(key)) return;
  seenChat.add(key);
  if (seenChat.size > 200) {
    const first = seenChat.values().next().value;
    seenChat.delete(first);
  }
  const box = document.getElementById('chat-messages');
  if (!box) return;
  const line = document.createElement('div');
  line.className = 'chat-line';
  const timeStr = formatChatTime(ts);
  line.innerHTML = `<span class="chat-user" style="color:${color}">${escapeHtml(user)}</span><span class="chat-text">: ${escapeHtml(text)}</span><span class="chat-time">${timeStr}</span>`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
  while (box.children.length > 40) box.removeChild(box.firstChild);
  // Notification when message is from someone else and user is on menu pages
  if (user !== (account.username || '') && document.getElementById('app') && !document.getElementById('app').classList.contains('hidden')) {
    showChatNotification(user, text);
  }
}
function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function sendChat(text) {
  text = (text || '').trim();
  if (!text) return;
  const now = Date.now();
  if (gun && netConnected) {
    const id = account.user_id + '_' + now;
    gun.get('dolex').get('chat').get(id).put({
      user: account.username,
      text,
      color: account.chatColor,
      uid: account.user_id,
      t: now
    });
  }
  // show locally immediately with date
  appendChat(account.username, text, account.chatColor, null, now);
  showChatBubble(account.user_id, text, true);
}

// ---------- Screens ----------
const content = document.getElementById('content');
let currentNav = 'home';

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

function renderHome() {
  stopAvatarPreview();
  const studioGames = (() => { try { return JSON.parse(localStorage.getItem('dolex_studio_games') || '[]'); } catch { return []; } })();
  const publicGames = studioGames.filter(g => g && g.public !== false);
  const friends = account.friends || [];
  // Deterministic online/offline from name hash so it feels stable
  const friendOnline = (name) => {
    let h = 0; for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
    return (Math.abs(h) % 3) !== 0; // ~2/3 online
  };
  const headshotFor = (name) => {
    // Prefer custom profile pic, fall back to DoLex branding
    return ASSETS.profilePic || ASSETS.dolex;
  };
  content.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
      <div>
        <div class="hello">Hello, ${escapeHtml(account.username)}!</div>
        <div class="muted">Friends ${friends.length}</div>
      </div>
      <div class="dlex-chip"><img src="${ASSETS.dlex}" class="theme-icon" alt="" onerror="this.style.display='none'"/><span class="dlex-val">${account.dlex}</span></div>
    </div>
    <div class="home-promo-card">
      <div class="home-promo-icon">📈</div>
      <div>
        <strong>Create &amp; publish</strong>
        <span class="muted">Build in DLStudio, track visits, and share with friends.</span>
      </div>
      <button class="btn btn-purple btn-sm" id="home-go-create">Create</button>
    </div>

    <div class="home-friends-strip">
      <div class="home-friends-strip-head">
        <h3>Friends</h3>
        <a href="#" id="home-friends-viewall" style="color:#8c50ff;font-size:0.82rem;font-weight:700;text-decoration:none">View All ›</a>
      </div>
      <div class="home-friends-scroll" id="home-friends-scroll">
        ${friends.length ? friends.map((f, i) => {
          const online = friendOnline(f);
          return `<div class="friend-template" data-fname="${escapeHtml(f)}" title="${escapeHtml(f)}">
            <img class="friend-template-headshot" src="${headshotFor(f)}" alt="" onerror="this.src='${ASSETS.dolex}'"/>
            <span class="friend-status-dot ${online ? 'online' : 'offline'}" title="${online ? 'Online' : 'Offline'}"></span>
            <div class="friend-template-name">${escapeHtml(f)}</div>
          </div>`;
        }).join('') : `<div class="muted" style="padding:12px 4px">No friends yet. Open Friends to add some!</div>`}
      </div>
    </div>

    <div class="online-banner" style="margin-top:8px">
      <span class="pulse-dot"></span>
      <span id="home-online-count">${globalOnlineCount}</span> players online on DoLex
    </div>

    <div class="game-section">
      <div class="game-section-title">Public Games <span class="badge-soft">Everyone</span></div>
      <div class="games-row">
        ${publicGames.length ? publicGames.map((g, i) => `
          <div class="game-card-sm studio-rec" data-gi="${i}">
            <div class="thumb">${g.thumbnail
              ? `<img src="${g.thumbnail}" alt="" />`
              : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#2a1f4a,#1a1628);color:#8c50ff;font-weight:800;font-size:1.4rem">${escapeHtml((g.title||'G')[0])}</div>`
            }</div>
            <div class="body"><h4>${escapeHtml(g.title || 'Untitled')}</h4><div class="stats">🌐 Public · ${escapeHtml(g.category || 'Game')} · ${g.serverSize || 10} max</div></div>
          </div>`).join('') : '<div class="muted" style="padding:18px 4px">No public games yet. Create a game in Studio and publish it to make it appear here.</div>'}
      </div>
    </div>
  `;
  document.querySelectorAll('.studio-rec').forEach(card => {
    card.onclick = () => openGameDetail(+card.dataset.gi);
  });
  document.getElementById('home-friends-viewall')?.addEventListener('click', (e) => {
    e.preventDefault();
    navigateTo('friends');
  });
  document.getElementById('home-go-create')?.addEventListener('click', () => navigateTo('create'));
  document.querySelectorAll('.friend-template').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelector('[data-nav="friends"]')?.click();
    });
  });
}

/* ===== Circular 3D profile character viewport ===== */
let profileViewport = null;

function disposeProfileViewport() {
  if (!profileViewport) return;
  try {
    if (profileViewport._raf) cancelAnimationFrame(profileViewport._raf);
    if (profileViewport.renderer) {
      profileViewport.renderer.dispose();
      const el = profileViewport.renderer.domElement;
      if (el && el.parentNode) el.parentNode.removeChild(el);
    }
    if (profileViewport.scene) {
      profileViewport.scene.traverse(o => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          if (Array.isArray(o.material)) o.material.forEach(m => m.dispose && m.dispose());
          else if (o.material.dispose) o.material.dispose();
        }
      });
    }
  } catch (_) {}
  profileViewport = null;
}

function mountProfile3DViewport(container) {
  disposeProfileViewport();
  if (!container) return;
  container.innerHTML = '';
  const holder = document.createElement('div');
  holder.className = 'profile-3d-viewport';
  holder.id = 'profile-3d-view';
  container.appendChild(holder);

  const size = Math.max(96, Math.min(container.clientWidth || 112, 160));
  try {
    const pScene = new THREE.Scene();
    pScene.background = null;
    const pCam = new THREE.PerspectiveCamera(32, 1, 0.05, 50);
    const pRen = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    pRen.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    pRen.setSize(size, size, false);
    pRen.setClearColor(0x000000, 0);
    holder.appendChild(pRen.domElement);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x444466, 1.05);
    pScene.add(hemi);
    const key = new THREE.DirectionalLight(0xffffff, 0.85);
    key.position.set(2.5, 4, 3);
    pScene.add(key);
    const fill = new THREE.DirectionalLight(0xa0b0ff, 0.35);
    fill.position.set(-2, 1.5, -1);
    pScene.add(fill);

    let model = null;
    if (character) {
      model = character.clone(true);
      model.traverse(c => {
        if (c.isMesh && c.material) {
          c.material = Array.isArray(c.material)
            ? c.material.map(m => (m.clone ? m.clone() : m))
            : (c.material.clone ? c.material.clone() : c.material);
        }
      });
    } else {
      model = createSimpleAvatar(account.avatarColor || account.chatColor || '#5b9dff');
    }
    pScene.add(model);

    // Head-focused camera (profile headshot framing)
    applyEquippedAccessoriesToModel(model);
    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const bsize = box.getSize(new THREE.Vector3());
    model.position.sub(center); // center model at origin
    // Aim at upper body / head (top of bounding box)
    const headY = bsize.y * 0.32;
    const headLook = new THREE.Vector3(0, headY, 0);
    const dist = Math.max(bsize.y * 1.05, bsize.x * 2.2, 1.1);
    pCam.fov = 28;
    pCam.updateProjectionMatrix();
    pCam.position.set(0, headY + bsize.y * 0.02, dist);
    pCam.lookAt(headLook);

    // Static profile character (no idle rotation) — slight front angle
    if (model) model.rotation.y = 0.12;
    profileViewport = { scene: pScene, camera: pCam, renderer: pRen, model, _raf: 0, _t0: performance.now() };
    const tick = () => {
      if (!profileViewport) return;
      try { profileViewport.renderer.render(profileViewport.scene, profileViewport.camera); } catch (_) {}
      profileViewport._raf = requestAnimationFrame(tick);
    };
    tick();
  } catch (err) {
    console.warn('Profile 3D viewport fallback:', err);
    holder.innerHTML = '<div class="profile-3d-fallback">3D</div>';
  }
}

function renderProfile() {
  disposeProfileViewport();
  const friendsCount = (account.friends||[]).length;
  const followers = account.followers || 0;
  const following = account.following || 0;
  const picSrc = account.profilePicData || ASSETS.profilePic || ASSETS.dolex;
  const rot = account.profilePicRot || 0;
  const zoom = account.profilePicZoom || 1;
  const use3D = !account.profilePicData;
  content.innerHTML = `
    <div class="profile-roblox">
      <div class="profile-hero">
        <div class="profile-avatar-wrap" id="profile-pic-frame">
          ${use3D
            ? '<div class="profile-3d-viewport" id="profile-3d-host"></div>'
            : `<img class="profile-avatar-img" id="profile-pic-img" src="${picSrc}" alt="Avatar"
            style="transform: rotate(${rot}deg) scale(${zoom}); transform-origin: center center;"
            onerror="this.src='${ASSETS.dolex}'"/>`}
          <span class="friend-status-dot online" title="Online"></span>
        </div>
        <div class="profile-info">
          <div class="hello" style="margin-bottom:2px">${escapeHtml(account.username || 'Player')}</div>
          <div class="muted">@${escapeHtml((account.username || 'player').toLowerCase())}</div>
          <div class="profile-stats">
            <span><strong>${friendsCount}</strong> Friends</span>
            <span><strong>${followers}</strong> Followers</span>
            <span><strong>${following}</strong> Following</span>
          </div>
          <div class="dlex-chip" style="margin-top:10px"><img src="${ASSETS.dlex}" class="theme-icon" onerror="this.style.display='none'"/><span class="dlex-val">${account.dlex}</span></div>
        </div>
      </div>
      <div class="profile-actions">
        <button class="btn btn-purple" id="profile-goto-avatar">Edit appearance</button>
        <button class="btn btn-dark" id="profile-edit">Edit profile</button>
      </div>
      <div class="profile-pic-editor" style="background:#201a32;border-radius:12px;padding:14px;margin-top:16px">
        <div style="font-weight:700;margin-bottom:10px">Customize Profile Picture</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
          <button class="btn btn-dark" id="pp-rotate" style="padding:8px 12px">Rotate</button>
          <button class="btn btn-dark" id="pp-zoom-in" style="padding:8px 12px">Zoom In</button>
          <button class="btn btn-dark" id="pp-zoom-out" style="padding:8px 12px">Zoom Out</button>
          <button class="btn btn-dark" id="pp-reset" style="padding:8px 12px">Reset</button>
        </div>
        <label class="btn btn-outline" style="display:inline-block;cursor:pointer;padding:8px 14px">
          Upload Photo
          <input type="file" id="pp-upload" accept="image/*" style="display:none"/>
        </label>
        <p class="muted" style="margin-top:8px;font-size:0.8rem">Rotate · Zoom in/out · Upload a new picture</p>
      </div>
      <div style="background:#201a32;border-radius:12px;padding:14px;margin-top:16px">
        <div style="font-weight:700;margin-bottom:8px">About</div>
        <textarea id="profile-about" rows="3" maxlength="200" style="width:100%;background:#120e1c;border:1px solid #3a3450;color:#f0eef8;border-radius:10px;padding:10px;font-family:inherit;font-weight:600;resize:vertical">${escapeHtml(account.about || '')}</textarea>
        <button class="btn btn-dark" id="profile-save-about" style="margin-top:8px">Save About</button>
      </div>
      <div class="muted" style="margin-top:14px">Game visits: ${account.game_visits || 0} · Joined: ${escapeHtml(account.joined || '—')}</div>
      <div class="muted" style="margin-top:6px">Chat color: <span style="color:${account.chatColor}">■ ${account.chatColor}</span></div>
      <div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-outline" id="profile-goto-settings">Settings</button>
      </div>
    </div>
  `;
  // Mount circular 3D character viewport when no custom photo is set
  if (use3D) {
    requestAnimationFrame(() => {
      const host = document.getElementById('profile-3d-host') || document.getElementById('profile-pic-frame');
      mountProfile3DViewport(host);
    });
  }
  const img = document.getElementById('profile-pic-img');
  const applyTransform = () => {
    if (!img) return;
    img.style.transform = `rotate(${account.profilePicRot || 0}deg) scale(${account.profilePicZoom || 1})`;
  };
  document.getElementById('pp-rotate')?.addEventListener('click', () => {
    account.profilePicRot = ((account.profilePicRot || 0) + 90) % 360;
    applyTransform();
    save(account);
  });
  document.getElementById('pp-zoom-in')?.addEventListener('click', () => {
    account.profilePicZoom = Math.min(2.5, (account.profilePicZoom || 1) + 0.15);
    applyTransform();
    save(account);
  });
  document.getElementById('pp-zoom-out')?.addEventListener('click', () => {
    account.profilePicZoom = Math.max(0.5, (account.profilePicZoom || 1) - 0.15);
    applyTransform();
    save(account);
  });
  document.getElementById('pp-reset')?.addEventListener('click', () => {
    account.profilePicRot = 0;
    account.profilePicZoom = 1;
    account.profilePicData = '';
    applyTransform();
    save(account);
    renderProfile();
  });
  document.getElementById('pp-upload')?.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      disposeProfileViewport();
      account.profilePicData = reader.result;
      account.profilePicRot = 0;
      account.profilePicZoom = 1;
      save(account);
      renderProfile();
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('profile-save-about')?.addEventListener('click', () => {
    account.about = (document.getElementById('profile-about')?.value || '').slice(0, 200);
    save(account);
    alert('Profile saved');
  });
  document.getElementById('profile-goto-avatar')?.addEventListener('click', () => navigateTo('avatar'));
  document.getElementById('profile-edit')?.addEventListener('click', () => navigateTo('settings'));
  document.getElementById('profile-goto-settings')?.addEventListener('click', () => navigateTo('settings'));
}

function renderCommunity() {
  const groups = loadGroups();
  content.innerHTML = `
    <div class="hello">Communities</div>
    <p class="muted" style="margin:8px 0 16px">Create or join groups · Roblox-style communities</p>
    <button class="btn btn-purple" id="btn-create-group" style="width:100%;padding:14px;margin-bottom:16px">+ Create Group</button>
    <div id="create-group-form" class="settings-group" style="display:none;margin-bottom:16px">
      <div class="settings-row" style="flex-direction:column;align-items:stretch;gap:8px">
        <label class="auth-field" style="margin:0"><span>Group Name</span>
          <input type="text" id="cg-name" maxlength="40" placeholder="My Community" />
        </label>
        <label class="auth-field" style="margin:0"><span>Description</span>
          <input type="text" id="cg-desc" maxlength="120" placeholder="What is this group about?" />
        </label>
        <label class="auth-field" style="margin:0"><span>Icon (emoji or letter)</span>
          <input type="text" id="cg-icon" maxlength="4" placeholder="G" />
        </label>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-purple" id="cg-submit" style="fdlex:1">Create</button>
          <button class="btn btn-dark" id="cg-cancel" style="fdlex:1">Cancel</button>
        </div>
      </div>
    </div>
    <div class="section-title">Groups</div>
    <div id="community-groups">${
      groups.length ? '' : '<p class="muted">No groups yet. Create the first one!</p>'
    }</div>
  `;
  document.getElementById('btn-create-group').onclick = () => {
    const f = document.getElementById('create-group-form');
    f.style.display = f.style.display === 'none' ? 'block' : 'none';
  };
  document.getElementById('cg-cancel').onclick = () => {
    document.getElementById('create-group-form').style.display = 'none';
  };
  document.getElementById('cg-submit').onclick = () => {
    const name = (document.getElementById('cg-name').value || '').trim();
    const desc = (document.getElementById('cg-desc').value || '').trim();
    const icon = (document.getElementById('cg-icon').value || 'G').trim() || 'G';
    if (!name) { alert('Group name required'); return; }
    const list = loadGroups();
    if (list.some(g => g.name.toLowerCase() === name.toLowerCase())) {
      alert('A group with that name already exists'); return;
    }
    const g = {
      id: 'g' + Date.now().toString(36),
      name, desc, icon,
      owner: account.username || 'Player',
      ownerId: account.user_id,
      members: [account.user_id],
      memberNames: [account.username || 'Player'],
      created: Date.now(),
      labels: ['Public', 'Social']
    };
    list.unshift(g);
    saveGroups(list);
    account.groups_joined = account.groups_joined || [];
    if (!account.groups_joined.includes(g.id)) account.groups_joined.push(g.id);
    save(account);
    renderCommunity();
  };
  const box = document.getElementById('community-groups');
  groups.forEach(g => {
    const joined = (account.groups_joined || []).includes(g.id) || (g.members || []).includes(account.user_id);
    const count = (g.members || []).length;
    const labels = (g.labels || ['Public']).map(l => `<span class="group-label">${escapeHtml(l)}</span>`).join('');
    const card = document.createElement('div');
    card.className = 'group-card';
    card.innerHTML = `
      <div class="group-icon">${escapeHtml(g.icon || '👥')}</div>
      <div class="group-body">
        <div class="group-name">${escapeHtml(g.name)}</div>
        <div class="muted" style="font-size:0.82rem;margin:2px 0">${escapeHtml(g.desc || 'No description')}</div>
        <div class="group-meta">
          <span>${count} member${count === 1 ? '' : 's'}</span>
          <span>· Owner ${escapeHtml(g.owner || '—')}</span>
        </div>
        <div class="group-labels">${labels}</div>
      </div>
      <button class="btn ${joined ? 'btn-outline' : 'btn-purple'} group-join-btn" style="padding:8px 14px;white-space:nowrap">${joined ? 'Joined' : 'Join Group'}</button>`;
    card.querySelector('.group-join-btn').onclick = () => {
      const list = loadGroups();
      const idx = list.findIndex(x => x.id === g.id);
      if (idx < 0) return;
      account.groups_joined = account.groups_joined || [];
      list[idx].members = list[idx].members || [];
      list[idx].memberNames = list[idx].memberNames || [];
      if (joined) {
        list[idx].members = list[idx].members.filter(m => m !== account.user_id);
        list[idx].memberNames = list[idx].memberNames.filter(n => n !== account.username);
        account.groups_joined = account.groups_joined.filter(x => x !== g.id);
      } else {
        if (!list[idx].members.includes(account.user_id)) list[idx].members.push(account.user_id);
        if (account.username && !list[idx].memberNames.includes(account.username)) list[idx].memberNames.push(account.username);
        if (!account.groups_joined.includes(g.id)) account.groups_joined.push(g.id);
      }
      saveGroups(list);
      save(account);
      renderCommunity();
    };
    box.appendChild(card);
  });
}

function renderAbout() {
  content.innerHTML = `
    <div class="about-page" style="padding:8px 4px 32px;max-width:560px;margin:0 auto">
      <div style="text-align:center;margin-bottom:18px">
        <img src="Assets/DoLex.png" alt="DoLex" style="width:96px;height:96px;border-radius:22px;box-shadow:0 8px 28px rgba(140,80,255,0.35)" onerror="this.style.display='none'"/>
        <h1 style="margin:14px 0 4px;font-size:1.85rem;font-weight:800;letter-spacing:-0.5px">About DoLex</h1>
        <p class="muted" style="margin:0">Creative 3D Platform · Studio · Marketplace</p>
      </div>

      <div class="about-card" style="background:#1e1830;border:1px solid rgba(140,80,255,0.25);border-radius:16px;padding:18px;margin-bottom:14px">
        <div style="font-weight:800;font-size:1.05rem;margin-bottom:8px;color:#e8e0ff">What is DoLex?</div>
        <p style="margin:0;line-height:1.55;color:#c8c0d8;font-size:0.95rem">
          DoLex is a Roblox-inspired creative platform where you play 3D experiences, customize avatars,
          build games inside <strong>DLStudio</strong>, earn and spend <strong>Dlex</strong> currency,
          and share creations with friends. It is designed to work with real internet connectivity
          (online mode) while still supporting local offline play over Wi-Fi.
        </p>
      </div>

      <div class="about-card" style="background:#1e1830;border:1px solid rgba(140,80,255,0.25);border-radius:16px;padding:18px;margin-bottom:14px">
        <div style="font-weight:800;font-size:1.05rem;margin-bottom:10px;color:#e8e0ff">Key Features</div>
        <ul style="margin:0;padding-left:18px;line-height:1.7;color:#c8c0d8;font-size:0.93rem">
          <li><strong>DLStudio</strong> – full desktop-style 3D editor (works on mobile too)</li>
          <li><strong>Dlex Marketplace</strong> – buy items, accessories &amp; Game Passes</li>
          <li><strong>Hotbar &amp; Tools</strong> – automatic pickup and equip system</li>
          <li><strong>Friends</strong> – see who is online / playing and join them</li>
          <li><strong>Script Editor</strong> – write and run scripts like in Roblox Studio</li>
          <li><strong>Material Panel</strong> – apply textures (Brick, Pebble, etc.) to Parts</li>
          <li><strong>Avatar system</strong> – faces, accessories, body customization</li>
        </ul>
      </div>

      <div class="about-card" style="background:#1e1830;border:1px solid rgba(140,80,255,0.25);border-radius:16px;padding:18px;margin-bottom:14px">
        <div style="font-weight:800;font-size:1.05rem;margin-bottom:8px;color:#e8e0ff">Online &amp; Connectivity</div>
        <p style="margin:0;line-height:1.55;color:#c8c0d8;font-size:0.95rem">
          DoLex is built for <strong>real internet / Wi-Fi online</strong> use. When connected, friends status,
          marketplace, and future multiplayer features stay live. Offline mode still works for single-player
          Studio editing and local saves. Always prefer a stable Wi-Fi or mobile data connection for the full experience.
        </p>
      </div>

      <div class="about-card" style="background:#1e1830;border:1px solid rgba(140,80,255,0.25);border-radius:16px;padding:18px;margin-bottom:14px">
        <div style="font-weight:800;font-size:1.05rem;margin-bottom:8px;color:#e8e0ff">Credits</div>
        <p style="margin:0;line-height:1.55;color:#c8c0d8;font-size:0.93rem">
          DoLex · Three.js · Studio Smooth Icons · AERØHEAD background music<br/>
          Version <strong>2.1</strong> – Complete Feature Update (Buy Item Frame, Hotbar, Material Panel, Friends, Studio)
        </p>
      </div>

      <p class="muted" style="text-align:center;font-size:0.82rem;margin-top:20px">
        © DoLex Platform · Demo Dlex purchases are local only · No real money is charged
      </p>
    </div>
  `;
}

function renderFriends() {
  const list = account.friends || [];
  const DEMO_GAMES = ['Demo Obby', 'Parkour World', 'DoLex Plaza', 'Speed Run', 'Build Battle', 'Tycoon'];
  const friendStatus = (name) => {
    let h = 0; for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
    const online = (Math.abs(h) % 3) !== 0;
    const playing = online && (Math.abs(h) % 5) < 3;
    const game = playing ? DEMO_GAMES[Math.abs(h) % DEMO_GAMES.length] : null;
    return { online, playing, game };
  };
  content.innerHTML = `
    <div class="hello"><img src="${ASSETS.friends || 'Assets/AddFriend.png'}" class="theme-icon" alt="" style="width:28px;height:28px;vertical-align:middle;margin-right:8px;border-radius:6px" onerror="this.style.display='none'"/> Friends</div>
    <button class="add-friend-btn" id="btn-add-friend">
      <img src="${ASSETS.addFriend || 'Assets/AddFriend.png'}" alt="" onerror="this.style.display='none'"/> Add Friend
    </button>
    <div class="muted" style="margin:8px 0 12px">Friends · Followers · Following · Requests · Online status requires internet</div>
    <div class="home-friends-scroll" style="margin-bottom:16px">
      ${list.length ? list.map((f) => {
        const st = friendStatus(f);
        return `<div class="friend-template" title="${escapeHtml(f)}">
          <img class="friend-template-headshot" src="${ASSETS.dolex || 'Assets/DoLex.png'}" alt="" onerror="this.style.display='none'"/>
          <span class="friend-status-dot ${st.online ? 'online' : 'offline'}"></span>
          <div class="friend-template-name">${escapeHtml(f)}</div>
        </div>`;
      }).join('') : ''}
    </div>
    <div id="friends-list">
      ${list.length ? list.map((f, i) => {
        const st = friendStatus(f);
        const statusText = st.playing
          ? `<span style="color:#7ee787">Playing ${escapeHtml(st.game)}</span>`
          : (st.online ? '<span style="color:#7ee787">Online</span>' : '<span class="muted">Offline</span>');
        return `
        <div class="friend-row" data-idx="${i}" style="align-items:flex-start">
          <div style="position:relative;flex-shrink:0">
            <img class="friend-avatar" src="${ASSETS.dolex || 'Assets/DoLex.png'}" alt="" onerror="this.style.display='none'"/>
            <span class="friend-status-dot ${st.online ? 'online' : 'offline'}" style="right:0;top:auto;bottom:0"></span>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700">${escapeHtml(f)}</div>
            <div style="font-size:0.82rem;margin-top:2px">${statusText}</div>
            ${st.playing ? `
              <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
                <div style="width:48px;height:32px;border-radius:6px;background:linear-gradient(135deg,#3d2a6e,#8c50ff);display:flex;align-items:center;justify-content:center;font-size:0.7rem;color:#fff;font-weight:700">🎮</div>
                <button class="btn btn-purple" style="padding:4px 12px;font-size:0.78rem;border-radius:8px" data-join="${escapeHtml(f)}" data-game="${escapeHtml(st.game)}">Join</button>
                <button class="btn btn-dark" style="padding:4px 10px;font-size:0.78rem;border-radius:8px" data-profile="${escapeHtml(f)}">View profile</button>
              </div>` : `
              <div style="margin-top:6px">
                <button class="btn btn-dark" style="padding:4px 10px;font-size:0.78rem;border-radius:8px" data-profile="${escapeHtml(f)}">View profile</button>
              </div>`}
          </div>
          <div class="friend-actions">
            <button class="friend-dots" data-idx="${i}" aria-label="More">•••</button>
            <div class="friend-menu" id="fmenu-${i}">
              <button data-act="friend" data-idx="${i}">Friend</button>
              <button data-act="follow" data-idx="${i}">Follow</button>
              <button data-act="details" data-idx="${i}">Details</button>
            </div>
          </div>
        </div>`;
      }).join('') : '<p class="muted">No friends yet. Add some!</p>'}
    </div>
  `;
  document.getElementById('btn-add-friend').onclick = () => {
    const name = prompt('Enter friend username:');
    if (name && name.trim()) {
      account.friends = account.friends || [];
      if (!account.friends.includes(name.trim())) {
        account.friends.push(name.trim());
        save(account);
        renderFriends();
      }
    }
  };
  content.querySelectorAll('[data-join]').forEach(btn => {
    btn.onclick = () => {
      const name = btn.dataset.join;
      const game = btn.dataset.game;
      alert(`Joining ${name} in "${game}"…\n\n(Online multiplayer requires an active internet / Wi-Fi connection.)`);
    };
  });
  content.querySelectorAll('[data-profile]').forEach(btn => {
    btn.onclick = () => {
      const name = btn.dataset.profile;
      alert(`Profile: ${name}\n\nView full profile, badges, and creations.\n(Requires online connection for live data.)`);
    };
  });
  content.querySelectorAll('.friend-dots').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const idx = btn.dataset.idx;
      const menu = document.getElementById('fmenu-' + idx);
      document.querySelectorAll('.friend-menu').forEach(m => { if (m !== menu) m.classList.remove('open'); });
      menu.classList.toggle('open');
    };
  });
  content.querySelectorAll('.friend-menu button').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const act = btn.dataset.act;
      const idx = +btn.dataset.idx;
      const name = account.friends[idx];
      if (act === 'details') alert(`User: ${name}\nStatus: Online\nFriends since: recently`);
      else if (act === 'follow') alert(`Now following ${name}`);
      else if (act === 'friend') alert(`${name} is already your friend`);
      document.querySelectorAll('.friend-menu').forEach(m => m.classList.remove('open'));
    };
  });
  document.addEventListener('click', () => {
    document.querySelectorAll('.friend-menu').forEach(m => m.classList.remove('open'));
  }, { once: true });
}

function renderInventory() {
  const inv = account.inventory || [];
  content.innerHTML = `
    <div class="hello">Inventory</div>
    <div class="muted">${inv.length} item(s)</div>
    <div class="grid" style="margin-top:16px">${
      inv.length
        ? inv.map(n => `<div class="item-card"><div>${escapeHtml(n)}</div><div class="price free">Owned</div></div>`).join('')
        : '<p class="muted">No items yet.</p>'
    }</div>
  `;
}

let avatarPreviewRenderer = null, avatarPreviewScene = null, avatarPreviewCamera = null, avatarPreviewAnim = null, avatarPreviewModel = null;
let avatarDrag = { active: false, lastX: 0, rotY: 0, autoSpin: true };
function stopAvatarPreview() {
  if (avatarPreviewAnim) { cancelAnimationFrame(avatarPreviewAnim); avatarPreviewAnim = null; }
  if (avatarPreviewRenderer) { avatarPreviewRenderer.dispose(); avatarPreviewRenderer = null; }
  avatarPreviewScene = null; avatarPreviewCamera = null; avatarPreviewModel = null;
  avatarDrag = { active: false, lastX: 0, rotY: 0, autoSpin: true };
}
function startAvatarPreview(canvasEl) {
  stopAvatarPreview();
  if (!canvasEl || !character) return;
  const w = canvasEl.clientWidth || 280, h = canvasEl.clientHeight || 280;
  avatarPreviewRenderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true, alpha: true });
  avatarPreviewRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  avatarPreviewRenderer.setSize(w, h, false);
  avatarPreviewRenderer.outputColorSpace = THREE.SRGBColorSpace;
  avatarPreviewScene = new THREE.Scene();
  // Sky background (static — character does not auto-rotate)
  avatarPreviewScene.background = new THREE.Color(0x87ceeb);
  try {
    const skyLoader = new THREE.TextureLoader();
    skyLoader.load('Assets/Skyboxes/Sky_Clouds.jpg', (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace || THREE.sRGBEncoding;
      tex.mapping = THREE.EquirectangularReflectionMapping;
      if (avatarPreviewScene) {
        avatarPreviewScene.background = tex;
        avatarPreviewScene.environment = tex;
      }
    }, undefined, () => {});
  } catch (_) {}
  avatarPreviewScene.add(new THREE.AmbientLight(0xffffff, 0.85));
  const light = new THREE.DirectionalLight(0xfff5e0, 1.15);
  light.position.set(3, 5, 4);
  avatarPreviewScene.add(light);
  const fill = new THREE.DirectionalLight(0x8899ff, 0.4);
  fill.position.set(-3, 2, -2);
  avatarPreviewScene.add(fill);
  avatarPreviewCamera = new THREE.PerspectiveCamera(40, w / h, 0.1, 50);
  avatarPreviewCamera.position.set(0, 1.2, 3.8);
  avatarPreviewCamera.lookAt(0, 0.9, 0);
  // Pivot at center of model — NO auto spin
  avatarPreviewModel = character.clone(true);
  applyEquippedAccessoriesToModel(avatarPreviewModel);
  const box = new THREE.Box3().setFromObject(avatarPreviewModel);
  const center = new THREE.Vector3();
  box.getCenter(center);
  avatarPreviewModel.position.set(-center.x, -box.min.y, -center.z);
  const pivot = new THREE.Group();
  pivot.add(avatarPreviewModel);
  avatarPreviewScene.add(pivot);
  avatarPreviewModel = pivot;
  avatarDrag.autoSpin = false;
  avatarDrag.rotY = 0;
  function tick() {
    avatarPreviewAnim = requestAnimationFrame(tick);
    if (avatarPreviewModel) avatarPreviewModel.rotation.y = avatarDrag.rotY;
    if (avatarPreviewRenderer) avatarPreviewRenderer.render(avatarPreviewScene, avatarPreviewCamera);
  }
  tick();
  // Optional manual drag rotate only (no auto spin after)
  const onDown = (e) => {
    avatarDrag.active = true;
    avatarDrag.autoSpin = false;
    avatarDrag.lastX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    e.preventDefault();
  };
  const onMove = (e) => {
    if (!avatarDrag.active) return;
    const x = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    const dx = x - avatarDrag.lastX;
    avatarDrag.rotY += dx * 0.01;
    avatarDrag.lastX = x;
    e.preventDefault();
  };
  const onUp = () => { avatarDrag.active = false; };
  canvasEl.addEventListener('pointerdown', onDown);
  canvasEl.addEventListener('pointermove', onMove);
  canvasEl.addEventListener('pointerup', onUp);
  canvasEl.addEventListener('pointerleave', onUp);
  canvasEl.addEventListener('touchstart', onDown, { passive: false });
  canvasEl.addEventListener('touchmove', onMove, { passive: false });
  canvasEl.addEventListener('touchend', onUp);
}

/** Catalog accessories available for equip on the avatar page */
/** Free face textures — only one may be equipped at a time */
function getFaceTextureCatalog() {
  return [
    { id: 'face_smile', name: 'Classic Smile', img: 'Assets/Faces/Face_Smile.png', desc: 'Friendly closed smile.' },
    { id: 'face_grin', name: 'Open Grin', img: 'Assets/Faces/Face_Grin.png', desc: 'Happy open-mouth grin.' },
    { id: 'face_happy', name: 'Happy Smile', img: 'Assets/Faces/Face_Happy.png', desc: 'Bright cheerful smile.' },
    { id: 'face_surprised', name: 'Surprised', img: 'Assets/Faces/Face_Surprised.png', desc: 'Wide-eyed surprise.' },
    { id: 'face_sidelook', name: 'Side Look', img: 'Assets/Faces/Face_SideLook.png', desc: 'Looking to the side.' },
    { id: 'face_monster', name: 'Monster Grin', img: 'Assets/Faces/Face_Monster.png', desc: 'Scary jagged smile.' },
  ];
}
// Back-compat aliases used by Avatar customize UI
function getAccessoryCatalog() { return getFaceTextureCatalog().map(f => ({ ...f, slot: 'face' })); }
function getOwnedAccessories() {
  return getFaceTextureCatalog().map(a => ({ ...a, slot: 'face', owned: true }));
}

function findHeadBoneOrMesh(root) {
  let found = null;
  root.traverse(c => {
    if (found) return;
    const n = (c.name || '').toLowerCase();
    if (n.includes('head') || n.includes('face') || n === 'mesh_head') found = c;
  });
  return found;
}

function applyEquippedAccessoriesToModel(root) {
  if (!root) return;
  const toRemove = [];
  root.traverse(c => { if (c.userData && c.userData.isAccessory) toRemove.push(c); });
  toRemove.forEach(c => c.parent && c.parent.remove(c));

  // Single equipped face texture (or none)
  const faceId = account.equippedFace || (account.equippedAccessories && account.equippedAccessories[0]) || null;
  if (!faceId) return;
  const item = getFaceTextureCatalog().find(a => a.id === faceId);
  if (!item) return;

  try {
    const loader = new THREE.TextureLoader();
    loader.load(item.img, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace || THREE.sRGBEncoding;
      const mat = new THREE.MeshBasicMaterial({
        map: tex, transparent: true, side: THREE.DoubleSide, depthWrite: false, alphaTest: 0.05
      });
      // Face plane sized for R6 / Girl head
      const geo = new THREE.PlaneGeometry(0.48, 0.48);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.userData.isAccessory = true;
      mesh.userData.accessoryId = faceId;
      mesh.name = 'EquippedFace';

      const head = findHeadBoneOrMesh(root);
      if (head) {
        // Attach in front of head mesh
        const hb = new THREE.Box3().setFromObject(head);
        const hs = hb.getSize(new THREE.Vector3());
        mesh.position.set(0, hs.y * 0.05, Math.max(hs.z * 0.55, 0.22));
        head.add(mesh);
      } else {
        // Fallback placement for simple avatars
        const box = new THREE.Box3().setFromObject(root);
        const size = box.getSize(new THREE.Vector3());
        mesh.position.set(0, size.y * 0.72, size.z * 0.35 + 0.2);
        root.add(mesh);
      }
    }, undefined, () => {});
  } catch (_) {}
}

/**
 * Equip/unequip a face texture.
 * Only ONE face may be equipped. Equipping another while one is on returns a message.
 */
function toggleEquipAccessory(id) {
  const catalog = getFaceTextureCatalog();
  if (!catalog.find(f => f.id === id)) return { ok: false, msg: 'Unknown face texture.' };

  account.inventory = account.inventory || [];
  if (!account.inventory.includes(id)) account.inventory.push(id);

  const current = account.equippedFace || null;
  if (current === id) {
    // Unequip
    account.equippedFace = null;
    account.equippedAccessories = [];
    account.settings = account.settings || {};
    account.settings.face = null;
    save(account);
    refreshAvatarPreview();
    return { ok: true, msg: 'Face unequipped.', equipped: false };
  }
  if (current && current !== id) {
    return {
      ok: false,
      msg: 'Only one face texture can be equipped. Unequip the current face first.',
      equipped: true,
      current
    };
  }
  // Equip this face
  account.equippedFace = id;
  account.equippedAccessories = [id];
  account.settings = account.settings || {};
  account.settings.face = id;
  save(account);
  refreshAvatarPreview();
  return { ok: true, msg: 'Face equipped.', equipped: true };
}

function unequipCharacterTexture() {
  account.equippedFace = null;
  account.equippedAccessories = [];
  if (account.settings) account.settings.face = null;
  save(account);
  refreshAvatarPreview();
}

function refreshAvatarPreview() {
  stopAvatarPreview();
  requestAnimationFrame(() => {
    const canvas = document.getElementById('avatar-viewport');
    if (canvas) startAvatarPreview(canvas);
    // also refresh profile host if visible
    const host = document.getElementById('profile-3d-host');
    if (host) mountProfile3DViewport(host);
  });
}
function renderAvatar() {
  stopAvatarPreview();
  const genderLabel = (account.gender === 'girl' || account.gender === 'female') ? 'Girl' : 'Boy';
  const col = account.avatarColor || account.chatColor || '#5b9dff';
  const partColors = account.partColors || {};
  const faces = getFaceTextureCatalog();
  const equippedFace = account.equippedFace || null;
  content.innerHTML = `
    <div class="hello">Avatar</div>
    <p class="muted" style="margin:8px 0">Character: <strong>${genderLabel}</strong> · Static viewport · Free face textures</p>
    <div id="avatar-viewport-wrap" class="avatar-viewport-sky"><canvas id="avatar-viewport"></canvas></div>
    <p class="muted" style="text-align:center;margin-top:8px">${escapeHtml(account.username)}</p>
    <div class="recolor-row">
      <label>Recolor all <input type="color" id="avatar-color" value="${col}" /></label>
      <button class="btn btn-dark" id="avatar-apply-color" style="padding:8px 14px">Apply All</button>
      <button class="btn btn-outline" id="avatar-switch-gender" style="padding:8px 14px">Switch to ${genderLabel === 'Boy' ? 'Girl' : 'Boy'}</button>
    </div>
    <div class="section-title" style="margin-top:18px">Customize Face</div>
    <p class="muted" style="margin:4px 0 10px">Free face textures for Boy / Girl models. Only <strong>one</strong> face can be equipped at a time.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
      <button class="btn btn-purple" id="avatar-toggle-acc-panel">Customize Accessories</button>
      <button class="btn btn-dark" id="avatar-unequip-face" ${equippedFace ? '' : 'disabled'}>Unequip Face Texture</button>
    </div>
    <div id="avatar-face-status" class="muted" style="min-height:1.2em;margin-bottom:8px">
      ${equippedFace ? 'Equipped: <strong>' + escapeHtml((faces.find(f => f.id === equippedFace) || {}).name || equippedFace) + '</strong>' : 'No face texture equipped.'}
    </div>
    <div id="avatar-acc-panel" class="avatar-acc-panel hidden">
      <div class="avatar-acc-grid" id="avatar-acc-grid">
        ${faces.map(a => {
          const on = equippedFace === a.id;
          return `<button class="avatar-acc-card ${on ? 'equipped' : ''}" data-acc-id="${a.id}" title="${escapeHtml(a.desc || '')}">
            <img src="${a.img}" alt=""/>
            <span class="acc-name">${escapeHtml(a.name)}</span>
            <span class="acc-state">${on ? 'Equipped' : 'Equip'}</span>
          </button>`;
        }).join('')}
      </div>
    </div>
    <div class="section-title" style="margin-top:16px">Part Colors</div>
    <div class="part-color-list" id="part-color-list"><p class="muted">Loading parts…</p></div>
  `;
  requestAnimationFrame(() => {
    startAvatarPreview(document.getElementById('avatar-viewport'));
    setTimeout(() => {
      const parts = getAvatarParts(character);
      const list = document.getElementById('part-color-list');
      if (!list) return;
      if (!parts.length) {
        list.innerHTML = '<p class="muted">No named parts found — use Recolor All</p>';
        return;
      }
      list.innerHTML = parts.map(p => {
        const saved = (partColors[p] || col);
        return `<div class="part-color-row">
          <span>${escapeHtml(p)}</span>
          <input type="color" data-part="${escapeHtml(p)}" value="${saved}" />
        </div>`;
      }).join('');
      list.querySelectorAll('input[type="color"]').forEach(inp => {
        inp.addEventListener('input', () => {
          const part = inp.dataset.part;
          const hex = inp.value;
          account.partColors = account.partColors || {};
          account.partColors[part] = hex;
          applyPartColor(character, part, hex);
          save(account);
        });
      });
    }, 400);
  });

  const statusEl = () => document.getElementById('avatar-face-status');
  const refreshFaceCards = () => {
    const eq = account.equippedFace || null;
    const facesNow = getFaceTextureCatalog();
    document.querySelectorAll('.avatar-acc-card').forEach(c => {
      const on = c.dataset.accId === eq;
      c.classList.toggle('equipped', on);
      const st = c.querySelector('.acc-state');
      if (st) st.textContent = on ? 'Equipped' : 'Equip';
    });
    const unequipBtn = document.getElementById('avatar-unequip-face');
    if (unequipBtn) unequipBtn.disabled = !eq;
    if (statusEl()) {
      statusEl().innerHTML = eq
        ? 'Equipped: <strong>' + escapeHtml((facesNow.find(f => f.id === eq) || {}).name || eq) + '</strong>'
        : 'No face texture equipped.';
    }
  };

  document.getElementById('avatar-toggle-acc-panel')?.addEventListener('click', () => {
    document.getElementById('avatar-acc-panel')?.classList.toggle('hidden');
  });
  document.getElementById('avatar-unequip-face')?.addEventListener('click', () => {
    unequipCharacterTexture();
    refreshFaceCards();
    if (statusEl()) statusEl().textContent = 'Face texture unequipped.';
  });
  document.querySelectorAll('.avatar-acc-card').forEach(btn => {
    btn.addEventListener('click', () => {
      const res = toggleEquipAccessory(btn.dataset.accId);
      refreshFaceCards();
      if (statusEl()) {
        statusEl().textContent = res.msg || '';
        if (!res.ok) statusEl().style.color = '#ff8c8c';
        else statusEl().style.color = '';
      }
    });
  });
  document.getElementById('avatar-apply-color')?.addEventListener('click', () => {
    const hex = document.getElementById('avatar-color')?.value || '#5b9dff';
    account.avatarColor = hex;
    applyAvatarColor(character, hex);
    account.partColors = {};
    save(account);
    refreshAvatarPreview();
  });
  document.getElementById('avatar-switch-gender')?.addEventListener('click', async () => {
    account.gender = (account.gender === 'girl' || account.gender === 'female') ? 'boy' : 'girl';
    save(account);
    await loadCharacter();
    renderAvatar();
  });
}

function renderGroups() {
  // Groups live under Communities now
  renderCommunity();
}

function renderSettings() {
  const s = account.settings;
  content.innerHTML = `
    <div class="hello"><img src="${ASSETS.gameSettings}" class="theme-icon" alt="" style="width:24px;height:24px;vertical-align:middle;margin-right:8px;border-radius:6px" onerror="this.style.display='none'"/> Settings</div>
    <div class="settings-group">
      <h3>Account</h3>
      <div class="settings-row">Username <input type="text" id="set-username" value="${escapeHtml(account.username)}" maxlength="20" /></div>
      <div class="settings-row">User ID <span class="muted">${account.user_id}</span></div>
    </div>
    <div class="settings-group">
      <h3>Audio</h3>
      <div class="settings-row">Sound <input type="checkbox" id="hs-sound" ${s.sound ? 'checked' : ''} /></div>
      <div class="settings-row">Music <input type="checkbox" id="hs-music" ${s.music ? 'checked' : ''} /></div>
      <div class="settings-row">Volume <input type="range" id="hs-volume" min="0" max="1" step="0.05" value="${s.volume || 0.7}" /></div>
      <div class="settings-row">Music Vol <input type="range" id="hs-music-vol" min="0" max="1" step="0.05" value="${s.musicVol || 0.5}" /></div>
    </div>
    <div class="settings-group">
      <h3>Controls</h3>
      <div class="settings-row">Joystick Visible <input type="checkbox" id="hs-joystick" ${s.joystick ? 'checked' : ''} /></div>
      <div class="settings-row">Look Sensitivity <input type="range" id="hs-sens" min="0.3" max="2" step="0.1" value="${s.sensitivity}" /></div>
    </div>
    <div class="settings-group">
      <h3>Graphics & QOL</h3>
      <div class="settings-row">Quality
        <select id="hs-graphics">
          <option value="low" ${s.graphics==='low'?'selected':''}>Low</option>
          <option value="medium" ${s.graphics==='medium'?'selected':''}>Medium</option>
          <option value="high" ${s.graphics==='high'?'selected':''}>High</option>
        </select>
      </div>
      <div class="settings-row">QOL <input type="range" id="hs-qol" min="0" max="500" step="10" value="${s.qol || 100}" /> <span id="qol-val">${s.qol || 100}</span></div>
      <div class="settings-row">FOV <input type="range" id="hs-fov" min="50" max="90" step="1" value="${s.fov}" /></div>
      <div class="settings-row">Show Names <input type="checkbox" id="hs-names" ${s.showNames !== false ? 'checked' : ''} /></div>
      <div class="settings-row">Theme
        <select id="hs-theme">
          <option value="light" ${!s.theme || s.theme==='light' || s.theme==='halloween'?'selected':''}>Light</option>
          <option value="purewhite" ${s.theme==='purewhite'||s.theme==='white'?'selected':''}>Pure White</option>
          <option value="dark" ${s.theme==='dark'?'selected':''}>Dark</option>
        </select>
      </div>
      <div class="settings-row">Desktop Mode <input type="checkbox" id="hs-desktop" ${s.desktopMode ? 'checked' : ''} /></div>
      <div class="settings-row">
        <button class="btn btn-dark" id="btn-fullscreen" style="display:flex;align-items:center;gap:8px;width:100%;justify-content:center">
          <img src="${ASSETS.fullScreen}" alt="" style="width:20px;height:20px" onerror="this.style.display='none'"/> Fullscreen
        </button>
      </div>
    </div>
    <div class="settings-group">
      <h3>Chat</h3>
      <div class="settings-row">Show Chat <input type="checkbox" id="hs-chat" ${s.chat !== false ? 'checked' : ''} /></div>
    </div>
    <div class="btn-row">
      <button class="btn btn-purple" id="go-buy">Buy Dlex</button>
      <button class="btn btn-dark" id="go-tx">Transactions</button>
    </div>
    <p class="muted" style="margin-top:20px;color:#e84545">Danger Zone</p>
    <p class="muted">Local save only. Online play requires internet.</p>
  `;

  document.getElementById('set-username').onchange = (e) => {
    const v = e.target.value.trim().slice(0, 20) || account.username;
    account.username = v;
    account.chatColor = colorForName(v);
    save(account);
    drawNameTag(account.username);
    if (nameTagTex) nameTagTex.needsUpdate = true;
  };
  const bind = (id, key, parse = v => v) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.onchange = el.oninput = () => {
      const val = el.type === 'checkbox' ? el.checked : parse(el.value);
      account.settings[key] = val;
      save(account);
      if (key === 'theme') applyTheme(val);
      if (key === 'music' || key === 'musicVol') syncBgMusic();
      if (key === 'fov' && camera) { camera.fov = +val; camera.updateProjectionMatrix(); }
      if (key === 'graphics') applyGraphics(val);
      if (key === 'joystick') showJoystick = !!val;
      if (key === 'chat') {
        document.getElementById('chat-panel')?.classList.toggle('hidden', !val);
      }
    };
  };
  bind('hs-sound', 'sound');
  bind('hs-music', 'music');
  bind('hs-volume', 'volume', parseFloat);
  bind('hs-music-vol', 'musicVol', parseFloat);
  bind('hs-joystick', 'joystick');
  bind('hs-sens', 'sensitivity', parseFloat);
  bind('hs-graphics', 'graphics');
  bind('hs-fov', 'fov', parseFloat);
  bind('hs-names', 'showNames');
  bind('hs-theme', 'theme');
  bind('hs-chat', 'chat');
  const deskEl = document.getElementById('hs-desktop');
  if (deskEl) {
    deskEl.onchange = () => {
      account.settings.desktopMode = deskEl.checked;
      save(account);
      applyDesktopMode(deskEl.checked);
    };
  }
  const qolEl = document.getElementById('hs-qol');
  if (qolEl) {
    qolEl.oninput = () => {
      account.settings.qol = +qolEl.value;
      document.getElementById('qol-val').textContent = qolEl.value;
      save(account);
      applyQol(+qolEl.value);
    };
  }
  document.getElementById('btn-fullscreen')?.addEventListener('click', () => {
    const el = document.documentElement;
    if (!document.fullscreenElement) el.requestFullscreen?.() || el.webkitRequestFullscreen?.();
    else document.exitFullscreen?.() || document.webkitExitFullscreen?.();
  });

  document.getElementById('go-buy').onclick = () => {
    document.getElementById('buy-balance').textContent = account.dlex;
    const packs = document.getElementById('packs');
    packs.innerHTML = '';
    PACKS.forEach(p => {
      const d = document.createElement('div');
      d.className = 'pack';
      d.innerHTML = `
        <div class="left"><img src="${ASSETS.dlexCoin}" onerror="this.style.display='none'"/><div>
          <div style="font-weight:600">${p.dlex} Dlex ${p.bonus ? '<span class="badge">BEST</span>' : ''}</div>
          <div class="muted">${p.label}</div></div></div>
        <div style="font-weight:700">$${p.usd.toFixed(2)}</div>`;
      d.onclick = () => alert('Dlex will be out soon! No purchasing Dlex today.');
      packs.appendChild(d);
    });
    showScreen('buy-dlex');
  };
  document.getElementById('go-tx').onclick = () => {
    const list = document.getElementById('tx-list');
    const txs = (account.transactions || []).slice().reverse().slice(0, 30);
    list.innerHTML = txs.length ? txs.map(t => `
      <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #2a2438;gap:8px;flex-wrap:wrap">
        <span class="muted">${t.time}</span><span>${escapeHtml(t.desc)}</span>
        <span style="color:${t.amount >= 0 ? '#28c85a' : '#e84545'}">${t.amount >= 0 ? '+' : ''}${t.amount} Dlex</span>
      </div>`).join('') : '<p class="muted">No transactions yet.</p>';
    showScreen('tx');
  };
}

function applyGraphics(level) {
  const pr = level === 'low' ? 1 : level === 'high' ? Math.min(window.devicePixelRatio, 2) : Math.min(window.devicePixelRatio, 1.5);
  renderer.setPixelRatio(pr);
  renderer.shadowMap.enabled = level !== 'low';
  sun.castShadow = level !== 'low';
}
function applyQol(val) {
  // QOL 0-500: higher = better shadows / quality without lag
  const q = Math.max(0, Math.min(500, val || 100));
  if (!renderer || !sun) return;
  const mapSize = q < 100 ? 512 : q < 250 ? 1024 : q < 400 ? 2048 : 2048;
  if (sun.shadow) {
    sun.shadow.mapSize.set(mapSize, mapSize);
    sun.shadow.map?.dispose?.();
    sun.shadow.map = null;
  }
  renderer.shadowMap.enabled = q > 20;
  sun.castShadow = q > 20;
  if (q >= 300) renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  else renderer.shadowMap.type = THREE.PCFShadowMap;
}

const FREE_FACE_CATALOG = [
  { id: 'face_smile', name: 'Classic Smile', face: '🙂', img: 'Assets/Faces/Face_Smile.png', description: 'Friendly closed smile.' },
  { id: 'face_grin', name: 'Open Grin', face: '😀', img: 'Assets/Faces/Face_Grin.png', description: 'Happy open-mouth grin.' },
  { id: 'face_happy', name: 'Happy Smile', face: '☺', img: 'Assets/Faces/Face_Happy.png', description: 'Bright cheerful smile.' },
  { id: 'face_surprised', name: 'Surprised', face: '😮', img: 'Assets/Faces/Face_Surprised.png', description: 'Wide-eyed surprise.' },
  { id: 'face_sidelook', name: 'Side Look', face: '👀', img: 'Assets/Faces/Face_SideLook.png', description: 'Looking to the side.' },
  { id: 'face_monster', name: 'Monster Grin', face: '😈', img: 'Assets/Faces/Face_Monster.png', description: 'Scary jagged smile.' }
];
const FREE_FACE_STOCK_KEY = 'dolex_free_face_stock_v1';
function getFreeFaceStock() {
  let stock = {};
  try { stock = JSON.parse(localStorage.getItem(FREE_FACE_STOCK_KEY) || '{}') || {}; } catch {}
  FREE_FACE_CATALOG.forEach(f => { if (!Number.isFinite(stock[f.id])) stock[f.id] = 200000; });
  try { localStorage.setItem(FREE_FACE_STOCK_KEY, JSON.stringify(stock)); } catch {}
  return stock;
}

function renderMarketplace() {
  if (!account.inventory) account.inventory = [];
  if (!account.settings) account.settings = {};

  // User-uploaded marketplace items (textures / accessories / avatars)
  const MP_KEY = 'dolex_marketplace_items_v1';
  function loadMpItems() {
    try { return JSON.parse(localStorage.getItem(MP_KEY) || '[]'); } catch { return []; }
  }
  function saveMpItems(list) {
    try { localStorage.setItem(MP_KEY, JSON.stringify(list)); } catch {}
  }
  let mpItems = loadMpItems();

  const ownsFat = account.inventory.includes('font_static_fat') || account.settings.usernameFont === 'static_fat';
  const dlexBal = account.dlex || 0;

  // Marketplace: accessories removed — free face textures live under Faces on Avatar page
  const catalog = {
    accessories: [],
    avatars: [
      { id: 'av_noob', name: 'Classic Noob', price: 0, img: 'Assets/DoLex.png', cat: 'Avatars', desc: 'The original starter look.', free: true },
    ],
    animations: [
      { id: 'anim_wave', name: 'Friendly Wave', price: 50, img: 'Assets/DoLex.png', cat: 'Animations', desc: 'Wave hello emote.' },
      { id: 'anim_dance', name: 'Victory Dance', price: 120, img: 'Assets/DoLex.png', cat: 'Animations', desc: 'Celebratory dance loop.' },
      { id: 'anim_idle', name: 'Cool Idle', price: 80, img: 'Assets/DoLex.png', cat: 'Animations', desc: 'Relaxed idle stance.' },
    ],
    models: [
      { id: 'mdl_crate', name: 'Wooden Crate', price: 25, img: 'Assets/IconCube.png', cat: 'Models', desc: 'Classic wooden crate part.' },
      { id: 'mdl_spawn', name: 'Spawn Point', price: 40, img: 'Assets/IconCube.png', cat: 'Models', desc: 'Player spawn location marker.' },
    ],
    skyboxes: [
      { id: 'sky_clouds', name: 'Cloudy Day', price: 75, img: 'Assets/Skyboxes/Sky_Clouds.jpg', cat: 'Skyboxes', desc: 'Bright daytime cloudy sky.' },
      { id: 'sky_cross', name: 'Skybox Cross', price: 90, img: 'Assets/Skyboxes/Skybox_Cross.jpg', cat: 'Skyboxes', desc: 'Classic cross skybox.' },
    ],
    audio: [
      { id: 'sfx_oof', name: 'Classic Oof', price: 30, img: 'Assets/DoLex.png', cat: 'Audio', desc: 'The classic death sound.' },
      { id: 'sfx_walk', name: 'Footsteps Pack', price: 45, img: 'Assets/DoLex.png', cat: 'Audio', desc: 'Walking footstep sounds.' },
    ],
    plugins: [
      { id: 'plg_builder', name: 'Quick Builder', price: 200, img: 'Assets/Create.png', cat: 'Plugins', desc: 'Speed up part placement in Studio.' },
      { id: 'plg_color', name: 'Palette Pro', price: 150, img: 'Assets/DoLex.png', cat: 'Plugins', desc: 'Advanced color tools for Studio.' },
    ],
  };
  const allCatalog = Object.values(catalog).flat();
  const demoAccessories = catalog.accessories;
  const demoAvatars = catalog.avatars;

  const hasUserItems = mpItems.length > 0;

  content.innerHTML = `
    <div class="dolex-market">
      <div class="dm-topbar">
        <div class="dm-logo">
          <div class="dm-logo-icon"><img src="Assets/DoLex.png" width="28" height="28" alt=""/></div>
          <div class="dm-logo-text">
            <strong>DoLex Market</strong>
            <span>AVATAR ITEMS · TRADE · EQUIP</span>
          </div>
        </div>
        <div class="dm-search">
          <span class="dm-search-icon"><img src="Studio_Smooth_Icons/eye.svg" width="16" height="16" alt=""/></span>
          <input type="text" id="dm-search-input" placeholder="Search items, avatars, accessories..." />
        </div>
        <div class="dm-currency">
          <img src="${ASSETS.dlex}" alt="Dlex" onerror="this.style.display='none'"/>
          <span id="dm-dlex-val">${dlexBal.toLocaleString()}</span>
          <button class="dm-currency-add" id="dm-add-dlex" title="Get Dlex">+</button>
        </div>
        <div class="dm-profile" title="Profile">
          <img src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/>
        </div>
      </div>

      
      <div class="dm-tabs-for-you" style="display:flex;gap:0;border-bottom:1px solid #3a3450;margin:0 0 12px">
        <button class="dm-fy-tab active" data-fy="foryou" style="fdlex:1;padding:12px;background:none;border:none;border-bottom:2px solid #8c50ff;color:#f0eef8;font-weight:700;cursor:pointer">For you</button>
        <button class="dm-fy-tab" data-fy="charts" style="fdlex:1;padding:12px;background:none;border:none;border-bottom:2px solid transparent;color:#8a849e;font-weight:700;cursor:pointer">Charts</button>
      </div>
    <div class="dm-body">
        <aside class="dm-sidebar">
          <button class="dm-side-item active" data-dm-cat="home">Home</button>
          <button class="dm-side-item" data-dm-cat="accessories">Accessories</button>
          <button class="dm-side-item" data-dm-cat="gear">Gear</button>
          <button class="dm-side-item" data-dm-cat="avatars">Avatars</button>
          <button class="dm-side-item" data-dm-cat="bundles">Bundles</button>
          <button class="dm-side-item" data-dm-cat="wishlist">Wishlist</button>
          <button class="dm-side-item" data-dm-cat="deals">Daily Deals</button>
          <button class="dm-side-item" data-dm-cat="purchases">My Purchases</button>
          <div class="dm-side-divider"></div>
          <button class="dm-side-item" data-dm-cat="help">Help Center</button>
          <button class="dm-side-item" data-dm-cat="leaderboards">Leaderboards</button>
          <button class="dm-side-item" data-dm-cat="settings">Settings</button>
          <div class="dm-side-promo">
            <strong>LEVEL UP YOUR STYLE!</strong>
            <span>Create & upload items for others to buy</span>
          </div>
        </aside>

        <div class="dm-main" id="dm-main">
          <div class="dm-banner">
            <div class="dm-banner-content">
              <h2>Daily Deals</h2>
              <p>Limited time offers. Don't miss out!</p>
              <button class="dm-banner-btn" id="dm-view-deals">VIEW ALL DEALS ›</button>
            </div>
            <div class="dm-banner-avatars">
              <img src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/>
              <img src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/>
              <img src="${ASSETS.dolex}" alt="" onerror="this.style.display='none'"/>
            </div>
          </div>

          ${!hasUserItems ? `
          <div class="dm-empty">
            <div class="dm-empty-icon"><img src="Studio_Smooth_Icons/archive.png" width="48" height="48" alt=""/></div>
            <h3>No Items Yet</h3>
            <p>You can go to <strong>Create</strong> and create some, or upload textures so other players can buy them. Set the price and then upload to the Marketplace.</p>
            <button class="btn btn-purple" id="dm-go-create">Go to Create</button>
            <button class="btn btn-dark" id="dm-upload-item">Upload Item / Texture</button>
          </div>
          ` : ''}

          <div class="dm-section-head">
            <h3>FREE FACE TEXTURES</h3>
            <a id="dm-view-all-acc">Equip on Avatar ›</a>
          </div>
          <div class="dm-grid" id="dm-acc-grid">
            ${getFaceTextureCatalog().map(a => {
              const on = (account.equippedFace || account.settings?.face) === a.id;
              return `<div class="dm-card" data-face-id="${a.id}">
                <div class="dm-card-img"><img src="${a.img}" alt=""/></div>
                <div class="dm-card-name">${a.name}</div>
                <div class="dm-card-price free">${on ? 'Equipped' : 'Free'}</div>
              </div>`;
            }).join('')}
          </div>

          <div class="dm-section-head">
            <h3>POPULAR AVATARS</h3>
            <a id="dm-view-all-av">VIEW ALL ›</a>
          </div>
          <div class="dm-grid" id="dm-av-grid">
            ${demoAvatars.map(a => `
              <div class="dm-card" data-demo="av">
                <div class="dm-card-img"><img src="${a.img}" alt="" onerror="this.parentElement.innerHTML='🙂'"/></div>
                <div class="dm-card-name">${a.name}</div>
                <div class="dm-card-price ${a.free ? 'free' : ''}">${a.free ? 'Free 🎁' : 'Dlex ' + a.price}</div>
              </div>
            `).join('')}
            ${mpItems.filter(i => i.category === 'avatar').map(i => `
              <div class="dm-card" data-mp-id="${i.id}">
                <div class="dm-card-img">${i.preview ? `<img src="${i.preview}" alt=""/>` : '👤'}</div>
                <div class="dm-card-name">${i.name}</div>
                <div class="dm-card-price ${i.price <= 0 ? 'free' : ''}">${i.price <= 0 ? 'Free' : 'Dlex ' + i.price}</div>
              </div>
            `).join('')}
          </div>

          <div class="dm-section-head">
            <h3>FONTS</h3>
          </div>
          <div class="dm-grid">
            <div class="dm-card" id="dm-font-fat">
              <div class="dm-card-img" style="font-family:Impact,Arial Black,sans-serif;font-size:1.4rem">Aa</div>
              <div class="dm-card-name">Username Font Static</div>
              <div class="dm-card-price free">${ownsFat ? 'Owned' : 'Free'}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Floating Chat button with UICorners -->
    <button id="dm-chat-btn" title="Chat">
      <img src="Assets/1000189403.jpg" alt="Chat"/>
    </button>
  `;

  // Remove any previous chat btn if re-rendered
  document.querySelectorAll('#dm-chat-btn').forEach((el, idx) => { if (idx > 0) el.remove(); });

  // Event wiring
  document.getElementById('dm-go-create')?.addEventListener('click', () => {
    document.querySelector('[data-nav="create"]')?.click();
  });

  document.getElementById('dm-add-dlex')?.addEventListener('click', () => {
    alert('Dlex packs will be available soon! No real purchases yet.');
  });

  document.getElementById('dm-view-deals')?.addEventListener('click', () => {
    alert('Daily Deals rotate every 24h. Check back soon!');
  });

  // Chat button
  document.getElementById('dm-chat-btn')?.addEventListener('click', () => {
    const existing = document.getElementById('chat-panel');
    if (existing) {
      existing.classList.toggle('hidden');
    } else {
      alert('Chat coming soon! Connect with other creators.');
    }
  });

  // Upload item flow
  document.getElementById('dm-upload-item')?.addEventListener('click', () => openUploadModal());

  function openUploadModal() {
    const overlay = document.createElement('div');
    overlay.className = 'dm-modal-overlay';
    overlay.innerHTML = `
      <div class="dm-modal">
        <h3>Upload to Marketplace</h3>
        <p class="muted" style="margin-bottom:12px;font-size:0.85rem">Create an item or upload a texture. Set a price (R$) so other players can buy it.</p>
        <label>Item Name</label>
        <input id="up-name" placeholder="e.g. Neon Sword Texture" maxlength="40"/>
        <label>Category</label>
        <select id="up-cat">
          <option value="accessory">Accessory</option>
          <option value="texture">Texture / Decal</option>
          <option value="avatar">Avatar</option>
          <option value="gear">Gear</option>
        </select>
        <label>Price (R$)</label>
        <input id="up-price" type="number" min="0" max="99999" value="99" placeholder="0 = Free"/>
        <label>Description</label>
        <textarea id="up-desc" rows="2" placeholder="Short description..."></textarea>
        <label>Preview Image (optional URL or leave blank)</label>
        <input id="up-preview" placeholder="https://... or leave empty"/>
        <div class="dm-modal-actions">
          <button class="btn btn-dark" id="up-cancel">Cancel</button>
          <button class="btn btn-purple" id="up-submit">Upload & Publish</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    overlay.querySelector('#up-cancel').onclick = () => overlay.remove();
    overlay.querySelector('#up-submit').onclick = () => {
      const name = (overlay.querySelector('#up-name').value || '').trim();
      if (!name) { alert('Please enter a name'); return; }
      const item = {
        id: 'mp_' + Date.now(),
        name,
        category: overlay.querySelector('#up-cat').value,
        price: Math.max(0, parseInt(overlay.querySelector('#up-price').value, 10) || 0),
        description: (overlay.querySelector('#up-desc').value || '').trim(),
        preview: (overlay.querySelector('#up-preview').value || '').trim() || null,
        creator: account.username || 'Player',
        created: Date.now()
      };
      mpItems.push(item);
      saveMpItems(mpItems);
      overlay.remove();
      alert('Item uploaded to Marketplace! Other players can now buy it.');
      renderMarketplace();
    };
  }

  // Face texture interactions — free, one at a time
  content.querySelectorAll('[data-face-id]').forEach(card => {
    card.addEventListener('click', () => {
      const id = card.dataset.faceId;
      const res = toggleEquipAccessory(id);
      if (!res.ok) alert(res.msg);
      else if (res.msg) { /* equipped/unequipped */ }
      renderMarketplace();
    });
  });

  document.getElementById('dm-font-fat')?.addEventListener('click', () => {
    if (!account.inventory.includes('font_static_fat')) account.inventory.push('font_static_fat');
    account.settings.usernameFont = 'static_fat';
    save(account);
    try { drawNameTag(account.username || 'Player'); } catch {}
    if (typeof nameTagTex !== 'undefined') nameTagTex.needsUpdate = true;
    renderMarketplace();
  });

  // Demo card clicks
  content.querySelectorAll('[data-demo]').forEach(c => {
    c.addEventListener('click', () => {
      alert('This is a demo item preview. Upload your own textures from Create / Upload to sell real items!');
    });
  });

  // User item buy
  content.querySelectorAll('[data-mp-id]').forEach(card => {
    card.addEventListener('click', () => {
      const id = card.dataset.mpId;
      const item = mpItems.find(x => x.id === id);
      if (!item) return;
      if (item.price > 0 && (account.dlex || 0) < item.price) {
        alert('Not enough Dlex / R$. Get more Dlex from packs.');
        return;
      }
      if (item.price > 0) {
        account.dlex = (account.dlex || 0) - item.price;
      }
      if (!account.inventory.includes(id)) account.inventory.push(id);
      save(account);
      alert(`Purchased "${item.name}"!`);
      renderMarketplace();
    });
  });

  // Sidebar category clicks (simple filter / message)
  content.querySelectorAll('.dm-side-item').forEach(btn => {
    btn.addEventListener('click', () => {
      content.querySelectorAll('.dm-side-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.dmCat;
      if (cat === 'settings') {
        document.querySelector('[data-nav="settings"]')?.click();
      } else if (cat === 'help') {
        alert('Help Center: Upload textures from the empty-state button, set a price, and they appear in the grid for other players to buy.');
      } else if (cat === 'purchases') {
        const owned = (account.inventory || []).filter(id => id.startsWith('mp_'));
        alert(owned.length ? `You own ${owned.length} marketplace item(s).` : 'No purchases yet. Buy something from the grids!');
      } else {
        // stay on home for other cats for now
      }
    });
  });
}

function renderCreate() {
  stopAvatarPreview();
  const games = JSON.parse(localStorage.getItem('dolex_studio_games') || '[]');
  const DECAL_KEY = 'dolex_decals_v1';
  const MODEL_KEY = 'dolex_models_v1';
  function loadDecals() { try { return JSON.parse(localStorage.getItem(DECAL_KEY) || '[]'); } catch { return []; } }
  function saveDecals(list) { try { localStorage.setItem(DECAL_KEY, JSON.stringify(list)); } catch {} }
  function loadModels() { try { return JSON.parse(localStorage.getItem(MODEL_KEY) || '[]'); } catch { return []; } }
  function saveModels(list) { try { localStorage.setItem(MODEL_KEY, JSON.stringify(list)); } catch {} }
  function genAssetId(prefix) {
    return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  let activeMenu = 'dashboard';
  let activeDevPage = null; // 'decal' | 'model' | null

  function gamesListHtml() {
    return games.length
      ? games.map((g, i) => `
          <div class="game-card-sm" data-gi="${i}">
            <div class="thumb">${g.thumbnail
              ? `<img src="${g.thumbnail}" alt="" />`
              : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#2a1f4a,#1a1628);color:#8c50ff;font-weight:800;font-size:1.4rem">${escapeHtml((g.title||'G')[0])}</div>`
            }</div>
            <div class="body">
              <h4>${escapeHtml(g.title || 'Untitled')}</h4>
              <div class="stats">${escapeHtml(g.category || 'Obby')} · ${g.visits||0} visits · ${(g.events||[]).length} events</div>
              <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
                <button class="btn btn-purple open-detail-btn" data-gi="${i}" style="fdlex:1;padding:6px 8px;font-size:0.78rem">Open</button>
                <button class="btn btn-dark edit-studio-btn" data-gi="${i}" style="fdlex:1;padding:6px 8px;font-size:0.78rem">Edit</button>
                <button class="btn btn-dark add-event-btn" data-gi="${i}" style="fdlex:1;padding:6px 8px;font-size:0.78rem">+ Event</button>
              </div>
            </div>
          </div>`).join('')
      : '<div class="muted" style="padding:18px 4px">No games yet. Hit + New Game (Studio) to start building.</div>';
  }

  function dashboardHtml() {
    const totalVisits = games.reduce((s, g) => s + (g.visits || 0), 0);
    const totalEvents = games.reduce((s, g) => s + ((g.events || []).length), 0);
    return `
      <div class="analytics-hero">
        <div class="analytics-hero-top">
          <div class="analytics-emoji">📈</div>
          <div>
            <h2 class="analytics-title">Creator Analytics</h2>
            <p class="muted" style="margin:0">Track your games, visits, and assets</p>
          </div>
        </div>
        <div class="analytics-grid">
          <div class="stat-card"><div class="stat-val">${games.length}</div><div class="stat-label">Games</div></div>
          <div class="stat-card"><div class="stat-val">${totalVisits}</div><div class="stat-label">Visits</div></div>
          <div class="stat-card"><div class="stat-val">${loadDecals().length}</div><div class="stat-label">Decals</div></div>
          <div class="stat-card"><div class="stat-val">${loadModels().length}</div><div class="stat-label">Models</div></div>
          <div class="stat-card"><div class="stat-val">${totalEvents}</div><div class="stat-label">Events</div></div>
          <div class="stat-card"><div class="stat-val">${(account.dlex||0).toLocaleString()}</div><div class="stat-label">Dlex</div></div>
        </div>
      </div>
      <button class="btn btn-purple btn-create-new" id="btn-new-game">
        <span class="create-plus-icon">+</span> New Game (Studio)
      </button>
      <div class="section-title" style="margin-top:18px">Recent Games</div>
      <div class="games-row" id="my-games-list">${gamesListHtml()}</div>
    `;
  }

  function gamesPanelHtml() {
    return `
      <button class="btn btn-purple" id="btn-new-game" style="width:100%;padding:14px;font-size:1.05rem;margin-bottom:14px">+ New Game (Studio)</button>
      <div class="section-title">My Games</div>
      <div class="games-row" id="my-games-list">${gamesListHtml()}</div>
    `;
  }

  function developmentHtml() {
    if (activeDevPage === 'decal') return decalPageHtml();
    if (activeDevPage === 'model') return modelPageHtml();
    return `
      <p class="muted" style="margin-bottom:12px">Upload assets for use in Studio. Each upload gets a unique ID you can import via the Import ID Box.</p>
      <div class="dev-items-grid">
        <div class="dev-item-card" id="dev-open-decal">
          <div class="dev-icon"><img src="Studio_Smooth_Icons/file.png" width="32" height="32" alt=""/></div>
          <strong>Decal</strong>
          <span>Upload photos → Decal ID</span>
        </div>
        <div class="dev-item-card" id="dev-open-model">
          <div class="dev-icon"><img src="Studio_Smooth_Icons/archive.png" width="32" height="32" alt=""/></div>
          <strong>Model</strong>
          <span>Upload models → Model ID</span>
        </div>
      </div>
    `;
  }

  function decalPageHtml() {
    const list = loadDecals();
    return `
      <div class="asset-page">
        <button class="btn btn-dark" id="dev-back" style="margin-bottom:12px">‹ Back</button>
        <h2>Decals</h2>
        <p class="muted">Upload a photo. It is converted into a Decal ID you can import in Studio.</p>
        <div class="asset-upload-zone" id="decal-drop">
          <div style="margin-bottom:8px"><img src="Studio_Smooth_Icons/camera.png" width="40" height="40" alt=""/></div>
          <strong>Upload Decal</strong>
          <p class="muted" style="margin-top:6px;font-size:0.85rem">Click or drop an image (PNG/JPG)</p>
          <input type="file" id="decal-file" accept="image/*"/>
        </div>
        <div class="asset-list">
          ${list.length ? list.map(d => `
            <div class="asset-row">
              <img src="${d.dataUrl}" alt=""/>
              <div class="asset-meta">
                <strong>${escapeHtml(d.name)}</strong>
                <div class="asset-id">${escapeHtml(d.id)}</div>
              </div>
              <button class="asset-copy" data-copy="${escapeHtml(d.id)}">Copy ID</button>
            </div>
          `).join('') : '<p class="muted">No decals yet. Upload one above.</p>'}
        </div>
      </div>
    `;
  }

  function modelPageHtml() {
    const list = loadModels();
    return `
      <div class="asset-page">
        <button class="btn btn-dark" id="dev-back" style="margin-bottom:12px">‹ Back</button>
        <h2>Models</h2>
        <p class="muted">Upload a 3D model (.obj / .gltf / .glb). You get a Model ID to import in Studio onto the Baseplate.</p>
        <div class="asset-upload-zone" id="model-drop">
          <div style="font-size:2rem;margin-bottom:8px">📦</div>
          <strong>Upload Model</strong>
          <p class="muted" style="margin-top:6px;font-size:0.85rem">Click or drop a model file</p>
          <input type="file" id="model-file" accept=".obj,.gltf,.glb,model/*"/>
        </div>
        <div class="asset-list">
          ${list.length ? list.map(m => `
            <div class="asset-row">
              <div class="asset-thumb">📦</div>
              <div class="asset-meta">
                <strong>${escapeHtml(m.name)}</strong>
                <div class="asset-id">${escapeHtml(m.id)}</div>
              </div>
              <button class="asset-copy" data-copy="${escapeHtml(m.id)}">Copy ID</button>
            </div>
          `).join('') : '<p class="muted">No models yet. Upload one above.</p>'}
        </div>
      </div>
    `;
  }

  function avatarItemsHtml() {
    return `
      <p class="muted" style="margin-bottom:12px">Avatar items you publish appear in the <strong>Marketplace</strong> for other players to buy.</p>
      <button class="btn btn-purple" id="create-go-market" style="width:100%;padding:14px">Open Avatar Items Marketplace</button>
      <button class="btn btn-dark" id="create-upload-avatar-item" style="width:100%;padding:12px;margin-top:10px">Upload Avatar Item / Texture</button>
      <p class="muted" style="margin-top:14px;font-size:0.85rem">Tip: From Marketplace empty state you can also upload textures and set prices.</p>
    `;
  }

  function experiencesHtml() {
    return `
      <div class="create-settings-card">
        <div class="create-settings-head"><div><h3>Experiences</h3><p class="muted">My Experiences · Shared With Me</p></div></div>
        <div style="display:flex;gap:8px;margin:12px 0;flex-wrap:wrap">
          <button class="btn btn-purple" style="padding:8px 14px">My Experiences</button>
          <button class="btn btn-dark" style="padding:8px 14px">Shared With Me</button>
        </div>
        <div class="games-row" id="my-games-list">${gamesListHtml()}</div>
      </div>
    `;
  }

  function creatorHubHtml() {
    return `
      <div class="create-settings-card">
        <h3>Explore Creator Hub</h3>
        <p class="muted" style="margin:8px 0 14px">Tools and programs to help you reach players.</p>
        <div class="dev-items-grid">
          <div class="dev-item-card" id="hub-avatar-item">
            <div class="dev-icon"><img src="${ASSETS.create || ASSETS.dolex}" width="36" height="36" alt=""/></div>
            <strong>Create an Avatar Item</strong>
            <span>Publish to Marketplace</span>
          </div>
          <div class="dev-item-card" id="hub-new-game">
            <div class="dev-icon"><img src="${ASSETS.home}" width="36" height="36" alt=""/></div>
            <strong>New Experience</strong>
            <span>Open Studio and build</span>
          </div>
        </div>
        <div style="background:#201a32;border-radius:12px;padding:14px;margin-top:16px">
          <strong>Build on DoLex and reach players</strong>
          <p class="muted" style="margin-top:8px;font-size:0.88rem">Publish games, upload assets, and track visits from the Dashboard.</p>
        </div>
      </div>
    `;
  }

  function learnHtml() {
    return `
      <div class="create-settings-card">
        <h3>Learn</h3>
        <p class="muted" style="margin:8px 0 12px">Guides for Studio, scripting basics, and publishing.</p>
        <ul style="margin:0;padding-left:18px;line-height:1.8">
          <li>Open <strong>Games</strong> then + New Game (Studio)</li>
          <li>Use Import ID Box for Decals and Models</li>
          <li>Publish as Public so it appears on Home</li>
          <li>Upload avatar textures from Avatar Items</li>
        </ul>
      </div>
    `;
  }

  function analyticsHtml() {
    return `
      <div class="create-settings-card">
        <h3>Analytics</h3>
        <p class="muted" style="margin:8px 0 12px">High-level stats for your experiences.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div style="background:#120e1c;border-radius:10px;padding:12px"><div class="muted">Experiences</div><strong style="font-size:1.3rem">${games.length}</strong></div>
          <div style="background:#120e1c;border-radius:10px;padding:12px"><div class="muted">Visits (local)</div><strong style="font-size:1.3rem">${games.reduce((s,g)=>s+(g.visits||0),0)}</strong></div>
          <div style="background:#120e1c;border-radius:10px;padding:12px"><div class="muted">Friends</div><strong style="font-size:1.3rem">${(account.friends||[]).length}</strong></div>
          <div style="background:#120e1c;border-radius:10px;padding:12px"><div class="muted">Dlex</div><strong style="font-size:1.3rem">${account.dlex||0}</strong></div>
        </div>
      </div>
    `;
  }

  function render() {
    content.innerHTML = `
      <div class="hello">Create</div>
      <p class="muted" style="margin:6px 0 10px">Creator Hub · Experiences · Assets · Analytics</p>
      <div class="create-menu-bar" id="create-menu-bar">
        <button data-cmenu="dashboard" class="${activeMenu==='dashboard'?'active':''}">Dashboard</button>
        <button data-cmenu="experiences" class="${activeMenu==='experiences'?'active':''}">Experiences</button>
        <button data-cmenu="games" class="${activeMenu==='games'?'active':''}">Games</button>
        <button data-cmenu="hub" class="${activeMenu==='hub'?'active':''}">Creator Hub</button>
        <button data-cmenu="development" class="${activeMenu==='development'?'active':''}">Development</button>
        <button data-cmenu="avatar" class="${activeMenu==='avatar'?'active':''}">Avatar Items</button>
        <button data-cmenu="learn" class="${activeMenu==='learn'?'active':''}">Learn</button>
        <button data-cmenu="analytics" class="${activeMenu==='analytics'?'active':''}">Analytics</button>
      </div>
      <div id="create-panel-body">
        ${activeMenu==='dashboard' ? dashboardHtml() :
          activeMenu==='experiences' ? experiencesHtml() :
          activeMenu==='games' ? gamesPanelHtml() :
          activeMenu==='hub' ? creatorHubHtml() :
          activeMenu==='development' ? developmentHtml() :
          activeMenu==='learn' ? learnHtml() :
          activeMenu==='analytics' ? analyticsHtml() :
          avatarItemsHtml()}
      </div>
    `;
    wire();
  }

  function wire() {
    content.querySelectorAll('[data-cmenu]').forEach(btn => {
      btn.onclick = () => {
        activeMenu = btn.dataset.cmenu;
        activeDevPage = null;
        render();
      };
    });

    document.getElementById('btn-new-game')?.addEventListener('click', () => openDLStudio(null, null));

    document.querySelectorAll('.open-detail-btn').forEach(btn => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openGameDetail(+btn.dataset.gi); });
    });
    document.querySelectorAll('.edit-studio-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const games2 = JSON.parse(localStorage.getItem('dolex_studio_games') || '[]');
        openDLStudio(games2[+btn.dataset.gi] || null, +btn.dataset.gi);
      });
    });
    document.querySelectorAll('.add-event-btn').forEach(btn => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openEventEditor(+btn.dataset.gi); });
    });

    document.getElementById('dev-open-decal')?.addEventListener('click', () => { activeDevPage = 'decal'; render(); });
    document.getElementById('dev-open-model')?.addEventListener('click', () => { activeDevPage = 'model'; render(); });
    document.getElementById('dev-back')?.addEventListener('click', () => { activeDevPage = null; render(); });

    // Decal upload
    const decalDrop = document.getElementById('decal-drop');
    const decalFile = document.getElementById('decal-file');
    if (decalDrop && decalFile) {
      decalDrop.onclick = () => decalFile.click();
      decalFile.onchange = () => {
        const file = decalFile.files && decalFile.files[0];
        if (!file || !file.type.startsWith('image/')) { alert('Please choose an image'); return; }
        const reader = new FileReader();
        reader.onload = () => {
          const id = genAssetId('decal');
          const list = loadDecals();
          list.unshift({ id, name: file.name.replace(/\.[^.]+$/, ''), dataUrl: reader.result, created: Date.now() });
          saveDecals(list);
          if (typeof window.dolexAddToToolbox === 'function') {
            window.dolexAddToToolbox({ name: file.name.replace(/\.[^.]+$/, ''), type: 'decal', dataUrl: reader.result, icon: 'Assets/IconPalette.png' });
          }
          alert('Decal uploaded!\nDecal ID: ' + id + '\nAdded to Toolbox inventory.\nUse Import ID in Studio or open Toolbox.');
          render();
        };
        reader.readAsDataURL(file);
      };
    }

    // Model upload
    const modelDrop = document.getElementById('model-drop');
    const modelFile = document.getElementById('model-file');
    if (modelDrop && modelFile) {
      modelDrop.onclick = () => modelFile.click();
      modelFile.onchange = () => {
        const file = modelFile.files && modelFile.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          const id = genAssetId('model');
          const list = loadModels();
          list.unshift({
            id,
            name: file.name.replace(/\.[^.]+$/, ''),
            dataUrl: reader.result,
            mime: file.type || 'model/obj',
            filename: file.name,
            created: Date.now()
          });
          saveModels(list);
          if (typeof window.dolexAddToToolbox === 'function') {
            window.dolexAddToToolbox({ name: file.name.replace(/\.[^.]+$/, ''), type: 'model', dataUrl: reader.result || '', icon: 'Assets/IconCube.png' });
          }
          alert('Model uploaded!\nModel ID: ' + id + '\nAdded to Toolbox inventory.');
          render();
        };
        // For large binary models store as data URL (base64). OK for demo sizes.
        reader.readAsDataURL(file);
      };
    }

    content.querySelectorAll('[data-copy]').forEach(btn => {
      btn.onclick = () => {
        const id = btn.dataset.copy;
        if (navigator.clipboard) navigator.clipboard.writeText(id).then(() => alert('Copied: ' + id)).catch(() => prompt('Copy ID:', id));
        else prompt('Copy ID:', id);
      };
    });

    document.getElementById('create-go-market')?.addEventListener('click', () => {
      document.querySelector('[data-nav="marketplace"]')?.click();
    });
    document.getElementById('create-upload-avatar-item')?.addEventListener('click', () => {
      document.querySelector('[data-nav="marketplace"]')?.click();
      setTimeout(() => document.getElementById('dm-upload-item')?.click(), 200);
    });
  }

  render();
}

const navRender = {
  home: renderHome, profile: renderProfile, friends: renderFriends,
  marketplace: renderMarketplace, create: renderCreate,
  inventory: renderInventory, avatar: renderAvatar,
  groups: renderGroups, community: renderCommunity,
  settings: renderSettings, about: renderAbout
};

document.getElementById('detail-back').onclick = () => { showScreen('lobby'); renderHome(); };
document.getElementById('buy-back').onclick = () => { showScreen('lobby'); renderSettings(); };
document.getElementById('tx-back').onclick = () => { showScreen('lobby'); renderSettings(); };
document.getElementById('ev-back')?.addEventListener('click', () => {
  showScreen('lobby');
  renderCreate();
});
document.getElementById('ev-image-btn')?.addEventListener('click', () => {
  document.getElementById('ev-image-file')?.click();
});
document.getElementById('ev-image-file')?.addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file || !file.type.startsWith('image/')) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const maxW = 480, maxH = 270;
      let w = img.width, h = img.height;
      const r = Math.min(maxW / w, maxH / h, 1);
      w = Math.round(w * r); h = Math.round(h * r);
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      window._evImageData = canvas.toDataURL('image/jpeg', 0.85);
      const prev = document.getElementById('ev-image-preview');
      if (prev) prev.innerHTML = `<img src="${window._evImageData}" alt=""/>`;
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});
document.getElementById('ev-publish')?.addEventListener('click', () => {
  const idx = currentDetailGameIndex;
  if (idx == null) return;
  const title = (document.getElementById('ev-title')?.value || '').trim();
  if (!title) { alert('Event title required'); return; }
  const games = studioLoadGames();
  if (!games[idx]) return;
  games[idx].events = games[idx].events || [];
  games[idx].events.unshift({
    title,
    desc: (document.getElementById('ev-desc')?.value || '').trim(),
    sub: (document.getElementById('ev-sub')?.value || '').trim(),
    date: (document.getElementById('ev-date')?.value || '').trim(),
    image: window._evImageData || null,
    t: Date.now()
  });
  studioSaveGames(games);
  alert('Event published!');
  openGameDetail(idx);
});
document.getElementById('btn-like').onclick = () => {
  if (!account.liked) {
    account.liked = true;
    account.likes = (account.likes || 0) + 1;
    addTx('Like reward', 5);
    document.getElementById('btn-like').textContent = 'Liked ✓';
  }
};
document.getElementById('btn-rate').onclick = () => {
  const ns = 3 + Math.random() * 2;
  const c = (account.rating_count || 0) + 1;
  account.rating = ((account.rating || 0) * (c - 1) + ns) / c;
  account.rating_count = c;
  addTx('Rate reward', 2);
  document.getElementById('detail-stats').textContent =
    `${account.likes} likes · Rating ${account.rating.toFixed(1)}`;
};

document.getElementById('btn-retry-online').onclick = () => {
  hideOfflineGate();
  connectNetwork();
};
document.getElementById('dc-reconnect').onclick = () => {
  hideDisconnect();
  if (!checkBrowserOnline()) {
    showOfflineGate('Still offline.');
    return;
  }
  netConnected = true;
  isOnline = true;
  setNetBadge('online', 'Online');
  startHeartbeat();
  if (document.getElementById('hud').classList.contains('active')) {
    gameRunning = true;
    subscribePlayers();
  }
};
document.getElementById('dc-leave').onclick = () => {
  hideDisconnect();
  endGame();
};

// ---------- THREE.JS ----------
const canvas = document.getElementById('game-canvas');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87a0c0);
scene.fog = new THREE.Fog(0x87a0c0, 40, 90);

const camera = new THREE.PerspectiveCamera(account.settings.fov || 60, window.innerWidth / window.innerHeight, 0.1, 200);
const ambientLight = new THREE.AmbientLight(0xffffff, 0.55);
scene.add(ambientLight);
const sun = new THREE.DirectionalLight(0xfff5e0, 1.1);
sun.position.set(30, 50, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 120;
sun.shadow.camera.left = -40;
sun.shadow.camera.right = 40;
sun.shadow.camera.top = 40;
sun.shadow.camera.bottom = -40;
sun.shadow.bias = -0.0005;
sun.shadow.normalBias = 0.02;
scene.add(sun);
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

// Day / Night cycle (full cycle ~4 min)
let dayNightTime = 0.25; // 0=midnight, 0.25=sunrise, 0.5=noon, 0.75=sunset
const DAY_NIGHT_SPEED = 0.00004;
function updateDayNight(dt) {
  dayNightTime = (dayNightTime + DAY_NIGHT_SPEED * dt * 60) % 1;
  const t = dayNightTime;
  // Sun angle: rise in east, set in west
  const angle = t * Math.PI * 2;
  const sunH = Math.sin(angle);
  const sunX = Math.cos(angle) * 40;
  const sunY = Math.max(2, sunH * 55);
  const sunZ = Math.sin(angle * 0.5) * 15;
  sun.position.set(sunX, sunY, sunZ);
  sun.target.position.set(0, 0, 0);
  // Colors
  let skyR, skyG, skyB, ambI, sunI, sunC;
  if (t < 0.2 || t > 0.8) { // night
    skyR = 0.05; skyG = 0.06; skyB = 0.12;
    ambI = 0.18; sunI = 0.15; sunC = 0x6688cc;
  } else if (t < 0.3) { // sunrise
    const k = (t - 0.2) / 0.1;
    skyR = 0.05 + k * 0.7; skyG = 0.06 + k * 0.45; skyB = 0.12 + k * 0.35;
    ambI = 0.18 + k * 0.35; sunI = 0.15 + k * 0.9; sunC = 0xffaa66;
  } else if (t < 0.7) { // day
    skyR = 0.53; skyG = 0.63; skyB = 0.75;
    ambI = 0.55; sunI = 1.15; sunC = 0xfff5e0;
  } else { // sunset
    const k = (t - 0.7) / 0.1;
    skyR = 0.53 + k * 0.3; skyG = 0.63 - k * 0.35; skyB = 0.75 - k * 0.5;
    ambI = 0.55 - k * 0.3; sunI = 1.15 - k * 0.7; sunC = 0xff7744;
  }
  // When textured sky is active (play / published), do not overwrite background texture
  if (!window.__useSkyTexture) {
    if (scene.background && scene.background.isColor) {
      scene.background.setRGB(skyR, skyG, skyB);
    } else if (!scene.background) {
      scene.background = new THREE.Color().setRGB(skyR, skyG, skyB);
    }
    if (scene.fog) scene.fog.color.setRGB(skyR, skyG, skyB);
  }
  ambientLight.intensity = ambI;
  sun.intensity = sunI;
  sun.color.setHex(sunC);
  sun.castShadow = sunY > 8;
}

const SPAWN = { x: 0, y: 1.2, z: 0 };
const player = {
  x: SPAWN.x, y: SPAWN.y, z: SPAWN.z, vy: 0, onGround: true,
  health: 100, maxHealth: 100, yaw: 0, dead: false, fallApartUntil: 0
};

let camDist = 8;
const CAM_MIN = 3.5, CAM_MAX = 16;
let camPitch = -0.35;
let camYaw = 0; // independent camera orbit; character faces move direction
let character = null;
const characterRoot = new THREE.Group();
scene.add(characterRoot);

const nameTagCanvas = document.createElement('canvas');
nameTagCanvas.width = 256; nameTagCanvas.height = 64;
const nameTagCtx = nameTagCanvas.getContext('2d');
function drawNameTag(name) {
  nameTagCtx.clearRect(0, 0, 256, 64);
  // BG fully transparent — only text visible
  const fat = account.settings && account.settings.usernameFont === 'static_fat';
  const classic = account.settings && account.settings.usernameFont === 'classic_free';
  nameTagCtx.fillStyle = account.chatColor || '#fff';
  if (fat) {
    nameTagCtx.font = '900 34px Impact, Haettenschweiler, \"Arial Black\", system-ui, sans-serif';
  } else if (classic) {
    nameTagCtx.font = 'italic 30px Georgia, serif';
  } else {
    nameTagCtx.font = 'bold 28px system-ui, sans-serif';
  }
  nameTagCtx.textAlign = 'center';
  nameTagCtx.textBaseline = 'middle';
  // subtle outline for readability without solid background
  nameTagCtx.lineWidth = fat ? 4 : 3;
  nameTagCtx.strokeStyle = 'rgba(0,0,0,0.75)';
  nameTagCtx.strokeText(name, 128, 32);
  nameTagCtx.fillText(name, 128, 32);
}
drawNameTag(account.username);
const nameTagTex = new THREE.CanvasTexture(nameTagCanvas);
nameTagTex.colorSpace = THREE.SRGBColorSpace;
const nameTag = new THREE.Sprite(new THREE.SpriteMaterial({ map: nameTagTex, transparent: true, depthTest: false }));
nameTag.scale.set(2.4, 0.6, 1);
nameTag.position.y = 2.6;
characterRoot.add(nameTag);

const keys = {};
let joyActive = false, joyDX = 0, joyDY = 0;
let pointerLook = false, lastPX = 0, lastPY = 0;
let pinchActive = false, pinchStartDist = 0, pinchStartCam = 8;

const healthWrap = document.getElementById('health-wrap');
const healthBar = document.getElementById('health-bar');
const damageFx = document.getElementById('damage-fx');
let healthVisibleUntil = 0, lastRegen = 0, damageFxUntil = 0, lastHazardHit = 0;

function setHealth(h) {
  const prev = player.health;
  player.health = Math.max(0, Math.min(player.maxHealth, h));
  healthBar.style.width = (player.health / player.maxHealth * 100) + '%';
  if (player.health < player.maxHealth) {
    healthWrap.classList.add('show');
    healthVisibleUntil = performance.now() + 3000;
    if (player.health < prev) {
      healthBar.classList.add('damaged');
      damageFx.classList.add('show');
      damageFxUntil = performance.now() + 1000;
      setTimeout(() => healthBar.classList.remove('damaged'), 400);
    }
  }
  if (player.health <= 0 && !player.dead) dieAndRespawn();
}
function takeDamage(amount) {
  if (player.dead) return;
  setHealth(player.health - amount);
}

// --- SFX: Walk + Death (Oof) ---
const sfxWalk = new Audio('Audio/Walk.mp3');
sfxWalk.loop = true;
sfxWalk.volume = 0.45;
sfxWalk.preload = 'auto';
const sfxDeath = new Audio('Audio/DeathOof.mp3');
sfxDeath.loop = false;
sfxDeath.volume = 0.7;
sfxDeath.preload = 'auto';
let sfxWalkPlaying = false;

function sfxEnabled() {
  try {
    if (account && account.settings && account.settings.sound === false) return false;
  } catch (_) {}
  return true;
}
function playWalkSfx(moving, onGround) {
  if (!sfxEnabled()) {
    if (sfxWalkPlaying) { try { sfxWalk.pause(); sfxWalk.currentTime = 0; } catch(_){} sfxWalkPlaying = false; }
    return;
  }
  if (moving && onGround && !player.dead) {
    if (!sfxWalkPlaying) {
      sfxWalkPlaying = true;
      sfxWalk.currentTime = 0;
      sfxWalk.play().catch(() => { sfxWalkPlaying = false; });
    }
  } else if (sfxWalkPlaying) {
    try { sfxWalk.pause(); sfxWalk.currentTime = 0; } catch(_){}
    sfxWalkPlaying = false;
  }
}
function playDeathSfx() {
  if (!sfxEnabled()) return;
  try {
    if (sfxWalkPlaying) { sfxWalk.pause(); sfxWalk.currentTime = 0; sfxWalkPlaying = false; }
    sfxDeath.currentTime = 0;
    sfxDeath.play().catch(() => {});
  } catch(_){}
}

function dieAndRespawn() {
  player.dead = true;
  player.health = 0;
  healthBar.style.width = '0%';
  playDeathSfx();
  if (character) {
    character.traverse(c => {
      if (c.isMesh) {
        c.userData._origPos = c.position.clone();
        c.userData._vel = new THREE.Vector3((Math.random() - 0.5) * 6, Math.random() * 4 + 2, (Math.random() - 0.5) * 6);
      }
    });
  }
  player.fallApartUntil = performance.now() + 1200;
  setTimeout(() => {
    if (character) {
      character.traverse(c => {
        if (c.isMesh && c.userData._origPos) {
          c.position.copy(c.userData._origPos);
          delete c.userData._vel; delete c.userData._origPos;
        }
      });
    }
    respawnPlayer();
  }, 1200);
}
function respawnPlayer() {
  player.x = SPAWN.x; player.y = SPAWN.y; player.z = SPAWN.z;
  player.vy = 0; player.health = player.maxHealth; player.dead = false; player.onGround = true;
  healthBar.style.width = '100%';
  healthBar.classList.remove('damaged');
  healthWrap.classList.remove('show');
  characterRoot.position.set(player.x, player.y, player.z);
  characterRoot.rotation.y = player.yaw;
}

const platforms = [];
function addBox(x, y, z, sx, sy, sz, color, receive = true) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(sx, sy, sz),
    new THREE.MeshStandardMaterial({ color, roughness: 0.85 })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = receive;
  scene.add(mesh);
  platforms.push({ x, y, z, sx, sy, sz, mesh, hazard: sx < 2 && sy > 1.5 });
  return mesh;
}

function withLoadTimeout(promise, ms = 5000, label = 'asset') { let timer; return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label + ' load timed out')), ms); })]).finally(() => clearTimeout(timer)); }

async function buildBaseplate() {
  const texLoader = new THREE.TextureLoader();
  let tex = null;
  try {
    tex = await withLoadTimeout(new Promise((res, rej) => texLoader.load(ASSETS.baseplateTex, res, undefined, rej)), 3500, 'Ground texture');
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(24, 24);
    tex.colorSpace = THREE.SRGBColorSpace;
  } catch { tex = null; }
  let loadedObj = false;
  try {
    const obj = await withLoadTimeout(new Promise((res, rej) => new OBJLoader().load(ASSETS.baseplateObj, res, undefined, rej)), 4500, 'Baseplate model');
    const mat = new THREE.MeshStandardMaterial({ color: tex ? 0xffffff : 0x6a6a6a, map: tex, roughness: 0.92, metalness: 0.05 });
    obj.traverse(c => { if (c.isMesh) { c.material = mat; c.receiveShadow = true; } });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3(); box.getSize(size);
    obj.scale.setScalar(80 / (Math.max(size.x, size.z) || 1));
    box.setFromObject(obj);
    obj.position.y -= box.min.y;
    scene.add(obj);
    platforms.push({ x: 0, y: -0.05, z: 0, sx: 80, sy: 0.2, sz: 80, mesh: obj, hazard: false });
    loadedObj = true;
  } catch (e) { console.warn(e); }
  if (!loadedObj) {
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(80, 80),
      new THREE.MeshStandardMaterial({ color: tex ? 0xffffff : 0x4a7a4a, map: tex, roughness: 0.9 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
    platforms.push({ x: 0, y: -0.05, z: 0, sx: 80, sy: 0.1, sz: 80, mesh: ground, hazard: false });
  }
}

function buildObby() {
  [
    [0, 0.5, 10, 5, 1, 4, 0x5a8cc8],
    [0, 1.3, 16, 4, 1, 3.5, 0x5a96d0],
    [4, 2.2, 21, 3.5, 1, 3, 0x64a0c8],
    [7, 3.1, 26, 3, 1, 3, 0x6e96be],
    [3, 4.0, 31, 2.8, 1, 2.8, 0x78a0b4],
    [0, 4.9, 36, 3.2, 1, 3, 0x64aa96],
    [-4, 5.8, 41, 2.6, 1, 2.6, 0x5ab496],
    [-1, 6.7, 46, 2.4, 1, 2.4, 0x50be8c],
    [2, 7.6, 50, 2.8, 1, 2.8, 0x64b482],
    [0, 8.5, 55, 4.5, 1, 4.5, 0xffc850],
  ].forEach(p => addBox(...p));
  addBox(8, 1.8, 22, 1.4, 2.5, 1.4, 0xdc5050);
  addBox(-6, 3.5, 38, 1.4, 2.2, 1.4, 0xdc5050);
}

// Character parts for procedural animation (like Humanoid limbs)
let charParts = { torso: null, head: null, legL: null, legR: null, armL: null, armR: null };
let animState = 'idle'; // idle | walk | jump
let animTime = 0;
let idleAnimLoaded = false;
async function preloadIdleAnim(){ try { const r=await fetch(ASSETS.idleAnim); idleAnimLoaded=r.ok; } catch { idleAnimLoaded=false; } }
preloadIdleAnim();

function applyAvatarColor(root, hex) {
  if (!root) return;
  const col = new THREE.Color(hex || account.avatarColor || '#5b9dff');
  root.traverse(c => {
    if (c.isMesh && c.material) {
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => {
        if (m.color) m.color.copy(col);
        m.needsUpdate = true;
      });
    }
  });
}

/** Apply color to a single named part (or mesh) of the avatar OBJ */
function applyPartColor(root, partName, hex) {
  if (!root || !partName) return;
  const col = new THREE.Color(hex);
  const target = partName.toLowerCase();
  root.traverse(c => {
    const n = (c.name || '').toLowerCase();
    if (!n || !n.includes(target) && n !== target) return;
    if (c.isMesh && c.material) {
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => {
        if (m.color) m.color.copy(col);
        m.needsUpdate = true;
      });
    } else if (c.isGroup || c.isObject3D) {
      c.traverse(ch => {
        if (ch.isMesh && ch.material) {
          const mats = Array.isArray(ch.material) ? ch.material : [ch.material];
          mats.forEach(m => {
            if (m.color) m.color.copy(col);
            m.needsUpdate = true;
          });
        }
      });
    }
  });
}

/** Collect unique named parts from OBJ for per-part coloring */
function getAvatarParts(root) {
  const parts = [];
  const seen = new Set();
  if (!root) return parts;
  root.traverse(c => {
    const n = (c.name || '').trim();
    if (!n || n.length < 2) return;
    const key = n.toLowerCase();
    if (seen.has(key)) return;
    // skip root/generic
    if (['boy','girl','player1','# made with prisma3d','r6 boy','r6_boy','scene','root'].includes(key)) return;
    if (c.isMesh || c.isGroup) {
      seen.add(key);
      parts.push(n);
    }
  });
  return parts;
}

function centerCharacterPivot(model) {
  // Pivot like HumanoidRootPart: centered in XZ, feet on ground (Y=0)
  const box = new THREE.Box3().setFromObject(model);
  const size = new THREE.Vector3();
  box.getSize(size);
  const center = new THREE.Vector3();
  box.getCenter(center);
  // Target height ~2.0 units
  const targetH = 2.0;
  const s = targetH / (size.y || 1);
  model.scale.setScalar(s);
  box.setFromObject(model);
  box.getCenter(center);
  box.getSize(size);
  // Center XZ, put feet at y=0
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= box.min.y;
  return model;
}

function tagCharParts(root) {
  charParts = { torso: null, head: null, legL: null, legR: null, armL: null, armR: null, root: null };
  root.traverse(c => {
    const n = (c.name || '').toLowerCase().replace(/\s+/g, '');
    if (!charParts.root && (n === 'humanoidrootpart' || n === 'r6boy')) charParts.root = c;
    if (!charParts.torso && (n === 'body' || n.includes('torso') || n.includes('chest') || n === 'humanoidrootpart')) charParts.torso = c;
    if (!charParts.head && (n === 'head' || n.includes('face'))) charParts.head = c;
    if (!charParts.legL && (n === 'leftleg' || n.includes('leftleg') || n === 'left leg')) charParts.legL = c;
    if (!charParts.legR && (n === 'rightleg' || n.includes('rightleg') || n === 'right leg')) charParts.legR = c;
    if (!charParts.armL && (n === 'leftarm' || n.includes('leftarm') || n === 'left arm')) charParts.armL = c;
    if (!charParts.armR && (n === 'rightarm' || n.includes('rightarm') || n === 'right arm')) charParts.armR = c;
  });
  // Prefer Body over HumanoidRootPart for torso if both found
  root.traverse(c => {
    const n = (c.name || '').toLowerCase();
    if (n === 'body') charParts.torso = c;
  });
  Object.keys(charParts).forEach(k => {
    const p = charParts[k];
    if (p) {
      p.userData.baseRot = p.rotation.clone();
      p.userData.basePos = p.position.clone();
    }
  });
}

// Animation state machine with smooth blending (reproduces Idle/Walk/Jump.anim intent)
// Note: .anim files are proprietary binary containers; procedural reproduction is used.
let animBlend = { idle: 1, walk: 0, jump: 0 };
const ANIM_BLEND_SPEED = 8.0;

function updateCharacterAnim(dt, moving, onGround) {
  if (!character) return;
  animTime += dt;

  // Target state
  let target = 'idle';
  if (!onGround) target = 'jump';
  else if (moving) target = 'walk';
  animState = target;

  // Soft blend weights
  const targets = { idle: 0, walk: 0, jump: 0 };
  targets[target] = 1;
  for (const k of ['idle', 'walk', 'jump']) {
    animBlend[k] += (targets[k] - animBlend[k]) * Math.min(1, dt * ANIM_BLEND_SPEED);
  }

  const t = animTime;
  const legs = [charParts.legL, charParts.legR].filter(Boolean);
  const arms = [charParts.armL, charParts.armR].filter(Boolean);

  // Idle contribution
  const idleBob = Math.sin(t * 2.2) * 0.018;
  // Walk contribution
  const walkPhase = t * 9.5;
  const walkSwing = Math.sin(walkPhase) * 0.52;
  const walkBob = Math.abs(Math.sin(walkPhase)) * 0.045;
  // Jump contribution
  const jumpLeg = -0.38;
  const jumpArm = -0.55;

  // Apply blended rotations / positions
  if (charParts.torso) {
    const baseX = charParts.torso.userData.baseRot?.x || 0;
    const baseY = charParts.torso.userData.baseRot?.y || 0;
    const basePY = charParts.torso.userData.basePos?.y || 0;
    charParts.torso.rotation.x = baseX
      + idleBob * 0.45 * animBlend.idle
      + Math.sin(walkPhase) * 0.03 * animBlend.walk
      - 0.09 * animBlend.jump;
    charParts.torso.rotation.y = baseY + Math.sin(walkPhase) * 0.035 * animBlend.walk;
    charParts.torso.position.y = basePY
      + Math.abs(idleBob) * 0.28 * animBlend.idle
      + walkBob * animBlend.walk;
  }

  legs.forEach((leg, i) => {
    if (!leg.userData.baseRot) return;
    const sign = i === 0 ? 1 : -1;
    const idle = Math.sin(t * 1.4 + i * Math.PI) * 0.035;
    const walk = walkSwing * sign;
    leg.rotation.x = leg.userData.baseRot.x
      + idle * animBlend.idle
      + walk * animBlend.walk
      + jumpLeg * animBlend.jump;
  });

  arms.forEach((arm, i) => {
    if (!arm.userData.baseRot) return;
    const sign = i === 0 ? -1 : 1;
    const idle = Math.sin(t * 1.15 + i) * 0.05;
    const walk = walkSwing * sign * 0.68;
    arm.rotation.x = arm.userData.baseRot.x
      + idle * animBlend.idle
      + walk * animBlend.walk
      + jumpArm * animBlend.jump;
  });

  // Subtle head look / breathing
  if (charParts.head) {
    const base = charParts.head.userData.baseRot || { x: 0, y: 0, z: 0 };
    charParts.head.rotation.x = base.x + Math.sin(t * 1.8) * 0.02 * animBlend.idle;
  }
}

async function loadCharacter() {
  // clear previous
  if (character) {
    characterRoot.remove(character);
    character = null;
  }
  const gender = (account.gender === 'girl' || account.gender === 'female') ? 'girl' : 'boy';
  const url = gender === 'girl' ? ASSETS.girl : ASSETS.boy;
  const isGltf = /\.gltf$|\.glb$/i.test(url);
  try {
    let model;
    if (isGltf) {
      const gltf = await withLoadTimeout(new Promise((res, rej) => {
        new GLTFLoader().load(url, res, (xhr) => {
          if (xhr.total) document.getElementById('load-prog').style.width = Math.min(90, 55 + (xhr.loaded / xhr.total) * 35) + '%';
        }, rej);
      }), 5500, 'Avatar model');
      model = gltf.scene || gltf.scenes?.[0];
      if (!model) throw new Error('GLTF has no scene');
    } else {
      model = await withLoadTimeout(new Promise((res, rej) => {
        new OBJLoader().load(url, res, (xhr) => {
          if (xhr.total) document.getElementById('load-prog').style.width = Math.min(90, 55 + (xhr.loaded / xhr.total) * 35) + '%';
        }, rej);
      }), 5500, 'Avatar model');
    }
    // Ensure materials exist + shadows; clone mats so part colors are independent
    model.traverse(c => {
      if (c.isMesh) {
        c.castShadow = true;
        c.receiveShadow = true;
        if (!c.material) {
          c.material = new THREE.MeshStandardMaterial({ color: 0x5b9dff, roughness: 0.45, metalness: 0.1 });
        } else {
          c.material = Array.isArray(c.material)
            ? c.material.map(m => (m.clone ? m.clone() : m))
            : (c.material.clone ? c.material.clone() : c.material);
          const mats = Array.isArray(c.material) ? c.material : [c.material];
          mats.forEach(m => {
            if (m.map) m.map.colorSpace = THREE.SRGBColorSpace;
            m.needsUpdate = true;
          });
        }
      }
    });
    character = centerCharacterPivot(model);
    tagCharParts(character);
    // Only tint whole body if no textures / user set a custom color beyond default
    if (account.avatarColor && account.avatarColor !== '#5b9dff') {
      applyAvatarColor(character, account.avatarColor);
    }
    if (account.partColors) {
      Object.entries(account.partColors).forEach(([part, hex]) => applyPartColor(character, part, hex));
    }
    characterRoot.add(character);
  } catch (e) {
    console.warn('Character load failed, using simple avatar', e);
    character = createSimpleAvatar(account.avatarColor || account.chatColor || '#5b9dff');
    centerCharacterPivot(character);
    tagCharParts(character);
    characterRoot.add(character);
  }
}

// Character collision capsule (CanCollide = true — cannot walk through parts)
const CHAR_RADIUS = 0.45;
const CHAR_HEIGHT = 1.85;
const CHAR_STEP = 0.55; // max step-up height

function platformTop(nx, ny, nz) {
  const r = CHAR_RADIUS;
  let best = null;
  for (const p of platforms) {
    if (p.hazard) continue;
    const top = p.y + p.sy / 2;
    if (Math.abs(nx - p.x) < p.sx / 2 + r && Math.abs(nz - p.z) < p.sz / 2 + r) {
      if (ny <= top + 0.5 && ny >= top - 1.0) {
        if (best === null || top > best) best = top;
      }
    }
  }
  return best;
}

/** True if character AABB at (nx,ny,nz) overlaps a solid non-hazard part */
function overlapsSolid(nx, ny, nz) {
  const feet = ny;
  const head = ny + CHAR_HEIGHT;
  const r = CHAR_RADIUS;
  for (const p of platforms) {
    if (p.hazard) continue;
    // thin ground planes: only stand on them, don't treat as side walls if very flat
    const isThinFloor = p.sy <= 0.35;
    const px0 = p.x - p.sx / 2, px1 = p.x + p.sx / 2;
    const pz0 = p.z - p.sz / 2, pz1 = p.z + p.sz / 2;
    const py0 = p.y - p.sy / 2, py1 = p.y + p.sy / 2;
    if (nx + r <= px0 || nx - r >= px1) continue;
    if (nz + r <= pz0 || nz - r >= pz1) continue;
    if (head <= py0 || feet >= py1) continue;
    if (isThinFloor) {
      // only block if trying to sink into the floor volume
      if (feet < py1 && feet > py0 - 0.05 && head > py1) continue; // standing on top ok
      if (feet >= py1 - 0.02) continue;
    }
    return true;
  }
  return false;
}

/** Resolve horizontal move so character cannot go through parts */
function resolveMove(fromX, fromZ, toX, toZ, y) {
  // try full move
  if (!overlapsSolid(toX, y, toZ)) return { x: toX, z: toZ };
  // try X only
  if (!overlapsSolid(toX, y, fromZ)) return { x: toX, z: fromZ };
  // try Z only
  if (!overlapsSolid(fromX, y, toZ)) return { x: fromX, z: toZ };
  // blocked
  return { x: fromX, z: fromZ };
}

function nearHazard(nx, nz) {
  for (const p of platforms) {
    if (!p.hazard) continue;
    if (Math.abs(nx - p.x) < p.sx / 2 + CHAR_RADIUS && Math.abs(nz - p.z) < p.sz / 2 + CHAR_RADIUS) {
      if (player.y < p.y + p.sy / 2 + 0.5 && player.y > p.y - p.sy / 2 - 0.3) return true;
    }
  }
  return false;
}

const MOVE_SPEED = 7, JUMP_SPEED = 10, GRAVITY = 24;
let showJoystick = account.settings.joystick !== false;


function checkPlayTimeReward() {
  if (!gameRunning || playRewardGranted || account.playRewardClaimed) return;
  if (!playSessionStart) return;
  const mins = (performance.now() - playSessionStart) / 60000;
  if (mins >= 20) {
    playRewardGranted = true;
    account.playRewardClaimed = true;
    addTx('First 20-minute play reward', 20);
    updateDlexUI();
    try {
      const tip = document.createElement('div');
      tip.className = 'play-reward-toast';
      tip.textContent = '+20 Dlex for playing 20 minutes!';
      document.body.appendChild(tip);
      setTimeout(() => tip.remove(), 4000);
    } catch {}
  }
}
function updatePlayer(dt) {
  if (player.dead) {
    try { playWalkSfx(false, false); } catch(_){}
    if (character && performance.now() < player.fallApartUntil) {
      character.traverse(c => {
        if (c.isMesh && c.userData._vel) {
          c.position.x += c.userData._vel.x * dt;
          c.position.y += c.userData._vel.y * dt;
          c.position.z += c.userData._vel.z * dt;
          c.userData._vel.y -= GRAVITY * dt * 0.5;
        }
      });
    }
    characterRoot.position.set(player.x, player.y, player.z);
    return;
  }

  let fx = 0, fz = 0;
  // Keyboard relative to camera
  if (keys['KeyW'] || keys['ArrowUp']) fz += 1;
  if (keys['KeyS'] || keys['ArrowDown']) fz -= 1;
  if (keys['KeyA'] || keys['ArrowLeft']) fx -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) fx += 1;

  // Joystick NOT inverted:
  // Screen Up → forward (away from camera), Down → back, Left/Right → strafe
  if (joyActive) {
    fx += joyDX;        // right = +1
    fz += -joyDY;       // up (negative screen dy) → +forward
  }

  const mag = Math.hypot(fx, fz);
  if (mag > 1) { fx /= mag; fz /= mag; }
  const moving = mag > 0.08;
  try { playWalkSfx(moving, !!player.onGround); } catch(_){}

  // Movement relative to CAMERA: joystick up = into the screen (camera look dir).
  // Camera sits at offset (sin(yaw), cos(yaw)); look dir is the opposite.
  const sy = Math.sin(camYaw);
  const cy = Math.cos(camYaw);
  // right = (cy, -sy), forward = (-sy, -cy)
  const mx = fx * cy + fz * (-sy);
  const mz = fx * (-sy) + fz * (-cy);

  // Horizontal move with solid collision (CanCollide = true)
  const step = MOVE_SPEED * dt;
  const wantX = player.x + mx * step;
  const wantZ = player.z + mz * step;
  // Allow small step-up onto ledges while moving
  let moveY = player.y;
  const stepTop = platformTop(wantX, player.y + CHAR_STEP, wantZ);
  if (stepTop !== null && stepTop > player.y && stepTop - player.y <= CHAR_STEP && player.onGround) {
    moveY = stepTop;
  }
  const resolved = resolveMove(player.x, player.z, wantX, wantZ, moveY);
  player.x = resolved.x;
  player.z = resolved.z;
  if (moveY > player.y) player.y = moveY;

  // Vertical gravity + floor / ceiling collision
  player.vy -= GRAVITY * dt;
  const nextY = player.y + player.vy * dt;

  // Ceiling: hit underside of solid parts
  if (player.vy > 0) {
    const head = nextY + CHAR_HEIGHT;
    let hitCeil = null;
    for (const p of platforms) {
      if (p.hazard || p.sy <= 0.35) continue;
      const py0 = p.y - p.sy / 2;
      if (Math.abs(player.x - p.x) < p.sx / 2 + CHAR_RADIUS &&
          Math.abs(player.z - p.z) < p.sz / 2 + CHAR_RADIUS) {
        if (player.y + CHAR_HEIGHT <= py0 + 0.05 && head > py0) {
          if (hitCeil === null || py0 < hitCeil) hitCeil = py0;
        }
      }
    }
    if (hitCeil !== null) {
      player.y = hitCeil - CHAR_HEIGHT;
      player.vy = 0;
    } else {
      player.y = nextY;
    }
  } else {
    player.y = nextY;
  }

  const top = platformTop(player.x, player.y, player.z);
  if (top !== null && player.vy <= 0) {
    player.y = top;
    player.vy = 0;
    player.onGround = true;
  } else if (player.y < -5) {
    takeDamage(player.health + 1);
  } else {
    player.onGround = false;
  }

  // Push out if somehow embedded in a solid
  if (overlapsSolid(player.x, player.y, player.z)) {
    const dirs = [[0.2,0],[-0.2,0],[0,0.2],[0,-0.2],[0.3,0.3],[-0.3,0.3],[0.3,-0.3],[-0.3,-0.3]];
    for (const [dx, dz] of dirs) {
      if (!overlapsSolid(player.x + dx, player.y, player.z + dz)) {
        player.x += dx; player.z += dz; break;
      }
    }
  }

  if (nearHazard(player.x, player.z)) {
    const now = performance.now();
    if (now - lastHazardHit > 600) {
      lastHazardHit = now;
      takeDamage(15);
    }
  }

  // Character faces joystick/move direction; camera stays independent
  if (moving) {
    const moveYaw = Math.atan2(mx, mz);
    let dyaw = moveYaw - characterRoot.rotation.y;
    while (dyaw > Math.PI) dyaw -= Math.PI * 2;
    while (dyaw < -Math.PI) dyaw += Math.PI * 2;
    characterRoot.rotation.y += dyaw * Math.min(1, 14 * dt);
    player.yaw = characterRoot.rotation.y; // sync for multiplayer
  }
  characterRoot.position.set(player.x, player.y, player.z);
  nameTag.visible = account.settings.showNames !== false;

  // Idle / Walk / Jump animations (always driven)
  updateCharacterAnim(dt, moving, player.onGround);

  // Hold-to-jump: keep jumping while button held and on ground
  if (jumpHeld) doJump();

  checkPlayTimeReward();
  pushPlayerState();
}

function updateCamera() {
  const pitch = camPitch, dist = camDist;
  const ox = Math.sin(camYaw) * Math.cos(pitch) * dist;
  const oy = -Math.sin(pitch) * dist + 1.6;
  const oz = Math.cos(camYaw) * Math.cos(pitch) * dist;
  camera.position.set(player.x + ox, player.y + oy, player.z + oz);
  camera.lookAt(player.x, player.y + 1.4, player.z);
}

let jumpHeld = false;
let joyPointerId = null;   // finger controlling joystick
let jumpPointerId = null;  // finger holding jump
let lookPointerId = null;  // finger controlling camera look

function doJump() {
  if (player.onGround && !player.dead) {
    player.vy = JUMP_SPEED;
    player.onGround = false;
  }
}

// Input
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Space') { e.preventDefault(); jumpHeld = true; doJump(); }
  if (studioOpen && (e.ctrlKey || e.metaKey) && e.code === 'KeyZ' && !e.shiftKey) { e.preventDefault(); studioUndo(); }
  if (studioOpen && (e.ctrlKey || e.metaKey) && (e.code === 'KeyY' || (e.code === 'KeyZ' && e.shiftKey))) { e.preventDefault(); studioRedo(); }
  if (e.code === 'Escape' && gameRunning) toggleMenu();
  if (e.code === 'Enter' && gameRunning) {
    const inp = document.getElementById('chat-input');
    if (document.activeElement !== inp) { inp.focus(); e.preventDefault(); }
  }
});
window.addEventListener('keyup', e => {
  keys[e.code] = false;
  if (e.code === 'Space') jumpHeld = false;
});

const sens = () => (account.settings.sensitivity || 1) * 0.005;

// Mouse look (desktop) — independent of touch joystick/jump
canvas.addEventListener('pointerdown', e => {
  if (!gameRunning || menuOpen) return;
  if (e.pointerType === 'touch') return;
  pointerLook = true;
  lookPointerId = e.pointerId;
  lastPX = e.clientX; lastPY = e.clientY;
  canvas.setPointerCapture?.(e.pointerId);
});
canvas.addEventListener('pointermove', e => {
  if (!pointerLook || !gameRunning || menuOpen) return;
  if (lookPointerId != null && e.pointerId !== lookPointerId) return;
  if (e.pointerType === 'touch') return;
  const dx = e.clientX - lastPX, dy = e.clientY - lastPY;
  lastPX = e.clientX; lastPY = e.clientY;
  camYaw -= dx * sens();
  camPitch = Math.max(-1.2, Math.min(0.4, camPitch - dy * sens() * 0.8));
});
canvas.addEventListener('pointerup', e => {
  if (lookPointerId === e.pointerId) { pointerLook = false; lookPointerId = null; }
});
canvas.addEventListener('pointercancel', e => {
  if (lookPointerId === e.pointerId) { pointerLook = false; lookPointerId = null; }
});
canvas.addEventListener('wheel', e => {
  if (!gameRunning) return;
  e.preventDefault();
  camDist = Math.max(CAM_MIN, Math.min(CAM_MAX, camDist + e.deltaY * 0.01));
}, { passive: false });

// Multitouch camera look — works WHILE joystick + jump are held
const activeTouches = new Map();
function isInJoyZone(x, y) {
  const w = window.innerWidth || 1;
  const h = window.innerHeight || 1;
  return x < w * 0.42 && y > h * 0.45;
}
function isInJumpZone(x, y) {
  const w = window.innerWidth || 1;
  const h = window.innerHeight || 1;
  return x > w * 0.68 && y > h * 0.62;
}

canvas.addEventListener('touchstart', e => {
  if (!gameRunning || menuOpen) return;
  for (const t of e.changedTouches) {
    if (t.identifier === joyPointerId || t.identifier === jumpPointerId) continue;
    if (isInJoyZone(t.clientX, t.clientY)) continue;
    if (isInJumpZone(t.clientX, t.clientY)) continue;
    activeTouches.set(t.identifier, { x: t.clientX, y: t.clientY });
  }
  if (activeTouches.size >= 2) {
    pinchActive = true;
    const pts = [...activeTouches.values()];
    pinchStartDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    pinchStartCam = camDist;
    pointerLook = false;
    lookPointerId = null;
  } else if (activeTouches.size === 1) {
    const id = [...activeTouches.keys()][0];
    const r = activeTouches.get(id);
    pointerLook = true;
    lookPointerId = id;
    lastPX = r.x; lastPY = r.y;
  }
}, { passive: true });

canvas.addEventListener('touchmove', e => {
  if (!gameRunning || menuOpen) return;
  let used = false;
  for (const t of e.changedTouches) {
    if (t.identifier === joyPointerId || t.identifier === jumpPointerId) continue;
    if (activeTouches.has(t.identifier)) {
      activeTouches.set(t.identifier, { x: t.clientX, y: t.clientY });
      used = true;
    }
  }
  if (!used && !pinchActive) return;
  e.preventDefault();
  if (pinchActive && activeTouches.size >= 2) {
    const pts = [...activeTouches.values()];
    const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    if (pinchStartDist > 0) camDist = Math.max(CAM_MIN, Math.min(CAM_MAX, pinchStartCam * (pinchStartDist / dist)));
  } else if (pointerLook && lookPointerId != null && activeTouches.has(lookPointerId)) {
    const r = activeTouches.get(lookPointerId);
    const dx = r.x - lastPX, dy = r.y - lastPY;
    lastPX = r.x; lastPY = r.y;
    camYaw -= dx * sens();
    camPitch = Math.max(-1.2, Math.min(0.4, camPitch - dy * sens() * 0.8));
  }
}, { passive: false });

canvas.addEventListener('touchend', e => {
  for (const t of e.changedTouches) {
    activeTouches.delete(t.identifier);
    if (lookPointerId === t.identifier) {
      pointerLook = false;
      lookPointerId = null;
    }
  }
  if (activeTouches.size < 2) pinchActive = false;
  if (!pointerLook && activeTouches.size === 1) {
    const id = [...activeTouches.keys()][0];
    const r = activeTouches.get(id);
    pointerLook = true;
    lookPointerId = id;
    lastPX = r.x; lastPY = r.y;
  }
});
canvas.addEventListener('touchcancel', e => {
  for (const t of e.changedTouches) {
    activeTouches.delete(t.identifier);
    if (lookPointerId === t.identifier) lookPointerId = null;
  }
  pinchActive = false;
  if (activeTouches.size === 0) pointerLook = false;
});

// Jump button — tracked by pointerId so other fingers don't release it
const jumpBtn = document.getElementById('jump-btn');
function jumpPress(e) {
  e.preventDefault(); e.stopPropagation();
  if (e.pointerId != null) {
    jumpPointerId = e.pointerId;
    try { jumpBtn?.setPointerCapture?.(e.pointerId); } catch {}
  }
  jumpHeld = true;
  jumpBtn?.classList.add('held');
  doJump();
}
function jumpRelease(e) {
  if (e && e.pointerId != null && jumpPointerId != null && e.pointerId !== jumpPointerId) return;
  if (e) { e.preventDefault(); e.stopPropagation(); }
  jumpHeld = false;
  jumpPointerId = null;
  jumpBtn?.classList.remove('held');
}
jumpBtn?.addEventListener('pointerdown', jumpPress);
jumpBtn?.addEventListener('pointerup', jumpRelease);
jumpBtn?.addEventListener('pointercancel', jumpRelease);
jumpBtn?.addEventListener('lostpointercapture', jumpRelease);

['menu-toggle', 'chat-toggle', 'jump-btn'].forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('touchmove', e => { e.preventDefault(); e.stopPropagation(); }, { passive: false });
});

// ===== JOYSTICK (multitouch-safe) =====
const joyZone = document.getElementById('joystick-zone');
const joyBase = document.getElementById('joystick-base');
const joyKnob = document.getElementById('joystick-knob');
let JOY_R = 45;

function updateJoyRadius() {
  const rect = joyBase.getBoundingClientRect();
  JOY_R = Math.min(rect.width, rect.height) * 0.38;
}

function setKnob(dx, dy) {
  joyKnob.style.left = '50%';
  joyKnob.style.top = '50%';
  joyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
}

function updateJoy(cx, cy) {
  const rect = joyBase.getBoundingClientRect();
  const cx0 = rect.left + rect.width / 2;
  const cy0 = rect.top + rect.height / 2;
  let dx = cx - cx0;
  let dy = cy - cy0;
  const m = Math.hypot(dx, dy);
  if (m > JOY_R) {
    dx = (dx / m) * JOY_R;
    dy = (dy / m) * JOY_R;
  }
  setKnob(dx, dy);
  joyDX = dx / JOY_R;
  joyDY = dy / JOY_R;
}

function joyEnd(pointerId) {
  if (pointerId != null && joyPointerId != null && pointerId !== joyPointerId) return;
  joyActive = false;
  joyPointerId = null;
  joyDX = 0;
  joyDY = 0;
  joyKnob.style.left = '50%';
  joyKnob.style.top = '50%';
  joyKnob.style.transform = 'translate(-50%, -50%)';
}

joyZone.addEventListener('pointerdown', e => {
  if (!gameRunning || menuOpen || !showJoystick) return;
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  // Only one joystick finger
  if (joyPointerId != null && e.pointerId !== joyPointerId) return;
  e.preventDefault();
  e.stopPropagation();
  joyActive = true;
  joyPointerId = e.pointerId;
  updateJoyRadius();
  updateJoy(e.clientX, e.clientY);
  try { joyZone.setPointerCapture?.(e.pointerId); } catch {}
});
joyZone.addEventListener('pointermove', e => {
  if (!joyActive || e.pointerId !== joyPointerId) return;
  e.preventDefault();
  e.stopPropagation();
  updateJoy(e.clientX, e.clientY);
});
joyZone.addEventListener('pointerup', e => {
  e.preventDefault();
  e.stopPropagation();
  joyEnd(e.pointerId);
});
joyZone.addEventListener('pointercancel', e => { joyEnd(e.pointerId); });
joyZone.addEventListener('lostpointercapture', e => { joyEnd(e.pointerId); });

// Chat UI
document.getElementById('chat-send').onclick = () => {
  const inp = document.getElementById('chat-input');
  sendChat(inp.value);
  inp.value = '';
  inp.blur();
};
document.getElementById('chat-input').addEventListener('keydown', e => {
  if (e.code === 'Enter') {
    e.preventDefault();
    sendChat(e.target.value);
    e.target.value = '';
    e.target.blur();
  }
  e.stopPropagation();
});

// Voice to text
let recognition = null;
const micBtn = document.getElementById('chat-mic');
micBtn.onclick = () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { alert('Voice input not supported in this browser'); return; }
  if (recognition) {
    recognition.stop();
    recognition = null;
    micBtn.classList.remove('listening');
    return;
  }
  recognition = new SR();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onresult = (ev) => {
    const text = ev.results[0][0].transcript;
    document.getElementById('chat-input').value = text;
    sendChat(text);
    document.getElementById('chat-input').value = '';
  };
  recognition.onerror = () => { micBtn.classList.remove('listening'); recognition = null; };
  recognition.onend = () => { micBtn.classList.remove('listening'); recognition = null; };
  micBtn.classList.add('listening');
  recognition.start();
};

// Menu (Roblox-style People / Settings / Report / Help)
let gameRunning = false;
let playSessionStart = 0;
let playRewardGranted = false;
let menuOpen = false;
function fillGameMenuPlayers() {
  const list = document.getElementById('gm-player-list');
  if (!list) return;
  const remote = (typeof remotePlayers !== 'undefined' && remotePlayers) ? [...remotePlayers.values()] : [];
  let html = `
    <div class="gm-player-row">
      <div class="gm-player-avatar-wrap">
        <img src="${ASSETS.profilePic || ASSETS.dolex}" alt="" onerror="this.src='${ASSETS.dolex}'"/>
        <span class="friend-status-dot online"></span>
      </div>
      <div class="gm-player-meta">
        <strong>${escapeHtml(account.username || 'You')}</strong>
        <span class="muted">@${escapeHtml((account.username || 'player').toLowerCase())}</span>
      </div>
      <span class="muted" style="font-size:0.75rem">You</span>
    </div>`;
  remote.forEach(p => {
    const name = p.username || p.name || 'Player';
    html += `
      <div class="gm-player-row">
        <div class="gm-player-avatar-wrap">
          <img src="${ASSETS.profilePic || ASSETS.dolex}" alt="" onerror="this.src='${ASSETS.dolex}'"/>
          <span class="friend-status-dot online"></span>
        </div>
        <div class="gm-player-meta">
          <strong>${escapeHtml(name)}</strong>
          <span class="muted">@${escapeHtml(String(name).toLowerCase())}</span>
        </div>
        <button class="btn btn-dark gm-add-friend" data-name="${escapeHtml(name)}" style="padding:6px 10px;font-size:0.78rem">Add Friend</button>
      </div>`;
  });
  if (!remote.length) {
    html += `<p class="muted" style="padding:12px 4px;font-size:0.85rem">No other players in this server yet.</p>`;
  }
  list.innerHTML = html;
  list.querySelectorAll('.gm-add-friend').forEach(btn => {
    btn.onclick = () => {
      const n = btn.dataset.name;
      if (!account.friends) account.friends = [];
      if (!account.friends.includes(n)) {
        account.friends.push(n);
        save(account);
        btn.textContent = 'Friends';
        btn.disabled = true;
      }
    };
  });
}
function toggleMenu() {
  menuOpen = !menuOpen;
  document.getElementById('game-menu').classList.toggle('open', menuOpen);
  if (menuOpen) fillGameMenuPlayers();
}
document.getElementById('menu-toggle').onclick = toggleMenu;
document.getElementById('chat-toggle')?.addEventListener('click', () => {
  const panel = document.getElementById('chat-panel');
  panel.classList.toggle('hidden');
});
document.querySelectorAll('.gm-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.gm-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const id = tab.dataset.gmTab;
    document.querySelectorAll('.gm-panel').forEach(p => p.classList.add('hidden'));
    const panel = document.getElementById('gm-panel-' + id);
    if (panel) panel.classList.remove('hidden');
  });
});
function closeGameMenu() {
  menuOpen = false;
  document.getElementById('game-menu').classList.remove('open');
}
document.getElementById('menu-resume')?.addEventListener('click', closeGameMenu);
document.getElementById('menu-resume-x')?.addEventListener('click', closeGameMenu);
document.getElementById('menu-resume-help')?.addEventListener('click', closeGameMenu);
document.getElementById('menu-respawn')?.addEventListener('click', () => {
  closeGameMenu();
  respawnPlayer();
});
document.getElementById('menu-invite')?.addEventListener('click', () => {
  const url = location.href;
  if (navigator.share) navigator.share({ title: 'DoLex', url }).catch(() => {});
  else if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => alert('Invite link copied!')).catch(() => alert(url));
  else alert(url);
});
document.getElementById('menu-close')?.addEventListener('click', () => {
  closeGameMenu();
  endGame();
});
document.getElementById('gm-report-btn')?.addEventListener('click', () => {
  alert('Report submitted. Thank you for helping keep DoLex safe.');
});

document.getElementById('set-joystick').onchange = (e) => {
  showJoystick = e.target.checked;
  account.settings.joystick = showJoystick;
  save(account);
  joyBase.style.display = showJoystick && gameRunning ? 'block' : 'none';
};
document.getElementById('set-sound').onchange = (e) => { account.settings.sound = e.target.checked; save(account); };
document.getElementById('set-music').onchange = (e) => { account.settings.music = e.target.checked; save(account); };
document.getElementById('set-chat').onchange = (e) => {
  account.settings.chat = e.target.checked;
  save(account);
  document.getElementById('chat-panel').classList.toggle('hidden', !e.target.checked);
};
document.getElementById('set-theme').onchange = (e) => applyTheme(e.target.value);
document.getElementById('set-volume')?.addEventListener('input', (e) => {
  account.settings.volume = parseFloat(e.target.value);
  save(account);
});
document.getElementById('set-music-vol')?.addEventListener('input', (e) => {
  account.settings.musicVol = parseFloat(e.target.value);
  save(account);
});
document.getElementById('set-qol')?.addEventListener('input', (e) => {
  account.settings.qol = parseInt(e.target.value, 10);
  save(account);
  applyQol(account.settings.qol);
});

/** Home / lobby = Portrait · 3D in-game = Landscape */
function lockOrientation(mode) {
  document.documentElement.classList.toggle('mode-portrait', mode === 'portrait');
  document.documentElement.classList.toggle('mode-landscape', mode === 'landscape');
  document.body.classList.toggle('mode-portrait', mode === 'portrait');
  document.body.classList.toggle('mode-landscape', mode === 'landscape');
  const hint = document.getElementById('orient-hint');
  if (hint) {
    hint.classList.toggle('hint-portrait', mode === 'portrait');
    hint.classList.toggle('hint-landscape', mode === 'landscape');
    const title = document.getElementById('orient-hint-title');
    const sub = document.getElementById('orient-hint-sub');
    if (mode === 'portrait') {
      if (title) title.textContent = 'Rotate to Portrait';
      if (sub) sub.textContent = 'Home screen works best in portrait mode.';
    } else {
      if (title) title.textContent = 'Rotate to Landscape';
      if (sub) sub.textContent = 'Play in landscape for the best 3D view.';
    }
  }
  const orient = screen.orientation;
  if (orient && typeof orient.lock === 'function') {
    const target = mode === 'landscape' ? 'landscape' : 'portrait';
    orient.lock(target).catch(() => {
      try { orient.lock(target + '-primary').catch(() => {}); } catch (_) {}
    });
  }
  resizeRenderer();
}

function resizeRenderer() {
  const w = window.innerWidth, h = window.innerHeight;
  if (typeof camera !== 'undefined' && camera) {
    camera.aspect = w / Math.max(h, 1);
    camera.updateProjectionMatrix();
  }
  if (typeof renderer !== 'undefined' && renderer) renderer.setSize(w, h);
}

function applyGameSkyTexture() {
  try {
    const loader = new THREE.TextureLoader();
    loader.load('Assets/Skyboxes/Sky_Clouds.jpg', (tex) => {
      tex.mapping = THREE.EquirectangularReflectionMapping;
      tex.colorSpace = THREE.SRGBColorSpace || THREE.sRGBEncoding;
      scene.background = tex;
      scene.environment = tex;
      if (scene.fog) scene.fog.color.set(0xa8c8e8);
    }, undefined, () => {
      scene.background = new THREE.Color(0x87ceeb);
    });
  } catch (_) {
    scene.background = new THREE.Color(0x87ceeb);
  }
}

function startGame() {
  // Offline-friendly: always play locally. Multiplayer joins when online.
  stopAvatarPreview();
  account.game_visits = (account.game_visits || 0) + 1;
  save(account);
  showJoiningScreen('Joining Experience…', 'Loading 3D world…');
  document.getElementById('ui-root').style.display = 'none';
  document.getElementById('hud').classList.add('active');
  document.getElementById('loading-screen').classList.remove('hidden');
  const online = checkBrowserOnline() && netConnected;
  document.getElementById('load-status').textContent = online
    ? "Joining public 3D game…"
    : "Starting offline 3D world…";
  document.getElementById('load-prog').style.width = '100%';

  // Mark play mode so CSS never hides the WebGL canvas (portrait/landscape lock)
  document.body.classList.add('playing-3d');
  document.body.classList.add('mode-landscape');
  try { document.getElementById('loading-screen')?.classList.add('hidden'); } catch (_) {}
  try { document.getElementById('joining-overlay')?.classList.add('hidden'); } catch (_) {}
  try { document.getElementById('ui-root').style.display = 'none'; } catch (_) {}
  document.body.classList.remove('mode-portrait');
  try { lockOrientation('landscape'); } catch (_) {}

  // Ensure baseplate / platforms visible
  try {
    platforms.forEach(p => {
      if (p.mesh && !p._hiddenForCustom) p.mesh.visible = true;
    });
  } catch (_) {}

  // Ensure character exists + face texture applied
  const ensureChar = (async () => {
    if (!character) {
      try { await loadCharacter(); } catch (_) {}
    }
    if (character) {
      try { applyEquippedAccessoriesToModel(character); } catch (_) {}
      character.visible = true;
      characterRoot.visible = true;
    }
    // If still no character, build simple fallback so world is never empty
    if (!character) {
      try {
        character = createSimpleAvatar(account.avatarColor || '#5b9dff');
        characterRoot.add(character);
        character.visible = true;
        characterRoot.visible = true;
      } catch (_) {}
    }
  })();

  applyGameSkyTexture();
  dayNightTime = 0.45; // noon-ish lighting under sky texture
  window.__useSkyTexture = true;

  respawnPlayer();
  player.yaw = 0;
  updateDlexUI();
  try {
    drawNameTag(account.username);
    if (typeof nameTagTex !== 'undefined') nameTagTex.needsUpdate = true;
  } catch (_) {}
  document.getElementById('chat-messages').innerHTML = '';
  document.getElementById('chat-panel').classList.toggle('hidden', account.settings.chat === false);

  subscribePlayers();

  // Enter game as soon as character is ready (or timeout)
  Promise.race([ensureChar, new Promise(r => setTimeout(r, 900))]).then(() => {
    document.getElementById('loading-screen').classList.add('hidden');
    hideJoiningScreen();
    gameRunning = true;
    playSessionStart = performance.now();
    playRewardGranted = !!account.playRewardClaimed;
    showJoystick = account.settings.joystick !== false;
    joyBase.style.display = showJoystick ? 'block' : 'none';
    const sj = document.getElementById('set-joystick');
    if (sj) sj.checked = showJoystick;
    const ss = document.getElementById('set-sound');
    if (ss) ss.checked = account.settings.sound !== false;
    const sm = document.getElementById('set-music');
    if (sm) sm.checked = !!account.settings.music;
    try { syncBgMusic(); } catch(_){}
    const sc = document.getElementById('set-chat');
    if (sc) sc.checked = account.settings.chat !== false;
    const st = document.getElementById('set-theme');
    if (st) st.value = account.settings.theme || 'light';
    if (gun && netConnected) {
      gun.get('dolex').get('presence').get(account.user_id).put({
        id: account.user_id, username: account.username, color: account.chatColor, inGame: true, t: Date.now()
      });
    }
    recountPresence();
    resizeRenderer();
    try { updateCamera(); } catch (_) {}
    if (canvas) {
      canvas.style.visibility = 'visible';
      canvas.style.opacity = '1';
      canvas.style.display = 'block';
      canvas.style.zIndex = '1';
      canvas.style.pointerEvents = 'auto';
    }
    // Force a few frames so first paint shows world + character
    try {
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.render(scene, camera);
    } catch (_) {}
  });
}

function endGame() {
  gameRunning = false;
  menuOpen = false;
  window.__useSkyTexture = false;
  document.body.classList.remove('playing-3d');
  hideJoiningScreen();
  try { lockOrientation('portrait'); } catch (_) {}
  try { playWalkSfx(false, false); } catch(_){}
  try { syncBgMusic(); } catch(_){}
  // restore default map if we were in a published game
  if (activePublishedGame) {
    platforms.forEach(p => {
      if (p._hiddenForCustom && p.mesh) { p.mesh.visible = true; delete p._hiddenForCustom; }
    });
    clearCustomMap();
    if (typeof SPAWN !== 'undefined') { SPAWN.x = 0; SPAWN.y = 2; SPAWN.z = 0; }
    activePublishedGame = null;
  }
  leaveMultiplayerPresence();
  clearRemotePlayers();
  if (gun) {
    gun.get('dolex').get('presence').get(account.user_id).put({
      id: account.user_id, username: account.username, color: account.chatColor, inGame: false, t: Date.now()
    });
  }
  document.getElementById('hud').classList.remove('active');
  document.getElementById('game-menu').classList.remove('open');
  document.getElementById('ui-root').style.display = '';
  document.body.classList.add('mode-portrait');
  document.body.classList.remove('mode-landscape');
  try { lockOrientation('portrait'); } catch (_) {}
  showScreen('lobby');
  renderHome();
  recountPresence();
  resizeRenderer();
}

document.getElementById('btn-play').onclick = startGame;

window.addEventListener('online', () => {
  hideOfflineGate();
  connectNetwork();
});
window.addEventListener('offline', () => {
  if (gameRunning) showDisconnect('Internet connection lost', ERROR_CODES.OFFLINE);
  else showOfflineGate('Internet connection lost.');
  leaveMultiplayerPresence();
  stopHeartbeat();
});

window.addEventListener('resize', () => {
  resizeRenderer();
});

window.addEventListener('orientationchange', () => {
  setTimeout(resizeRenderer, 100);
});

window.addEventListener('beforeunload', () => {
  leaveMultiplayerPresence();
});

let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  updateDayNight(dt);

  // Always simulate local player when in-game (online or offline)
  if (gameRunning && !menuOpen) {
    updatePlayer(dt);
    updateCamera();
    updateChatBubbles(now);
    if (now - lastRegen > 1000) {
      lastRegen = now;
      if (player.health < player.maxHealth && player.health > 0 && !player.dead) setHealth(player.health + 2);
    }
    if (player.health >= player.maxHealth && now > healthVisibleUntil) healthWrap.classList.remove('show');
    if (now > damageFxUntil) damageFx.classList.remove('show');
  } else if (!gameRunning) {
    camera.position.set(8, 6, 12);
    camera.lookAt(0, 1, 0);
  }

  // Keep canvas visible while HUD is active
  if (gameRunning && canvas) {
    canvas.style.visibility = 'visible';
    canvas.style.display = 'block';
  }

  renderer.render(scene, camera);
}

// ===================== DLStudio =====================
let studioOpen = false;
let studioRenderer = null, studioScene = null, studioCam = null, studioAnim = null;
let studioSelected = null;
let studioTool = 'select'; // select | move | scale | rotate
let studioObjects = []; // { id, name, className, mesh, canCollide }
let studioGameIndex = null;
let studioDrag = null;
let studioGizmo = null;
let studioOrbit = null;
let studioTransform = null;
let studioPlaying = false;
let studioPlayerMesh = null;
let studioJoyActive = false, studioJoyDX = 0, studioJoyDY = 0;
let studioSelectionBox = null;
let studioClock = new THREE.Clock();
let studioClipboard = null;
let studioUndoStack = [];
let studioRedoStack = [];
const STUDIO_UNDO_MAX = 40;

function studioSnapshot() {
  return studioObjects.map(o => ({
    id: o.id, name: o.name, className: o.className, shape: o.shape || o.className,
    x: o.mesh.position.x, y: o.mesh.position.y, z: o.mesh.position.z,
    sx: o.mesh.scale.x, sy: o.mesh.scale.y, sz: o.mesh.scale.z,
    ry: o.mesh.rotation.y,
    color: o.mesh.material?.color?.getHex?.() || 0x9a9a9a,
    canCollide: o.canCollide !== false, anchored: o.anchored !== false,
    // Persist special assets so publish keeps them
    textContent: o.textContent || null,
    textColor: o.textColor || null,
    decalId: o.decalId || null,
    decalDataUrl: o.decalDataUrl || null,
    modelId: o.modelId || null,
    modelDataUrl: o.modelDataUrl || null,
    modelMime: o.modelMime || null
  }));
}

function studioPushUndo() {
  studioUndoStack.push(studioSnapshot());
  if (studioUndoStack.length > STUDIO_UNDO_MAX) studioUndoStack.shift();
  studioRedoStack = [];
}


function rebuildStudioObjectFromPd(pd) {
  // Returns { mesh, meta } handling plain parts, 3D text, decals, models
  const cls = pd.className || pd.shape || 'Part';
  if (pd.textContent) {
    // Placeholder box until font loads; then replace geometry
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1, 0.5, 0.2),
      new THREE.MeshStandardMaterial({ color: pd.textColor || pd.color || 0xffffff, roughness: 0.45 })
    );
    mesh.scale.set(pd.sx || 1, pd.sy || 1, pd.sz || 1);
    mesh.position.set(pd.x || 0, pd.y || 1, pd.z || 0);
    mesh.rotation.y = pd.ry || 0;
    try {
      const loader = new THREE.FontLoader();
      loader.load('https://cdn.jsdelivr.net/npm/three@0.160.0/examples/fonts/helvetiker_bold.typeface.json', font => {
        const geo = new TextGeometry(pd.textContent, {
          font, size: 0.65, height: 0.18, curveSegments: 6,
          bevelEnabled: true, bevelThickness: 0.025, bevelSize: 0.018, bevelSegments: 2
        });
        geo.center();
        mesh.geometry.dispose();
        mesh.geometry = geo;
      });
    } catch {}
    return {
      mesh,
      meta: {
        textContent: pd.textContent,
        textColor: pd.textColor || '#ffffff'
      }
    };
  }
  if (pd.decalDataUrl || pd.decalId) {
    const geo = new THREE.PlaneGeometry(2, 2);
    const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.scale.set(pd.sx || 1, pd.sy || 1, pd.sz || 1);
    mesh.position.set(pd.x || 0, pd.y || 1.5, pd.z || 0);
    mesh.rotation.y = pd.ry || 0;
    if (pd.decalDataUrl) {
      try {
        const loader = new THREE.TextureLoader();
        loader.load(pd.decalDataUrl, (tex) => {
          tex.colorSpace = THREE.SRGBColorSpace;
          mat.map = tex;
          mat.needsUpdate = true;
        });
      } catch {}
    }
    return {
      mesh,
      meta: { decalId: pd.decalId, decalDataUrl: pd.decalDataUrl }
    };
  }
  if (pd.modelId || pd.modelDataUrl) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.5, 1.5, 1.5),
      new THREE.MeshStandardMaterial({ color: 0x6a8cff, roughness: 0.5 })
    );
    mesh.scale.set(pd.sx || 1, pd.sy || 1, pd.sz || 1);
    mesh.position.set(pd.x || 0, pd.y || 0.75, pd.z || 0);
    mesh.rotation.y = pd.ry || 0;
    return {
      mesh,
      meta: {
        modelId: pd.modelId,
        modelDataUrl: pd.modelDataUrl,
        modelMime: pd.modelMime
      }
    };
  }
  const mesh = new THREE.Mesh(
    makeStudioGeometry(cls),
    new THREE.MeshStandardMaterial({ color: pd.color || 0x9a9a9a, roughness: 0.8 })
  );
  mesh.scale.set(pd.sx || 1, pd.sy || 1, pd.sz || 1);
  mesh.position.set(pd.x || 0, pd.y || 0.5, pd.z || 0);
  mesh.rotation.y = pd.ry || 0;
  return { mesh, meta: {} };
}

function studioRestoreSnapshot(snap) {
  // remove current
  studioObjects.forEach(o => { if (o.mesh) studioScene.remove(o.mesh); });
  studioObjects = [];
  studioSelected = null;
  studioSelectedIds.clear();
  (snap || []).forEach(pd => {
    const cls = pd.className || 'Part';
    const { mesh, meta } = rebuildStudioObjectFromPd(pd);
    studioScene.add(mesh);
    studioObjects.push({
      id: pd.id || ('p' + Math.random().toString(36).slice(2, 8)),
      name: pd.name || cls, className: cls, shape: pd.shape || cls,
      mesh, canCollide: pd.canCollide !== false, anchored: pd.anchored !== false, vy: 0,
      ...meta
    });
  });
  if (studioTransform) { studioTransform.detach(); studioTransform.visible = false; }
  renderStudioExplorer();
  renderStudioProps();
  updateStudioSelectionBox();
}

function studioUndo() {
  if (!studioUndoStack.length) return;
  studioRedoStack.push(studioSnapshot());
  const prev = studioUndoStack.pop();
  studioRestoreSnapshot(prev);
}

function studioRedo() {
  if (!studioRedoStack.length) return;
  studioUndoStack.push(studioSnapshot());
  const next = studioRedoStack.pop();
  studioRestoreSnapshot(next);
}

let studioMultiMode = false;
let studioSelectedIds = new Set();
let activePublishedGame = null; // { title, parts } when playing published map
let customMapMeshes = [];

const STUDIO_CLASSES = ['Part', 'SpawnLocation', 'Model', 'Folder', 'Script', 'LocalScript', 'Camera', 'Baseplate'];

function studioSaveGames(list) {
  try {
    const normalized = (Array.isArray(list) ? list : []).map(g => ({
      ...g,
      public: g.public !== false,
      visibility: g.public === false ? 'Private' : 'Public'
    }));
    localStorage.setItem('dolex_studio_games', JSON.stringify(normalized));
  } catch {}
}
function studioLoadGames() {
  try {
    const games = JSON.parse(localStorage.getItem('dolex_studio_games') || '[]');
    return (Array.isArray(games) ? games : []).map(g => ({ ...g, public: g.public !== false, visibility: g.public === false ? 'Private' : 'Public' }));
  } catch { return []; }
}

function closeDLStudio() {
  studioOpen = false;
  studioPlaying = false;
  hideJoiningScreen();
  lockOrientation('portrait');
  if (studioAnim) { cancelAnimationFrame(studioAnim); studioAnim = null; }
  if (studioTransform) { studioTransform.dispose(); studioTransform = null; }
  if (studioOrbit) { studioOrbit.dispose(); studioOrbit = null; }
  if (studioRenderer) { studioRenderer.dispose(); studioRenderer = null; }
  studioScene = null; studioCam = null; studioSelected = null; studioObjects = [];
  studioGizmo = null; studioPlayerMesh = null; studioSelectionBox = null;
  document.getElementById('dlstudio')?.classList.add('hidden');
  document.getElementById('publish-page')?.classList.add('hidden');
  document.getElementById('studio-joystick-zone')?.classList.remove('active');
  lockOrientation('portrait');
  document.getElementById('ui-root')?.classList.remove('hidden');
  document.getElementById('ui-root').style.display = '';
  showScreen('lobby');
  renderCreate();
}

function buildStudioGizmo() {
  // SelectionBox helper (outline)
  if (studioSelectionBox) {
    studioScene.remove(studioSelectionBox);
    studioSelectionBox = null;
  }
  studioSelectionBox = new THREE.BoxHelper(new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1)), 0x8c50ff);
  studioSelectionBox.visible = false;
  studioScene.add(studioSelectionBox);

  // TransformControls = Handles / ArcHandles style gizmos
  if (studioTransform) {
    studioScene.remove(studioTransform);
    studioTransform.dispose();
  }
  studioTransform = new TransformControls(studioCam, studioRenderer.domElement);
  studioTransform.setSize(0.9);
  studioTransform.addEventListener('dragging-changed', (e) => {
    if (studioOrbit) studioOrbit.enabled = !e.value;
  });
  studioTransform.addEventListener('change', () => {
    if (studioSelected) {
      updateStudioSelectionBox();
      // live-update properties panel numbers if open
      const px = document.getElementById('sp-px');
      if (px && studioSelected) {
        const m = studioSelected.mesh;
        px.value = m.position.x.toFixed(2);
        document.getElementById('sp-py').value = m.position.y.toFixed(2);
        document.getElementById('sp-pz').value = m.position.z.toFixed(2);
        document.getElementById('sp-sx').value = m.scale.x.toFixed(2);
        document.getElementById('sp-sy').value = m.scale.y.toFixed(2);
        document.getElementById('sp-sz').value = m.scale.z.toFixed(2);
        document.getElementById('sp-ry').value = (m.rotation.y * 180 / Math.PI).toFixed(0);
      }
    }
  });
  studioScene.add(studioTransform);
  try { enableOneSidedScale(); } catch(_){}
  studioTransform.visible = false;
  studioTransform.enabled = false;
}

function updateStudioSelectionBox() {
  if (!studioSelectionBox || !studioSelected) {
    if (studioSelectionBox) studioSelectionBox.visible = false;
    return;
  }
  studioSelectionBox.visible = true;
  studioSelectionBox.setFromObject(studioSelected.mesh);
}

function updateStudioGizmo() {
  updateStudioSelectionBox();
  if (!studioTransform || !studioSelected || studioPlaying) {
    if (studioTransform) {
      studioTransform.detach();
      studioTransform.visible = false;
      studioTransform.enabled = false;
    }
    return;
  }
  studioTransform.attach(studioSelected.mesh);
  studioTransform.visible = true;
  studioTransform.enabled = true;
  studioTransform.space = 'local';
  if (studioTool === 'move') studioTransform.setMode('translate');
  else if (studioTool === 'rotate') studioTransform.setMode('rotate');
  else if (studioTool === 'scale') {
    studioTransform.setMode('scale');
    // Non-uniform: only the axis handle you drag scales (not all axes)
    try { studioTransform.setScaleSnap(null); } catch(_){}
  }
  else {
    // select mode still shows selection box but no handles drag unless move/rotate/scale
    studioTransform.setMode('translate');
  }
}

function selectStudioObject(obj) {
  studioSelected = obj;
  if (obj) studioSelectedService = null;
  document.querySelectorAll('#studio-explorer-tree li').forEach(li => {
    li.classList.toggle('selected', !!(obj && li.dataset.id === obj.id));
  });
  renderStudioProps();
  updateStudioGizmo();
}

// Studio service selection (Explorer services that are not mesh parts)
let studioSelectedService = null;
const studioServiceState = {
  Workspace: { Gravity: 196.2, StreamingEnabled: false, FallenPartsDestroyHeight: -500, AllowThirdPartySales: false },
  Camera: { FieldOfView: 70, CameraType: 'Custom', HeadLocked: true, FieldOfViewMode: 'Vertical', NearPlaneZ: 0.5 },
  Terrain: { WaterColor: '#1e90ff', WaterReflectance: 1, WaterTransparency: 0.3, WaterWaveSize: 0.15, WaterWaveSpeed: 10, Decoration: true, GrassLength: 0.7 },
  SpawnLocation: { Duration: 10, Enabled: true, Neutral: true, AllowTeamChangeOnTouch: false, TeamColor: 'Medium stone grey' },
  Baseplate: { Anchored: true, CanCollide: true, Material: 'Plastic', Size: '512, 1, 512', Color: '#4b8a3a' },
  Players: { CharacterAutoLoads: true, MaxPlayers: 50, RespawnTime: 5, BanningEnabled: true },
  Lighting: {
    Ambient: '#404040', Brightness: 2, ClockTime: 14, ExposureCompensation: 0,
    FogColor: '#c8c8c8', FogEnd: 1000, FogStart: 0, GeographicLatitude: 41.7,
    GlobalShadows: true, OutdoorAmbient: '#808080', ShadowSoftness: 0.2,
    EnvironmentDiffuseScale: 1, EnvironmentSpecularScale: 1, Technology: 'ShadowMap'
  , SkyboxId: 'clouds', SkyboxName: 'Cloudy Sky' },
  ReplicatedFirst: {},
  ReplicatedStorage: {},
  StarterGui: { ResetPlayerGuiOnSpawn: true, ScreenOrientation: 'LandscapeRight', ShowDevelopmentGui: true },
  StarterPack: {},
  StarterPlayer: {
    CameraMaxZoomDistance: 128, CameraMinZoomDistance: 0.5, CameraMode: 'Classic',
    CharacterJumpHeight: 7.2, CharacterWalkSpeed: 16, CharacterUseJumpPower: false,
    HealthDisplayDistance: 100, NameDisplayDistance: 100, AutoJumpEnabled: true
  },
  StarterPlayerScripts: {},
  StarterCharacterScripts: {},
  Teams: { AutoAssignable: true },
  ServerScriptService: { LoadStringEnabled: false },
  ServerStorage: {},
  SoundService: { AmbientReverb: 'NoReverb', DistanceFactor: 3.33, DopplerScale: 1, RolloffScale: 1, RespectFilteringEnabled: true },
  TextChat: { ChatVersion: 'TextChatService', CreateDefaultCommands: true, CreateDefaultTextChannels: true },
};


// Insertable Roblox-like classes (shown in + picker)
const CLASS_CATALOG = [
  // Parts / 3D
  { name: 'Part', cat: 'Parts', icon: '🧱' },
  { name: 'MeshPart', cat: 'Parts', icon: '🔷' },
  { name: 'WedgePart', cat: 'Parts', icon: '🔺' },
  { name: 'CornerWedgePart', cat: 'Parts', icon: '🔻' },
  { name: 'TrussPart', cat: 'Parts', icon: '🪜' },
  { name: 'SpawnLocation', cat: 'Parts', icon: '✳️' },
  { name: 'Seat', cat: 'Parts', icon: '💺' },
  { name: 'VehicleSeat', cat: 'Parts', icon: '🚗' },
  { name: 'Model', cat: 'Parts', icon: '📦' },
  { name: 'Folder', cat: 'Parts', icon: '📁' },
  { name: 'Attachment', cat: 'Parts', icon: '📌' },
  // GUIs
  { name: 'ScreenGui', cat: 'GUI', icon: '🖼️' },
  { name: 'Frame', cat: 'GUI', icon: '▭' },
  { name: 'ScrollingFrame', cat: 'GUI', icon: '📜' },
  { name: 'TextLabel', cat: 'GUI', icon: '🔤' },
  { name: 'TextButton', cat: 'GUI', icon: '🔘' },
  { name: 'TextBox', cat: 'GUI', icon: '⌨️' },
  { name: 'ImageLabel', cat: 'GUI', icon: '🖼️' },
  { name: 'ImageButton', cat: 'GUI', icon: '🖼️' },
  { name: 'BillboardGui', cat: 'GUI', icon: '🏷️' },
  { name: 'SurfaceGui', cat: 'GUI', icon: '📺' },
  // UI Layout
  { name: 'UIListLayout', cat: 'UI', icon: '☰' },
  { name: 'UIGridLayout', cat: 'UI', icon: '▦' },
  { name: 'UIPadding', cat: 'UI', icon: '↔️' },
  { name: 'UICorner', cat: 'UI', icon: '╭' },
  { name: 'UIStroke', cat: 'UI', icon: '⬜' },
  { name: 'UIGradient', cat: 'UI', icon: '🌈' },
  { name: 'UIScale', cat: 'UI', icon: '🔍' },
  // Scripts
  { name: 'Script', cat: 'Scripts', icon: '📜' },
  { name: 'LocalScript', cat: 'Scripts', icon: '📄' },
  { name: 'ModuleScript', cat: 'Scripts', icon: '📦' },
  // Networking
  { name: 'RemoteEvent', cat: 'Network', icon: '📡' },
  { name: 'RemoteFunction', cat: 'Network', icon: '📞' },
  { name: 'BindableEvent', cat: 'Network', icon: '🔔' },
  { name: 'BindableFunction', cat: 'Network', icon: '🔗' },
  // Values
  { name: 'BoolValue', cat: 'Values', icon: '✓' },
  { name: 'IntValue', cat: 'Values', icon: '🔢' },
  { name: 'NumberValue', cat: 'Values', icon: '#️⃣' },
  { name: 'StringValue', cat: 'Values', icon: '🔤' },
  { name: 'ObjectValue', cat: 'Values', icon: '📎' },
  { name: 'Vector3Value', cat: 'Values', icon: '📐' },
  { name: 'Color3Value', cat: 'Values', icon: '🎨' },
  // Effects
  { name: 'PointLight', cat: 'Effects', icon: '💡' },
  { name: 'SpotLight', cat: 'Effects', icon: '🔦' },
  { name: 'SurfaceLight', cat: 'Effects', icon: '🔆' },
  { name: 'Fire', cat: 'Effects', icon: '🔥' },
  { name: 'Smoke', cat: 'Effects', icon: '💨' },
  { name: 'Sparkles', cat: 'Effects', icon: '✨' },
  { name: 'ParticleEmitter', cat: 'Effects', icon: '🎆' },
  { name: 'Beam', cat: 'Effects', icon: '➖' },
  { name: 'Trail', cat: 'Effects', icon: '〰️' },
  { name: 'Explosion', cat: 'Effects', icon: '💥' },
  { name: 'Highlight', cat: 'Effects', icon: '🟨' },
  // Sound
  { name: 'Sound', cat: 'Sound', icon: '🔊' },
  { name: 'SoundGroup', cat: 'Sound', icon: '🔈' },
  // Physics
  { name: 'WeldConstraint', cat: 'Physics', icon: '🔗' },
  { name: 'HingeConstraint', cat: 'Physics', icon: '🔧' },
  { name: 'BallSocketConstraint', cat: 'Physics', icon: '⚪' },
  { name: 'RopeConstraint', cat: 'Physics', icon: '🪢' },
  { name: 'SpringConstraint', cat: 'Physics', icon: '🌀' },
  { name: 'AlignPosition', cat: 'Physics', icon: '📍' },
  { name: 'AlignOrientation', cat: 'Physics', icon: '🧭' },
  // Interaction
  { name: 'ClickDetector', cat: 'Interaction', icon: '👆' },
  { name: 'ProximityPrompt', cat: 'Interaction', icon: '⬚' },
  // Players
  { name: 'Humanoid', cat: 'Character', icon: '🧍' },
  { name: 'Tool', cat: 'Character', icon: '🔨' },
  { name: 'Animation', cat: 'Character', icon: '🎬' },
  // Teams
  { name: 'Team', cat: 'Teams', icon: '🚩' },
  // Lighting extras
  { name: 'Sky', cat: 'Lighting', icon: '🌌' },
  { name: 'Atmosphere', cat: 'Lighting', icon: '🌫️' },
  { name: 'BloomEffect', cat: 'Lighting', icon: '🌟' },
  { name: 'BlurEffect', cat: 'Lighting', icon: '💧' },
  { name: 'ColorCorrectionEffect', cat: 'Lighting', icon: '🎨' },
  { name: 'SunRaysEffect', cat: 'Lighting', icon: '☀️' },
];

// Virtual (non-mesh) instances inserted under services
let studioInserted = {}; // { [parentService]: [ { id, name, className, icon, locked:false } ] }
let studioInsertParent = 'Workspace';

const BUILTIN_SERVICES = new Set([
  'Workspace','Camera','Terrain','SpawnLocation','Baseplate',
  'Players','Lighting','ReplicatedFirst','ReplicatedStorage',
  'StarterGui','StarterPack','StarterPlayer','StarterPlayerScripts','StarterCharacterScripts',
  'Teams','ServerScriptService','ServerStorage','SoundService','TextChat'
]);

function servicePropsRows(svcName) {
  const st = studioServiceState[svcName] || {};
  const rows = [
    { sec: 'Data', key: 'Name', html: `<span style="color:#ccc">${escapeHtml(svcName)}</span>` },
    { sec: 'Data', key: 'Parent', html: `<span style="color:#ccc">game</span>` },
    { sec: 'Data', key: 'ClassName', html: `<span style="color:#ccc">${escapeHtml(svcName)}</span>` },
    { sec: 'Data', key: 'Archivable', html: `<input type="checkbox" checked data-svc-key="Archivable" />` },
  ];
  Object.entries(st).forEach(([k, v]) => {
    const id = 'svc-' + k.replace(/\W/g, '');
    let sec = 'Data';
    if (/Color|Ambient|Fog|Material|Brightness|Exposure|Shadow|Outdoor|Technology|Water|Decoration|Grass/i.test(k)) sec = 'Appearance';
    else if (/Enabled|Auto|Load|Filter|Jump|Walk|Camera|Character|Assign|Ban|Third/i.test(k)) sec = 'Behavior';
    if (typeof v === 'boolean') {
      rows.push({ sec, key: k, html: `<input type="checkbox" id="${id}" ${v ? 'checked' : ''} data-svc-key="${k}" />` });
    } else if (typeof v === 'number') {
      rows.push({ sec, key: k, html: `<input type="number" step="any" id="${id}" value="${v}" data-svc-key="${k}" />` });
    } else if (typeof v === 'string' && /^#[0-9a-fA-F]{3,8}$/.test(v)) {
      rows.push({ sec: 'Appearance', key: k, html: `<input type="color" id="${id}" value="${v}" data-svc-key="${k}" />` });
    } else {
      rows.push({ sec, key: k, html: `<input type="text" id="${id}" value="${escapeHtml(String(v))}" data-svc-key="${k}" />` });
    }
  });
  return rows;
}

function renderStudioProps() {
  const box = document.getElementById('studio-props');
  if (!box) return;
  const filter = (document.getElementById('studio-props-filter')?.value || '').trim().toLowerCase();

  // Service selected (no mesh)
  if (studioSelectedService && !studioSelected) {
    const rows = servicePropsRows(studioSelectedService)
      .filter(r => !filter || r.key.toLowerCase().includes(filter) || r.sec.toLowerCase().includes(filter));
    const sections = {};
    rows.forEach(r => { (sections[r.sec] = sections[r.sec] || []).push(r); });
    box.innerHTML = Object.entries(sections).map(([sec, list]) => `
      <div class="studio-prop-section">
        <div class="studio-prop-section-title">${sec}</div>
        ${list.map(r => `<div class="studio-prop-row"><span>${r.key}</span>${r.html}</div>`).join('')}
      </div>`).join('') || '<p class="muted" style="padding:12px">No matching properties</p>';
    box.querySelectorAll('[data-svc-key]').forEach(el => {
      const key = el.dataset.svcKey;
      const apply = () => {
        if (!studioServiceState[studioSelectedService]) studioServiceState[studioSelectedService] = {};
        if (el.type === 'checkbox') studioServiceState[studioSelectedService][key] = el.checked;
        else if (el.type === 'number') studioServiceState[studioSelectedService][key] = parseFloat(el.value) || 0;
        else studioServiceState[studioSelectedService][key] = el.value;
      };
      el.onchange = el.oninput = apply;
    });
    return;
  }

  if (!studioSelected) {
    box.innerHTML = '<p class="muted" style="padding:12px">Select an object</p>';
    return;
  }
  const o = studioSelected;
  // Virtual (non-mesh) inserted instances
  if (o.virtual || !o.mesh) {
    const canRename = !o.locked && !BUILTIN_SERVICES.has(o.className);
    const rows = [
      { sec: 'Data', key: 'Name', html: canRename
        ? `<input id="sp-name" value="${escapeHtml(o.name)}" />`
        : `<span style="color:#ccc">${escapeHtml(o.name)}</span>` },
      { sec: 'Data', key: 'Parent', html: `<span style="color:#ccc">${escapeHtml(o.parent || 'Workspace')}</span>` },
      { sec: 'Data', key: 'ClassName', html: `<span style="color:#ccc">${escapeHtml(o.className)}</span>` },
      { sec: 'Data', key: 'Archivable', html: `<input type="checkbox" checked disabled />` },
      { sec: 'Data', key: 'UniqueId', html: `<span style="color:#888;font-size:0.75rem">${escapeHtml(o.id)}</span>` },
    ].filter(r => !filter || r.key.toLowerCase().includes(filter) || r.sec.toLowerCase().includes(filter));
    box.innerHTML = `<div class="studio-prop-section"><div class="studio-prop-section-title">Data</div>
      ${rows.map(r => `<div class="studio-prop-row"><span>${r.key}</span>${r.html}</div>`).join('')}</div>`;
    document.getElementById('sp-name')?.addEventListener('change', e => {
      if (!canRename) return;
      const neu = e.target.value.slice(0, 40) || o.name;
      o.name = neu;
      const list = studioInserted[o.parent] || [];
      const inst = list.find(x => x.id === o.id);
      if (inst) inst.name = neu;
      renderStudioExplorer();
    });
    return;
  }
  const m = o.mesh;
  if (!m) {
    box.innerHTML = '<p class="muted" style="padding:12px">No mesh properties</p>';
    return;
  }
  // Defaults for Roblox-like props
  o.archivable = o.archivable !== false;
  o.canTouch = o.canTouch !== false;
  o.canQuery = o.canQuery !== false;
  o.massless = !!o.massless;
  o.locked = !!o.locked;
  o.reflectance = o.reflectance ?? 0;
  o.material = o.material || 'Plastic';
  o.collisionGroup = o.collisionGroup || 'Default';
  o.rootPriority = o.rootPriority ?? 0;
  const rx = (m.rotation.x * 180 / Math.PI).toFixed(1);
  const ry = (m.rotation.y * 180 / Math.PI).toFixed(1);
  const rz = (m.rotation.z * 180 / Math.PI).toFixed(1);
  const colorHex = '#' + (m.material?.color?.getHexString?.() || '888888');
  const transparency = (m.material?.opacity != null ? (1 - m.material.opacity) : 0).toFixed(2);
  const matOpts = ['Plastic','SmoothPlastic','Neon','Metal','Wood','WoodPlanks','Concrete','Grass','Slate','Brick','Cobblestone','Rock','Ice','Glass','ForceField']
    .map(x => `<option value="${x}" ${o.material === x ? 'selected' : ''}>${x}</option>`).join('');
  const shapeOpts = ['Block','Ball','Cylinder','Wedge','CornerWedge']
    .map(x => `<option value="${x}" ${(o.shape || o.className) === x || o.className === 'Part' && x==='Block' ? 'selected' : ''}>${x}</option>`).join('');

  const rows = [
    // Common Instance
    { sec: 'Data', key: 'Name', html: `<input id="sp-name" value="${escapeHtml(o.name)}" />` },
    { sec: 'Data', key: 'Parent', html: `<span style="color:#ccc">Workspace</span>` },
    { sec: 'Data', key: 'ClassName', html: `<span style="color:#ccc">${escapeHtml(o.className || 'Part')}</span>` },
    { sec: 'Data', key: 'Archivable', html: `<input type="checkbox" id="sp-archivable" ${o.archivable ? 'checked' : ''} />` },
    { sec: 'Data', key: 'UniqueId', html: `<span style="color:#888;font-size:0.75rem">${escapeHtml(o.id)}</span>` },
    { sec: 'Data', key: 'Attributes', html: `<span style="color:#888">0</span>` },
    { sec: 'Data', key: 'Tags', html: `<span style="color:#888">—</span>` },
    // Transform / Part
    { sec: 'Transform', key: 'Position', html: `<span class="sp-vec3">
      <input type="number" step="0.1" id="sp-px" value="${m.position.x.toFixed(2)}" title="X"/>
      <input type="number" step="0.1" id="sp-py" value="${m.position.y.toFixed(2)}" title="Y"/>
      <input type="number" step="0.1" id="sp-pz" value="${m.position.z.toFixed(2)}" title="Z"/></span>` },
    { sec: 'Transform', key: 'Orientation', html: `<span class="sp-vec3">
      <input type="number" step="1" id="sp-rx" value="${rx}" title="X"/>
      <input type="number" step="1" id="sp-ry" value="${ry}" title="Y"/>
      <input type="number" step="1" id="sp-rz" value="${rz}" title="Z"/></span>` },
    { sec: 'Transform', key: 'Size', html: `<span class="sp-vec3">
      <input type="number" step="0.1" id="sp-sx" value="${m.scale.x.toFixed(2)}" title="X"/>
      <input type="number" step="0.1" id="sp-sy" value="${m.scale.y.toFixed(2)}" title="Y"/>
      <input type="number" step="0.1" id="sp-sz" value="${m.scale.z.toFixed(2)}" title="Z"/></span>` },
    { sec: 'Transform', key: 'CFrame', html: `<span style="color:#888;font-size:0.72rem">${m.position.x.toFixed(1)}, ${m.position.y.toFixed(1)}, ${m.position.z.toFixed(1)}</span>` },
    { sec: 'Transform', key: 'PivotOffset', html: `<span style="color:#888">0, 0, 0</span>` },
    // Appearance
    { sec: 'Appearance', key: 'Color', html: `<input type="color" id="sp-color" value="${colorHex}" />` },
    { sec: 'Appearance', key: 'BrickColor', html: `<span style="color:#ccc">Custom</span>` },
    { sec: 'Appearance', key: 'Material', html: `<select id="sp-mat">${matOpts}</select>` },
    { sec: 'Appearance', key: 'MaterialVariant', html: `<span style="color:#888">—</span>` },
    { sec: 'Appearance', key: 'Transparency', html: `<input type="number" step="0.05" min="0" max="1" id="sp-trans" value="${transparency}" />` },
    { sec: 'Appearance', key: 'Reflectance', html: `<input type="number" step="0.05" min="0" max="1" id="sp-refl" value="${o.reflectance}" />` },
    { sec: 'Appearance', key: 'CastShadow', html: `<input type="checkbox" id="sp-shadow" ${m.castShadow ? 'checked' : ''} />` },
    { sec: 'Appearance', key: 'Shape', html: `<select id="sp-shape">${shapeOpts}</select>` },
    // Behavior
    { sec: 'Behavior', key: 'Anchored', html: `<input type="checkbox" id="sp-anchored" ${o.anchored !== false ? 'checked' : ''} />` },
    { sec: 'Behavior', key: 'CanCollide', html: `<input type="checkbox" id="sp-collide" ${o.canCollide !== false ? 'checked' : ''} />` },
    { sec: 'Behavior', key: 'CanTouch', html: `<input type="checkbox" id="sp-cantouch" ${o.canTouch ? 'checked' : ''} />` },
    { sec: 'Behavior', key: 'CanQuery', html: `<input type="checkbox" id="sp-canquery" ${o.canQuery ? 'checked' : ''} />` },
    { sec: 'Behavior', key: 'CollisionGroup', html: `<input type="text" id="sp-colgroup" value="${escapeHtml(o.collisionGroup)}" />` },
    { sec: 'Behavior', key: 'Massless', html: `<input type="checkbox" id="sp-massless" ${o.massless ? 'checked' : ''} />` },
    { sec: 'Behavior', key: 'RootPriority', html: `<input type="number" step="1" id="sp-rootpri" value="${o.rootPriority}" />` },
    { sec: 'Behavior', key: 'Locked', html: `<input type="checkbox" id="sp-locked" ${o.locked ? 'checked' : ''} />` },
    // Surface
    { sec: 'Surface', key: 'TopSurface', html: `<span style="color:#ccc">Studs</span>` },
    { sec: 'Surface', key: 'BottomSurface', html: `<span style="color:#ccc">Inlet</span>` },
    { sec: 'Surface', key: 'FrontSurface', html: `<span style="color:#ccc">Smooth</span>` },
    { sec: 'Surface', key: 'BackSurface', html: `<span style="color:#ccc">Smooth</span>` },
    { sec: 'Surface', key: 'LeftSurface', html: `<span style="color:#ccc">Smooth</span>` },
    { sec: 'Surface', key: 'RightSurface', html: `<span style="color:#ccc">Smooth</span>` },
    // Assembly
    { sec: 'Assembly', key: 'AssemblyMass', html: `<span style="color:#888">${(m.scale.x * m.scale.y * m.scale.z).toFixed(2)}</span>` },
    { sec: 'Assembly', key: 'AssemblyCenterOfMass', html: `<span style="color:#888">${m.position.x.toFixed(1)}, ${m.position.y.toFixed(1)}, ${m.position.z.toFixed(1)}</span>` },
    { sec: 'Assembly', key: 'AssemblyLinearVelocity', html: `<span style="color:#888">0, 0, 0</span>` },
    { sec: 'Assembly', key: 'AssemblyAngularVelocity', html: `<span style="color:#888">0, 0, 0</span>` },
  ].filter(r => !filter || r.key.toLowerCase().includes(filter) || r.sec.toLowerCase().includes(filter));

  const sections = {};
  rows.forEach(r => { (sections[r.sec] = sections[r.sec] || []).push(r); });
  box.innerHTML = Object.entries(sections).map(([sec, list]) => `
    <div class="studio-prop-section">
      <div class="studio-prop-section-title">${sec}</div>
      ${list.map(r => `<div class="studio-prop-row"><span>${r.key}</span>${r.html}</div>`).join('')}
    </div>`).join('') || '<p class="muted" style="padding:12px">No matching properties</p>';

  const bindNum = (id, fn) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.onchange = el.oninput = () => { fn(parseFloat(el.value) || 0); updateStudioGizmo(); };
  };
  bindNum('sp-px', v => { m.position.x = v; });
  bindNum('sp-py', v => { m.position.y = v; });
  bindNum('sp-pz', v => { m.position.z = v; });
  bindNum('sp-sx', v => { m.scale.x = Math.max(0.05, v); });
  bindNum('sp-sy', v => { m.scale.y = Math.max(0.05, v); });
  bindNum('sp-sz', v => { m.scale.z = Math.max(0.05, v); });
  bindNum('sp-rx', v => { m.rotation.x = v * Math.PI / 180; });
  bindNum('sp-ry', v => { m.rotation.y = v * Math.PI / 180; });
  bindNum('sp-rz', v => { m.rotation.z = v * Math.PI / 180; });
  bindNum('sp-refl', v => { o.reflectance = Math.min(1, Math.max(0, v)); if (m.material) m.material.metalness = o.reflectance; });
  bindNum('sp-rootpri', v => { o.rootPriority = v | 0; });
  document.getElementById('sp-name')?.addEventListener('change', e => {
    o.name = e.target.value.slice(0, 40) || o.name;
    renderStudioExplorer();
  });
  document.getElementById('sp-collide')?.addEventListener('change', e => { o.canCollide = e.target.checked; });
  document.getElementById('sp-anchored')?.addEventListener('change', e => { o.anchored = e.target.checked; });
  document.getElementById('sp-shadow')?.addEventListener('change', e => { m.castShadow = e.target.checked; });
  document.getElementById('sp-archivable')?.addEventListener('change', e => { o.archivable = e.target.checked; });
  document.getElementById('sp-cantouch')?.addEventListener('change', e => { o.canTouch = e.target.checked; });
  document.getElementById('sp-canquery')?.addEventListener('change', e => { o.canQuery = e.target.checked; });
  document.getElementById('sp-massless')?.addEventListener('change', e => { o.massless = e.target.checked; });
  document.getElementById('sp-locked')?.addEventListener('change', e => { o.locked = e.target.checked; });
  document.getElementById('sp-colgroup')?.addEventListener('change', e => { o.collisionGroup = e.target.value || 'Default'; });
  document.getElementById('sp-mat')?.addEventListener('change', e => {
    o.material = e.target.value;
    if (m.material) {
      if (o.material === 'Neon') { m.material.emissive = m.material.color.clone(); m.material.metalness = 0; m.material.roughness = 0.3; }
      else if (o.material === 'Metal') { m.material.emissive?.set?.(0); m.material.metalness = 0.85; m.material.roughness = 0.25; }
      else if (o.material === 'Glass') { m.material.transparent = true; m.material.opacity = 0.4; m.material.metalness = 0.1; m.material.roughness = 0.05; }
      else { m.material.emissive?.set?.(0); m.material.metalness = 0.1; m.material.roughness = 0.7; }
    }
  });
  document.getElementById('sp-shape')?.addEventListener('change', e => { o.shape = e.target.value; });
  document.getElementById('sp-color')?.addEventListener('input', e => {
    if (m.material && m.material.color) m.material.color.set(e.target.value);
  });
  document.getElementById('sp-trans')?.addEventListener('input', e => {
    if (m.material) {
      const t = Math.min(1, Math.max(0, parseFloat(e.target.value) || 0));
      m.material.transparent = t > 0.01;
      m.material.opacity = 1 - t;
    }
  });
}

function renderStudioExplorer(filter = '') {
  const tree = document.getElementById('studio-explorer-tree');
  if (!tree) return;
  const q = (filter || document.getElementById('studio-explorer-search')?.value || '').trim().toLowerCase();
  const parts = studioObjects.filter(o => !q || o.name.toLowerCase().includes(q) || o.className.toLowerCase().includes(q));

  // Workspace builtins (Roblox-style)
  const workspaceBuiltins = [
    { name: 'Camera', service: 'Camera' },
    { name: 'Terrain', service: 'Terrain' },
    { name: 'SpawnLocation', service: 'SpawnLocation' },
    { name: 'Baseplate', service: 'Baseplate' },
  ];

  // Full service tree matching Roblox Explorer
  const services = [
    { name: 'Players', children: [] },
    { name: 'Lighting', children: [] },
    { name: 'ReplicatedFirst', children: [] },
    { name: 'ReplicatedStorage', children: [] },
    { name: 'StarterGui', children: [] },
    { name: 'StarterPack', children: [] },
    { name: 'StarterPlayer', children: [
      { name: 'StarterPlayerScripts' },
      { name: 'StarterCharacterScripts' },
    ]},
    { name: 'Teams', children: [] },
    { name: 'ServerScriptService', children: [] },
    { name: 'ServerStorage', children: [] },
    { name: 'SoundService', children: [] },
    { name: 'TextChat', children: [] },
  ];

  const isSel = (svc) => studioSelectedService === svc && !studioSelected ? 'selected' : '';
  const isPartSel = (id) => studioSelected && studioSelected.id === id ? 'selected' : '';
  const iconHtml = (cls) => `<span class="tree-icon">${studioClassIcon(cls)}</span>`;

  let html = `
    <li class="tree-folder tree-service ${isSel('Workspace')}" data-service="Workspace" data-expand="ws">
      <span class="tree-caret">▼</span>
      ${iconHtml('Workspace')}<span class="tree-label">Workspace</span>
      <span class="tree-add" data-add="Workspace" title="Add">+</span>
    </li>
    <ul class="tree-children" data-parent="ws">
      ${workspaceBuiltins.map(b => `
        <li class="tree-service ${isSel(b.service)}" data-service="${b.service}">
          ${iconHtml(b.service)}<span class="tree-label">${b.name}</span>
          <span class="tree-add" data-add="${b.service}" title="Add">+</span>
        </li>`).join('')}
      ${(studioInserted['Workspace'] || []).filter(ins => !q || ins.name.toLowerCase().includes(q) || ins.className.toLowerCase().includes(q)).map(ins => `
        <li data-inserted="${ins.id}" data-parent="Workspace" class="${studioSelected && studioSelected.id === ins.id ? 'selected' : ''}">
          <span class="tree-caret">·</span>
          ${iconHtml(ins.className || ins.name)}
          <span class="tree-label">${escapeHtml(ins.name)}</span>
          <span class="tree-add" data-add="Workspace" title="Add child">+</span>
        </li>`).join('')}
      ${parts.map(o => `
        <li data-id="${o.id}" class="${isPartSel(o.id)}">
          <span class="tree-caret">·</span>
          ${iconHtml(o.className)}
          <span class="tree-label">${escapeHtml(o.name)}</span>
          <span class="tree-add" data-add="Workspace" title="Add sibling">+</span>
        </li>`).join('')}
    </ul>
  `;

  services.forEach((s, i) => {
    const pid = 'svc' + i;
    const hasKids = s.children && s.children.length;
    html += `
      <li class="tree-folder tree-service ${isSel(s.name)}" data-service="${s.name}" data-expand="${pid}">
        <span class="tree-caret">${hasKids ? '▼' : '·'}</span>
        ${iconHtml(s.name)}<span class="tree-label">${s.name}</span>
        <span class="tree-add" data-add="${s.name}" title="Add">+</span>
      </li>`;
    if (hasKids) {
      html += `<ul class="tree-children" data-parent="${pid}">`;
      s.children.forEach(c => {
        html += `
          <li class="tree-service ${isSel(c.name)}" data-service="${c.name}">
            ${iconHtml(c.name)}<span class="tree-label">${c.name}</span>
            <span class="tree-add" data-add="${c.name}" title="Add">+</span>
          </li>`;
        // inserted under this child service
        (studioInserted[c.name] || []).filter(ins => !q || ins.name.toLowerCase().includes(q) || ins.className.toLowerCase().includes(q)).forEach(ins => {
          html += `
            <li data-inserted="${ins.id}" data-parent="${c.name}" class="${studioSelected && studioSelected.id === ins.id ? 'selected' : ''}" style="padding-left:28px">
              ${iconHtml(ins.className || ins.name)}
              <span class="tree-label">${escapeHtml(ins.name)}</span>
            </li>`;
        });
      });
      // inserted directly under parent service
      (studioInserted[s.name] || []).filter(ins => !q || ins.name.toLowerCase().includes(q) || ins.className.toLowerCase().includes(q)).forEach(ins => {
        html += `
          <li data-inserted="${ins.id}" data-parent="${s.name}" class="${studioSelected && studioSelected.id === ins.id ? 'selected' : ''}">
            ${iconHtml(ins.className || ins.name)}
            <span class="tree-label">${escapeHtml(ins.name)}</span>
          </li>`;
      });
      html += `</ul>`;
    } else {
      // no folder children — still show inserted under this service as siblings
      const insList = (studioInserted[s.name] || []).filter(ins => !q || ins.name.toLowerCase().includes(q) || ins.className.toLowerCase().includes(q));
      if (insList.length) {
        html += `<ul class="tree-children" data-parent="${pid}">`;
        insList.forEach(ins => {
          html += `
            <li data-inserted="${ins.id}" data-parent="${s.name}" class="${studioSelected && studioSelected.id === ins.id ? 'selected' : ''}">
              ${iconHtml(ins.className || ins.name)}
              <span class="tree-label">${escapeHtml(ins.name)}</span>
            </li>`;
        });
        html += `</ul>`;
      }
    }
  });

  tree.innerHTML = html;

  // Select mesh parts
  tree.querySelectorAll('li[data-id]').forEach(li => {
    li.onclick = (e) => {
      e.stopPropagation();
      studioSelectedService = null;
      const obj = studioObjects.find(o => o.id === li.dataset.id);
      selectStudioObject(obj || null);
    };
  });

  // Select services
  tree.querySelectorAll('li[data-service]').forEach(li => {
    li.onclick = (e) => {
      e.stopPropagation();
      studioSelected = null;
      studioSelectedIds = new Set();
      studioSelectedService = li.dataset.service;
      if (typeof updateStudioGizmo === 'function') updateStudioGizmo();
      renderStudioExplorer(q);
      renderStudioProps();
    };
  });

  // Expand / collapse carets
  tree.querySelectorAll('.tree-caret').forEach(c => {
    c.onclick = (e) => {
      e.stopPropagation();
      const li = c.closest('li');
      const pid = li?.dataset.expand;
      if (!pid) return;
      const ul = tree.querySelector(`ul[data-parent="${pid}"]`);
      if (!ul) return;
      const open = ul.style.display !== 'none';
      ul.style.display = open ? 'none' : '';
      c.textContent = open ? '▶' : '▼';
    };
  });

  // + button opens class picker for that parent
  tree.querySelectorAll('.tree-add').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      e.preventDefault();
      openClassPicker(btn.dataset.add || 'Workspace');
    };
  });

  // Select inserted virtual instances
  tree.querySelectorAll('li[data-inserted]').forEach(li => {
    li.onclick = (e) => {
      e.stopPropagation();
      studioSelectedService = null;
      studioSelected = null;
      studioSelectedIds = new Set();
      const parent = li.dataset.parent;
      const id = li.dataset.inserted;
      const list = studioInserted[parent] || [];
      const inst = list.find(x => x.id === id);
      if (inst) {
        studioSelected = { id: inst.id, name: inst.name, className: inst.className, mesh: null, virtual: true, parent, locked: false, props: inst.props };
        try { onStudioSkySelected(inst); } catch(_){}
        try { if (inst.className === 'Script') openScriptEditor(inst); } catch(_){}
        try { renderStudioUIPreview(); } catch(_){}
      }
      renderStudioExplorer(q);
      renderStudioProps();
    };
  });

  // Context menu: right-click or long-press on Explorer (Workspace classes)
  const ctx = document.getElementById('studio-ctx-menu');
  let holdTimer = null;
  function showCtxMenu(x, y, li) {
    if (!ctx) return;
    if (li.dataset.id) {
      const obj = studioObjects.find(o => o.id === li.dataset.id);
      if (obj) selectStudioObject(obj);
    } else if (li.dataset.inserted || li.dataset.service) {
      try { li.click(); } catch (_) {}
    }
    const isGroup = !!(studioSelected && studioSelected.group);
    document.getElementById('ctx-group')?.classList.toggle('hidden', isGroup);
    document.getElementById('ctx-ungroup')?.classList.toggle('hidden', !isGroup);
    ctx.classList.remove('hidden');
    const pad = 8;
    const w = ctx.offsetWidth || 180;
    const h = ctx.offsetHeight || 280;
    let left = x, top = y;
    if (left + w > window.innerWidth - pad) left = window.innerWidth - w - pad;
    if (top + h > window.innerHeight - pad) top = window.innerHeight - h - pad;
    ctx.style.left = Math.max(pad, left) + 'px';
    ctx.style.top = Math.max(pad, top) + 'px';
  }
  function hideCtxMenu() { ctx?.classList.add('hidden'); }
  tree.querySelectorAll('li[data-id], li[data-inserted], li[data-service]').forEach(li => {
    li.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showCtxMenu(e.clientX, e.clientY, li);
    });
    li.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      holdTimer = setTimeout(() => showCtxMenu(e.clientX || 40, e.clientY || 120, li), 450);
    });
    li.addEventListener('pointerup', () => clearTimeout(holdTimer));
    li.addEventListener('pointerleave', () => clearTimeout(holdTimer));
    li.addEventListener('pointercancel', () => clearTimeout(holdTimer));
  });
  document.addEventListener('pointerdown', (e) => {
    if (ctx && !ctx.classList.contains('hidden') && !ctx.contains(e.target)) {
      if (!e.target.closest || !e.target.closest('#studio-ctx-menu')) hideCtxMenu();
    }
  }, true);
}

function openClassPicker(parentService) {
  studioInsertParent = parentService || 'Workspace';
  let modal = document.getElementById('studio-class-picker');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'studio-class-picker';
    modal.className = 'studio-class-picker';
    modal.innerHTML = `
      <div class="scp-box">
        <div class="scp-head">
          <div class="scp-title">Insert Class under <span id="scp-parent">Workspace</span></div>
          <button type="button" class="scp-close" id="scp-close">✕</button>
        </div>
        <input type="search" id="scp-search" class="scp-search" placeholder="Search classes…" autocomplete="off" />
        <div class="scp-cats" id="scp-cats"></div>
        <div class="scp-list" id="scp-list"></div>
        <div class="scp-foot">
          <span class="muted" id="scp-selected-label">None selected</span>
          <button type="button" class="btn btn-purple" id="scp-insert" disabled>Insert</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('scp-close').onclick = () => { modal.classList.remove('open'); };
    modal.addEventListener('click', e => { if (e.target === modal) modal.classList.remove('open'); });
    document.getElementById('scp-search').oninput = () => fillClassPickerList();
    document.getElementById('scp-insert').onclick = () => {
      const name = modal.dataset.selectedClass;
      if (!name) return;
      insertClassUnder(studioInsertParent, name);
      modal.classList.remove('open');
    };
  }
  document.getElementById('scp-parent').textContent = studioInsertParent;
  document.getElementById('scp-search').value = '';
  modal.dataset.selectedClass = '';
  document.getElementById('scp-selected-label').textContent = 'None selected';
  document.getElementById('scp-insert').disabled = true;
  // categories
  const cats = ['All', ...Array.from(new Set(CLASS_CATALOG.map(c => c.cat)))];
  const catBox = document.getElementById('scp-cats');
  catBox.innerHTML = cats.map((c, i) => `<button type="button" class="scp-cat${i===0?' active':''}" data-cat="${c}">${c}</button>`).join('');
  catBox.querySelectorAll('.scp-cat').forEach(b => {
    b.onclick = () => {
      catBox.querySelectorAll('.scp-cat').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      fillClassPickerList();
    };
  });
  fillClassPickerList();
  modal.classList.add('open');
  // force list scrollable area
  const listEl = document.getElementById('scp-list');
  if (listEl) {
    listEl.style.overflowY = 'auto';
    listEl.style.flex = '1 1 auto';
    listEl.style.minHeight = '160px';
    listEl.style.maxHeight = 'none';
  }
  setTimeout(() => document.getElementById('scp-search')?.focus(), 50);
}

function fillClassPickerList() {
  const q = (document.getElementById('scp-search')?.value || '').trim().toLowerCase();
  const cat = document.querySelector('.scp-cat.active')?.dataset.cat || 'All';
  const list = document.getElementById('scp-list');
  if (!list) return;
  const items = CLASS_CATALOG.filter(c => {
    if (cat !== 'All' && c.cat !== cat) return false;
    if (q && !c.name.toLowerCase().includes(q) && !c.cat.toLowerCase().includes(q)) return false;
    return true;
  });
  list.innerHTML = items.map(c => `
    <button type="button" class="scp-item" data-class="${c.name}">
      <span class="scp-icon">${c.icon}</span>
      <span class="scp-name">${c.name}</span>
      <span class="scp-cat-tag">${c.cat}</span>
    </button>`).join('') || '<p class="muted" style="padding:12px">No classes match</p>';
  list.querySelectorAll('.scp-item').forEach(btn => {
    btn.onclick = () => {
      list.querySelectorAll('.scp-item').forEach(x => x.classList.remove('selected'));
      btn.classList.add('selected');
      const modal = document.getElementById('studio-class-picker');
      modal.dataset.selectedClass = btn.dataset.class;
      document.getElementById('scp-selected-label').textContent = btn.dataset.class;
      document.getElementById('scp-insert').disabled = false;
    };
    btn.ondblclick = () => {
      insertClassUnder(studioInsertParent, btn.dataset.class);
      document.getElementById('studio-class-picker')?.classList.remove('open');
    };
  });
}

function insertClassUnder(parent, className) {
  const info = CLASS_CATALOG.find(c => c.name === className) || { name: className, icon: '📄' };
  // Mesh-capable classes go into the 3D scene under Workspace
  const meshClasses = new Set(['Part','MeshPart','WedgePart','CornerWedgePart','TrussPart','SpawnLocation','Seat','VehicleSeat','Ball']);
  if ((parent === 'Workspace' || parent === 'Baseplate') && (meshClasses.has(className) || className === 'Part')) {
    const map = { WedgePart: 'Wedge', CornerWedgePart: 'Wedge', MeshPart: 'Part', TrussPart: 'Part', Seat: 'Part', VehicleSeat: 'Part', Ball: 'Ball' };
    addStudioPart(map[className] || className);
    return;
  }
  if (!studioInserted[parent]) studioInserted[parent] = [];
  const count = studioInserted[parent].filter(x => x.className === className).length + 1;
  const inst = {
    id: 'ins_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    name: className + count,
    className,
    icon: info.icon || '📄',
    locked: false,
    parent
  };
  studioInserted[parent].push(inst);
  studioSelected = { id: inst.id, name: inst.name, className: inst.className, mesh: null, virtual: true, parent, locked: false };
  studioSelectedService = null;
  studioSelectedIds = new Set();
  renderStudioExplorer();
  renderStudioProps();
}


function makeStudioGeometry(className) {
  // Always unit-sized geometry; world size comes from mesh.scale
  if (className === 'Ball') return new THREE.SphereGeometry(0.5, 24, 16); // diameter 1
  if (className === 'Cylinder') return new THREE.CylinderGeometry(0.5, 0.5, 1, 24);
  if (className === 'Wedge') {
    const shape = new THREE.Shape();
    shape.moveTo(-0.5, -0.5);
    shape.lineTo(0.5, -0.5);
    shape.lineTo(-0.5, 0.5);
    shape.lineTo(-0.5, -0.5);
    const geo = new THREE.ExtrudeGeometry(shape, { depth: 1, bevelEnabled: false });
    geo.rotateY(Math.PI / 2);
    geo.translate(0, 0, -0.5);
    geo.computeVertexNormals();
    return geo;
  }
  if (className === 'SpawnLocation') return new THREE.BoxGeometry(1, 1, 1);
  return new THREE.BoxGeometry(1, 1, 1); // Part
}

function defaultStudioScale(className) {
  if (className === 'SpawnLocation') return { x: 4, y: 0.2, z: 4 };
  if (className === 'Ball') return { x: 2, y: 2, z: 2 };
  if (className === 'Cylinder') return { x: 1.5, y: 2, z: 1.5 };
  if (className === 'Wedge') return { x: 2, y: 1, z: 2 };
  return { x: 2, y: 1, z: 2 }; // Part
}

function studioClassIcon(className, asHtml) {
  const name = (className || 'Part').replace(/\s+/g, '');
  const alias = {
    Ball: 'Part', Cylinder: 'Part', Wedge: 'Part',
    Workspace: 'Workspace', Baseplate: 'Part',
    TextChat: 'TextChatService', StarterCharacterScripts: 'StarterPlayer',
    StarterPlayerScripts: 'StarterPlayer'
  };
  const key = alias[name] || name;
  const src = `Assets/ClassIcons/${key}.png`;
  const fallbackEmoji = {
    Part: '🧊', Ball: '⚪', Cylinder: '🛢️', Wedge: '▲',
    SpawnLocation: '✳️', Model: '📦', Folder: '📁', Script: '📜',
    LocalScript: '📜', ScreenGui: '🖼️', Frame: '▭', TextLabel: '🔤',
    Camera: '📷', Terrain: '🏔️', Lighting: '💡', Players: '👥',
    Workspace: '🌐'
  }[name] || '📦';
  if (asHtml === false) return fallbackEmoji;
  return `<img class="tree-class-icon" src="${src}" alt="" onerror="this.style.display='none';this.nextElementSibling&&(this.nextElementSibling.style.display='inline');"/><span class="tree-class-emoji" style="display:none">${fallbackEmoji}</span>`;
}

function addStudioPart(className = 'Part') {
  if (typeof studioPushUndo === 'function') studioPushUndo();
  const geo = makeStudioGeometry(className);
  const color = className === 'SpawnLocation' ? 0x50be8c
    : className === 'Ball' ? 0x5b9dff
    : className === 'Cylinder' ? 0xe67e22
    : className === 'Wedge' ? 0x9b59b6
    : 0x9a9a9a;
  const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, roughness: 0.8 }));
  const sc = defaultStudioScale(className);
  mesh.scale.set(sc.x, sc.y, sc.z);
  const yOff = sc.y / 2 + 0.01;
  mesh.position.set((Math.random() - 0.5) * 6, yOff, (Math.random() - 0.5) * 6);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  studioScene.add(mesh);
  const id = 'p' + Math.random().toString(36).slice(2, 8);
  const count = studioObjects.filter(o => o.className === className).length + 1;
  const obj = {
    id, name: className + count,
    className, mesh, canCollide: true, anchored: true,
    shape: className, vy: 0
  };
  studioObjects.push(obj);
  renderStudioExplorer();
  selectStudioObject(obj);
}


function studioGetSelectedList() {
  if (studioMultiMode && studioSelectedIds.size) {
    return studioObjects.filter(o => studioSelectedIds.has(o.id));
  }
  return studioSelected ? [studioSelected] : [];
}

function studioDuplicateSelected() {
  const list = studioGetSelectedList();
  if (!list.length) return;
  const created = [];
  list.forEach(src => {
    const cls = src.className || 'Part';
    const mesh = new THREE.Mesh(
      makeStudioGeometry(cls),
      src.mesh.material.clone ? src.mesh.material.clone() : new THREE.MeshStandardMaterial({ color: src.mesh.material?.color?.getHex?.() || 0x9a9a9a, roughness: 0.8 })
    );
    mesh.position.copy(src.mesh.position).add(new THREE.Vector3(1.2, 0, 1.2));
    mesh.scale.copy(src.mesh.scale);
    mesh.rotation.copy(src.mesh.rotation);
    studioScene.add(mesh);
    const id = 'p' + Math.random().toString(36).slice(2, 8);
    const obj = {
      id, name: (src.name || cls) + '_Copy',
      className: cls, shape: src.shape || cls,
      mesh, canCollide: src.canCollide !== false, anchored: src.anchored !== false
    };
    studioObjects.push(obj);
    created.push(obj);
  });
  renderStudioExplorer();
  if (created.length === 1) selectStudioObject(created[0]);
}

function studioCopySelected() {
  const list = studioGetSelectedList();
  if (!list.length) return;
  studioClipboard = list.map(o => ({
    className: o.className, shape: o.shape || o.className, name: o.name,
    x: o.mesh.position.x, y: o.mesh.position.y, z: o.mesh.position.z,
    sx: o.mesh.scale.x, sy: o.mesh.scale.y, sz: o.mesh.scale.z,
    ry: o.mesh.rotation.y,
    color: o.mesh.material?.color?.getHex?.() || 0x9a9a9a,
    canCollide: o.canCollide !== false, anchored: o.anchored !== false
  }));
}

function studioPasteClipboard() {
  if (!studioClipboard || !studioClipboard.length) return;
  let last = null;
  studioClipboard.forEach(pd => {
    const cls = pd.className || 'Part';
    const mesh = new THREE.Mesh(
      makeStudioGeometry(cls),
      new THREE.MeshStandardMaterial({ color: pd.color || 0x9a9a9a, roughness: 0.8 })
    );
    mesh.position.set((pd.x || 0) + 1.5, pd.y || 0.5, (pd.z || 0) + 1.5);
    mesh.scale.set(pd.sx || 1, pd.sy || 1, pd.sz || 1);
    mesh.rotation.y = pd.ry || 0;
    studioScene.add(mesh);
    const id = 'p' + Math.random().toString(36).slice(2, 8);
    last = {
      id, name: (pd.name || cls) + '_Paste', className: cls, shape: pd.shape || cls,
      mesh, canCollide: pd.canCollide !== false, anchored: pd.anchored !== false
    };
    studioObjects.push(last);
  });
  renderStudioExplorer();
  if (last) selectStudioObject(last);
}

function studioDeleteSelected() {
  // Built-in explorer services cannot be deleted
  if (studioSelectedService && BUILTIN_SERVICES.has(studioSelectedService) && !studioSelected) {
    return;
  }
  // Virtual inserted instance
  if (studioSelected && studioSelected.virtual) {
    const parent = studioSelected.parent;
    if (studioInserted[parent]) {
      studioInserted[parent] = studioInserted[parent].filter(x => x.id !== studioSelected.id);
    }
    studioSelected = null;
    renderStudioExplorer();
    renderStudioProps();
    return;
  }
  const list = studioGetSelectedList();
  if (!list.length) return;
  list.forEach(o => {
    if (o.locked || BUILTIN_SERVICES.has(o.className)) return;
    if (o.mesh && studioScene) studioScene.remove(o.mesh);
    studioObjects = studioObjects.filter(x => x.id !== o.id);
    studioSelectedIds.delete(o.id);
  });
  studioSelected = null;
  if (studioTransform) { studioTransform.detach(); studioTransform.visible = false; }
  renderStudioExplorer();
  renderStudioProps();
  updateStudioSelectionBox();
}

function studioCutSelected() {
  studioCopySelected();
  studioDeleteSelected();
}

function studioSelectAll() {
  studioMultiMode = true;
  studioSelectedIds = new Set(studioObjects.map(o => o.id));
  if (studioObjects[0]) selectStudioObject(studioObjects[0]);
  renderStudioExplorer();
}

function studioToggleMulti() {
  studioMultiMode = !studioMultiMode;
  document.getElementById('studio-multi')?.classList.toggle('active', studioMultiMode);
  if (!studioMultiMode) studioSelectedIds.clear();
}

function studioGroupSelected() {
  const list = studioGetSelectedList();
  if (list.length < 2) { alert('Select 2+ parts to group'); return; }
  // parent under a folder-like marker name
  const gname = 'Model' + (studioObjects.filter(o => o.className === 'Model').length + 1);
  list.forEach(o => { o.groupName = gname; o.className = o.className === 'Model' ? o.className : o.className; });
  // create a Model entry that references group
  const id = 'g' + Math.random().toString(36).slice(2, 8);
  // use first mesh as representative
  const first = list[0];
  studioObjects.push({
    id, name: gname, className: 'Model', shape: 'Model',
    mesh: first.mesh, canCollide: true, anchored: true,
    isGroup: true, memberIds: list.map(o => o.id)
  });
  renderStudioExplorer();
  alert('Grouped as ' + gname);
}

function studioUngroupSelected() {
  const list = studioGetSelectedList().filter(o => o.isGroup || o.groupName);
  if (!list.length) { alert('Select a group'); return; }
  list.forEach(o => {
    if (o.isGroup) {
      studioObjects = studioObjects.filter(x => x.id !== o.id);
    } else {
      delete o.groupName;
    }
  });
  renderStudioExplorer();
}

function studioToggleAnchor() {
  const list = studioGetSelectedList();
  if (!list.length) return;
  const next = !(list[0].anchored !== false);
  list.forEach(o => { o.anchored = next; });
  renderStudioProps();
}

function studioApplyPaletteColor(hex, target) {
  if (typeof studioPushUndo === 'function') studioPushUndo();
  target = target || document.getElementById('studio-color-target')?.value || 'selected';
  let list = [];
  if (target === 'allparts' || target === 'model') {
    list = studioObjects.filter(o => o.mesh && o.className !== 'Model');
  } else {
    list = studioGetSelectedList();
  }
  if (!list.length) return;
  const col = new THREE.Color(hex);
  list.forEach(o => {
    if (!o.mesh) return;
    o.mesh.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => {
          if (m.color) m.color.copy(col);
          m.needsUpdate = true;
        });
      }
    });
  });
  renderStudioProps();
}

/** Load a published studio map into the main game scene for in-game play */
function clearCustomMap() {
  customMapMeshes.forEach(m => scene.remove(m));
  customMapMeshes = [];
  // remove custom platforms (keep baseplate roughly: large floor)
  const kept = [];
  platforms.forEach(p => {
    if (p._custom) {
      if (p.mesh) scene.remove(p.mesh);
    } else kept.push(p);
  });
  platforms.length = 0;
  kept.forEach(p => platforms.push(p));
  activePublishedGame = null;
}

function placePublishedPart(pd) {
  const cls = pd.className || pd.shape || 'Part';
  const def = defaultStudioScale(cls);
  const sx = (pd.sx != null && pd.sx > 0) ? pd.sx : def.x;
  const sy = (pd.sy != null && pd.sy > 0) ? pd.sy : def.y;
  const sz = (pd.sz != null && pd.sz > 0) ? pd.sz : def.z;
  const px = pd.x != null ? pd.x : 0;
  const py = pd.y != null ? pd.y : sy / 2;
  const pz = pd.z != null ? pd.z : 0;

  const finish = (mesh, isModel) => {
    mesh.position.set(px, py, pz);
    mesh.rotation.y = pd.ry || 0;
    if (!isModel) mesh.scale.set(sx, sy, sz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData.className = isModel ? 'Model' : cls;
    scene.add(mesh);
    customMapMeshes.push(mesh);
    const box = new THREE.Box3().setFromObject(mesh);
    const size = box.getSize(new THREE.Vector3());
    platforms.push({
      x: px, y: py, z: pz,
      sx: Math.max(Math.abs(size.x || sx), 0.2),
      sy: Math.max(Math.abs(size.y || sy), 0.2),
      sz: Math.max(Math.abs(size.z || sz), 0.2),
      mesh, hazard: false, _custom: true,
      canCollide: pd.canCollide !== false,
      anchored: pd.anchored !== false,
      className: isModel ? 'Model' : cls
    });
  };

  // GLTF / OBJ models from Studio → import as Model (not plain Part)
  if ((cls === 'Model' || pd.modelDataUrl || pd.modelId) && (pd.modelDataUrl || pd.modelId)) {
    const url = pd.modelDataUrl;
    const mime = (pd.modelMime || '').toLowerCase();
    const isGltf = mime.includes('gltf') || mime.includes('glb') || (url || '').includes('gltf') || (url || '').includes('glb');
    const isObj = mime.includes('obj') || (url || '').includes('obj') || (url || '').startsWith('data:text');
    if (url && isGltf && typeof GLTFLoader === 'function') {
      try {
        new GLTFLoader().load(url, (gltf) => {
          const root = gltf.scene || (gltf.scenes && gltf.scenes[0]);
          if (!root) {
            finish(new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), new THREE.MeshStandardMaterial({ color: 0x6a8cff })), true);
            return;
          }
          root.traverse(c => { if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; } });
          const box = new THREE.Box3().setFromObject(root);
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z, 0.01);
          const scale = Math.max(sx, sy, sz) / maxDim;
          root.scale.multiplyScalar(scale);
          finish(root, true);
        }, undefined, () => {
          finish(new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), new THREE.MeshStandardMaterial({ color: 0x6a8cff })), true);
        });
        return;
      } catch (_) {}
    }
    if (url && isObj) {
      try {
        const base64 = (url || '').split(',')[1];
        if (base64) {
          const textObj = atob(base64);
          const loader = new OBJLoader();
          const obj = loader.parse(textObj);
          const box = new THREE.Box3().setFromObject(obj);
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z, 0.01);
          obj.scale.setScalar(Math.max(sx, sy, sz) / maxDim);
          finish(obj, true);
          return;
        }
      } catch (_) {}
    }
    finish(new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), new THREE.MeshStandardMaterial({ color: 0x6a8cff, roughness: 0.5 })), true);
    return;
  }

  const mesh = new THREE.Mesh(
    makeStudioGeometry(cls),
    new THREE.MeshStandardMaterial({ color: pd.color || 0x9a9a9a, roughness: 0.85 })
  );
  finish(mesh, false);
}

function loadPublishedMap(gameData) {
  clearCustomMap();
  if (!gameData || !gameData.parts) return;
  activePublishedGame = gameData;
  // hide default obby parts that are not baseplate
  platforms.forEach(p => {
    if (p.mesh && !p._custom && p.sy > 0.3 && p.sx < 50) {
      p.mesh.visible = false;
      p._hiddenForCustom = true;
    }
  });
  gameData.parts.forEach(pd => placePublishedPart(pd));
  const spawnPart = gameData.parts.find(p => (p.className || p.shape) === 'SpawnLocation');
  if (spawnPart) {
    const sy = (spawnPart.sy != null && spawnPart.sy > 0) ? spawnPart.sy : 0.2;
    SPAWN.x = spawnPart.x || 0;
    SPAWN.y = (spawnPart.y != null ? spawnPart.y : 0) + sy / 2 + 1.2;
    SPAWN.z = spawnPart.z || 0;
  } else {
    SPAWN.x = 0; SPAWN.y = 2; SPAWN.z = 0;
  }
  applyGameSkyTexture();
}

function playPublishedGame(index) {
  const games = studioLoadGames();
  const g = games[index];
  if (!g) return;
  g.visits = (g.visits || 0) + 1;
  games[index] = g;
  studioSaveGames(games);
  account.playedGames = account.playedGames || [];
  if (!account.playedGames.includes(g.title)) account.playedGames.unshift(g.title);
  account.playedGames = account.playedGames.slice(0, 12);
  save(account);
  loadPublishedMap(g);
  startGame();
  document.getElementById('load-status').textContent = 'Joining ' + (g.title || 'Game') + '…';
}

function openGameDetail(index) {
  const games = studioLoadGames();
  const g = games[index];
  if (!g) return;
  currentDetailGameIndex = index;
  showScreen('detail');
  renderGameDetailPage(g, index);
}

let currentDetailGameIndex = null;

function renderGameDetailPage(g, index) {
  const root = document.getElementById('detail');
  if (!root) return;
  const thumb = g.thumbnail || ASSETS.dolex;
  const events = g.events || [];
  const visits = g.visits || 0;
  const likes = g.likes || 0;
  const created = g.created ? new Date(g.created).toLocaleDateString() : '—';
  const updated = g.updated ? new Date(g.updated).toLocaleDateString() : '—';
  root.innerHTML = `
    <button class="back" id="detail-back">Back</button>
    <div class="gdp-header">
      <img class="gdp-icon" src="${thumb}" alt="" onerror="this.src='${ASSETS.dolex}'"/>
      <div>
        <div class="gdp-title">${escapeHtml(g.title || 'Untitled')}</div>
        <div class="muted">${escapeHtml(account.username || 'Creator')} · Maturity: Minimal</div>
      </div>
    </div>
    <div class="gdp-banner">
      <img src="${thumb}" alt="" onerror="this.style.display='none'"/>
    </div>
    <div class="gdp-stats">
      <span>👍 ${likes}%</span>
      <span>👥 ${visits} visits</span>
      <button class="btn btn-dark" id="gdp-like" style="padding:6px 12px">Like</button>
      <button class="btn btn-dark" id="gdp-notify" style="padding:6px 12px">🔔 Notify</button>
    </div>
    <div class="gdp-section">
      <h3>Events</h3>
      <div class="gdp-events">${
        events.length ? events.map((ev, ei) => `
          <div class="gdp-event-card">
            ${ev.image ? `<img src="${ev.image}" alt=""/>` : ''}
            <div>
              <div class="gdp-event-title">${escapeHtml(ev.title || 'Event')}</div>
              <div class="muted">${escapeHtml(ev.sub || '')}</div>
              <div class="muted" style="font-size:0.75rem">📅 ${escapeHtml(ev.date || 'Date TBA')}</div>
              <button class="btn btn-dark event-notify-btn" data-event-index="${ei}" style="margin-top:6px;padding:5px 9px">🔔 Notify Me!</button>
            </div>
          </div>`).join('') : '<p class="muted">No events yet.</p>'
      }</div>
    </div>
    <div class="gdp-section">
      <h3>Description</h3>
      <p class="muted">${escapeHtml(g.desc || 'No description.')}</p>
      <p class="muted" style="margin-top:8px"><strong>How to Play:</strong> Explore the map and have fun!</p>
    </div>
    <div class="gdp-section">
      <h3>Servers</h3>
      <div id="gdp-servers">
        <div class="gdp-server-row"><span>Public Server</span><button class="btn btn-purple gdp-join-pub" style="padding:6px 14px">Join</button></div>
        ${(g.privateServers||[]).map((s, si) => `
          <div class="gdp-server-row"><span>🔒 ${escapeHtml(s.name || 'Private')}</span>
          <button class="btn btn-dark gdp-join-priv" data-si="${si}" style="padding:6px 14px">Join</button></div>
        `).join('')}
        <button class="btn btn-dark" id="gdp-create-priv" style="margin-top:8px;width:100%">+ Create Private Server</button>
      </div>
    </div>
    <div class="gdp-section">
      <h3>Information</h3>
      <div class="gdp-info-row"><span>Visits</span><span>${visits}</span></div>
      <div class="gdp-info-row"><span>Content Maturity</span><span>Minimal</span></div>
      <div class="gdp-info-row"><span>Developer</span><span>${escapeHtml(account.username || 'You')}</span></div>
      <div class="gdp-info-row"><span>Server Size</span><span>${g.serverSize || 10}</span></div>
      <div class="gdp-info-row"><span>Genre</span><span>${escapeHtml(g.category || 'Obby')}</span></div>
      <div class="gdp-info-row"><span>Created</span><span>${created}</span></div>
      <div class="gdp-info-row"><span>Updated</span><span>${updated}</span></div>
      <div class="gdp-info-row"><span>Voice Chat</span><span>Supported</span></div>
      <div class="gdp-info-row"><span>Camera</span><span>Supported</span></div>
    </div>
    <div class="gdp-section">
      <h3>Community</h3>
      <button class="btn btn-dark" id="gdp-add-community" style="width:100%">Add to Community</button>
    </div>
    <div class="gdp-section">
      <h3>Game Links</h3>
      <div class="game-links-row"><button class="btn btn-dark" id="gdp-copy-link">🔗 Copy Game Link</button><button class="btn btn-purple" id="gdp-share-game">Share Game</button></div>
      <p class="muted" style="margin-top:8px">dolex://game/${index}</p>
    </div>
    <div class="gdp-play-bar">
      <button class="btn btn-purple" id="btn-play" style="fdlex:1;padding:14px;font-size:1.1rem">▶ Play</button>
    </div>
  `;
  document.getElementById('detail-back').onclick = () => { showScreen('lobby'); renderHome(); };
  document.getElementById('gdp-copy-link')?.addEventListener('click',()=>{const u=location.href.split('#')[0]+'#game='+index;if(navigator.clipboard)navigator.clipboard.writeText(u);alert('Game link copied!');});
  document.getElementById('gdp-share-game')?.addEventListener('click',()=>{const u=location.href.split('#')[0]+'#game='+index;if(navigator.share)navigator.share({title:g.title||'DoLex Game',text:g.desc||'',url:u}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(u).then(()=>alert('Game link copied!'));});
  document.getElementById('btn-play').onclick = () => playPublishedGame(index);
  document.querySelectorAll('.gdp-join-pub').forEach(b => b.onclick = () => playPublishedGame(index));
  document.getElementById('gdp-like')?.addEventListener('click', () => {
    const games = studioLoadGames();
    if (!games[index]) return;
    games[index].likes = (games[index].likes || 0) + 1;
    studioSaveGames(games);
    renderGameDetailPage(games[index], index);
  });
  document.querySelectorAll('.event-notify-btn').forEach(b=>b.addEventListener('click',()=>{ const ev=(g.events||[])[+b.dataset.eventIndex]; account.notifications=account.notifications||[]; account.notifications.push({title:`Event reminder: ${ev?.title||'Event'}`, body:`${ev?.date||'Date TBA'}`, t:Date.now()}); save(account); b.textContent='✓ Notified'; }));
  document.getElementById('gdp-create-priv')?.addEventListener('click', () => {
    const name = prompt('Private server name:', 'My Server');
    if (!name) return;
    const games = studioLoadGames();
    games[index].privateServers = games[index].privateServers || [];
    games[index].privateServers.push({ name: name.trim(), owner: account.username, t: Date.now() });
    studioSaveGames(games);
    renderGameDetailPage(games[index], index);
  });
  document.querySelectorAll('.gdp-join-priv').forEach(b => {
    b.onclick = () => playPublishedGame(index);
  });
  document.getElementById('gdp-add-community')?.addEventListener('click', () => {
    const cname = prompt('Community / Group name to add this game to:');
    if (!cname || !cname.trim()) return;
    account.groups_joined = account.groups_joined || [];
    if (!account.groups_joined.includes(cname.trim())) account.groups_joined.push(cname.trim());
    const games = studioLoadGames();
    games[index].communityIds = games[index].communityIds || [];
    if (!games[index].communityIds.includes(cname.trim())) games[index].communityIds.push(cname.trim());
    studioSaveGames(games);
    save(account);
    alert('Added to community: ' + cname.trim());
  });
}

function openEventEditor(gameIndex) {
  currentDetailGameIndex = gameIndex;
  showScreen('event-editor');
  const games = studioLoadGames();
  const g = games[gameIndex];
  document.getElementById('ev-game-title').textContent = g ? (g.title || 'Game') : '';
  document.getElementById('ev-title').value = '';
  document.getElementById('ev-desc').value = '';
  document.getElementById('ev-sub').value = '';
  document.getElementById('ev-date').value = '';
  document.getElementById('ev-image-preview').innerHTML = '<span class="muted">No image</span>';
  window._evImageData = null;
}

function startStudioPlay() {
  if (studioPlaying) return;
  studioPlaying = true;
  document.getElementById('studio-play').disabled = true;
  document.getElementById('studio-stop').disabled = false;
  document.getElementById('studio-hint').textContent = 'Play Test — your character · joystick or WASD';
  document.getElementById('studio-joystick-zone')?.classList.add('active');
  if (studioTransform) {
    studioTransform.detach();
    studioTransform.visible = false;
    studioTransform.enabled = false;
  }
  if (studioOrbit) studioOrbit.enabled = false;

  let spawn = { x: 0, y: 1, z: 0 };
  const sl = studioObjects.find(o => o.className === 'SpawnLocation');
  if (sl) {
    spawn = { x: sl.mesh.position.x, y: sl.mesh.position.y + (sl.mesh.scale.y || 1) * 0.15 + 1.2, z: sl.mesh.position.z };
  }
  if (studioPlayerMesh) {
    studioScene.remove(studioPlayerMesh);
    studioPlayerMesh = null;
  }
  // Prefer real avatar character if loaded
  if (typeof character !== 'undefined' && character) {
    studioPlayerMesh = character.clone(true);
    studioPlayerMesh.traverse(c => {
      if (c.isMesh && c.material) {
        c.material = Array.isArray(c.material) ? c.material.map(m => m.clone()) : c.material.clone();
      }
    });
  } else {
    const geo = new THREE.CapsuleGeometry(0.4, 1.0, 6, 12);
    const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(account.avatarColor || '#5b9dff'), roughness: 0.4 });
    studioPlayerMesh = new THREE.Mesh(geo, mat);
  }
  studioPlayerMesh.position.set(spawn.x, spawn.y, spawn.z);
  studioPlayerMesh.userData.vy = 0;
  studioScene.add(studioPlayerMesh);
  studioCam.position.set(spawn.x + 6, spawn.y + 4, spawn.z + 8);
  studioCam.lookAt(spawn.x, spawn.y + 1, spawn.z);
}

function stopStudioPlay() {
  studioPlaying = false;
  document.getElementById('studio-play').disabled = false;
  document.getElementById('studio-stop').disabled = true;
  document.getElementById('studio-hint').textContent = 'Orbit: drag · Pan: right-drag · Zoom: scroll · Select parts';
  document.getElementById('studio-joystick-zone')?.classList.remove('active');
  if (studioPlayerMesh) {
    studioScene.remove(studioPlayerMesh);
    studioPlayerMesh = null;
  }
  if (studioOrbit) studioOrbit.enabled = true;
  updateStudioGizmo();
}


let studioTab = 'home';
function setStudioTab(tab){
  studioTab = tab || 'home';
  document.querySelectorAll('.studio-tab').forEach(b =>
    b.classList.toggle('active', b.dataset.studioTab === studioTab)
  );
  const panel = document.getElementById('studio-tab-panel');
  const tool = document.getElementById('studio-transform-tools');
  const edit = document.querySelector('.studio-edit-tools');
  const ins = document.querySelector('.studio-insert-wrap');
  const toolbar = document.getElementById('studio-toolbar');

  // Home = Roblox-style top tools bar only (Select / Move / Scale / Rotate / Insert…)
  // View / Avatar / UI / Plugins / Insert ID open floating panels
  const isHome = studioTab === 'home';
  const panelTabs = ['view', 'avatar', 'ui', 'script', 'plugins', 'model'];
  if (panel) {
    if (panelTabs.includes(studioTab)) panel.classList.remove('hidden');
    else panel.classList.add('hidden');
  }
  // Toolbar always visible; Home keeps transform + insert tools
  if (toolbar) toolbar.style.display = 'flex';
  if (tool) tool.style.display = 'flex';
  if (edit) edit.style.display = isHome ? 'flex' : 'flex';
  if (ins) ins.style.display = isHome ? 'block' : 'block';
  toolbar?.classList.toggle('tab-home', isHome);
  toolbar?.classList.toggle('tab-other', !isHome);

  document.querySelectorAll('[data-studio-panel]').forEach(p => {
    const on = p.dataset.studioPanel === studioTab && !isHome;
    p.classList.toggle('active', on);
    p.style.display = on ? 'block' : 'none';
  });
}
function addStudioAvatarByQuery(q){
  const status=document.getElementById('studio-avatar-status');
  q=(q||'').trim(); if(!q){if(status)status.textContent='Enter a username or User ID.';return;}
  if(status)status.textContent='Looking up avatar…';
  const resolve=async()=>{
    let uid=q;
    if(!/^\d+$/.test(q)){
      const r=await fetch('https://users.roblox.com/v1/usernames/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({usernames:[q],excludeBannedUsers:false})});
      const j=await r.json(); uid=j.data?.[0]?.id;
      if(!uid)throw new Error('Username not found');
    }
    const tr=await fetch(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${uid}&size=420x420&format=Png&isCircular=false`); const tj=await tr.json(); const image=tj.data?.[0]?.imageUrl;
    const mesh=new THREE.Mesh(new THREE.CapsuleGeometry(.55,1.1,6,12),new THREE.MeshStandardMaterial({color:0x5b9dff})); mesh.position.set(0,1,0); studioScene.add(mesh);
    studioObjects.push({id:'avatar_'+uid+'_'+Date.now(),name:`Avatar ${q}`,className:'Model',shape:'Model',mesh,canCollide:false,anchored:true,avatarUserId:String(uid),avatarImage:image||''});
    selectStudioObject(studioObjects[studioObjects.length-1]); renderStudioExplorer();
    if(status)status.textContent=`Added avatar for ${q} (User ID ${uid}).`;
  };
  resolve().catch(e=>{if(status)status.textContent='Could not load avatar: '+e.message;});
}
function addStudio3DText(text, color) {
  text = (text || '').trim();
  if (!text) { alert('Type some text first'); return; }
  const loader = new THREE.FontLoader();
  loader.load('https://cdn.jsdelivr.net/npm/three@0.160.0/examples/fonts/helvetiker_bold.typeface.json', font => {
    const geo = new TextGeometry(text, {
      font, size: 0.65, height: 0.18, curveSegments: 6,
      bevelEnabled: true, bevelThickness: 0.025, bevelSize: 0.018, bevelSegments: 2
    });
    geo.center();
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
      color: color || 0xffffff, roughness: 0.45, metalness: 0.1
    }));
    mesh.position.set(0, 1, 0);
    studioScene.add(mesh);
    studioObjects.push({
      id: 'text_' + Date.now(),
      name: '3DText ' + text,
      className: 'Model',
      shape: 'Model',
      mesh,
      canCollide: false,
      anchored: true,
      textContent: text,
      textColor: color || '#ffffff'
    });
    selectStudioObject(studioObjects[studioObjects.length - 1]);
    renderStudioExplorer();
  }, undefined, () => alert('3D Text font could not load. Connect to the internet and try again.'));
}

function importStudioAssetById(type, assetId) {
  type = (type || 'decal').toLowerCase();
  assetId = (assetId || '').trim();
  if (!assetId) { alert('Paste a Decal ID or Model ID'); return; }
  if (type === 'decal') {
    let list = [];
    try { list = JSON.parse(localStorage.getItem('dolex_decals_v1') || '[]'); } catch {}
    const item = list.find(d => d.id === assetId);
    if (!item) { alert('Decal ID not found. Upload it under Create → Development Items → Decal.'); return; }
    const loader = new THREE.TextureLoader();
    loader.load(item.dataUrl, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      const geo = new THREE.PlaneGeometry(2, 2);
      const mat = new THREE.MeshStandardMaterial({ map: tex, transparent: true, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(0, 1.5, 0);
      studioScene.add(mesh);
      studioObjects.push({
        id: 'decal_' + Date.now(),
        name: item.name || 'Decal',
        className: 'Part',
        shape: 'Part',
        mesh,
        canCollide: false,
        anchored: true,
        decalId: item.id,
        decalDataUrl: item.dataUrl
      });
      selectStudioObject(studioObjects[studioObjects.length - 1]);
      renderStudioExplorer();
      alert('Decal imported onto Baseplate viewport.');
    }, undefined, () => alert('Failed to load decal texture'));
  } else {
    let list = [];
    try { list = JSON.parse(localStorage.getItem('dolex_models_v1') || '[]'); } catch {}
    const item = list.find(m => m.id === assetId);
    if (!item) { alert('Model ID not found. Upload it under Create → Development Items → Model.'); return; }
    const name = (item.filename || item.name || '').toLowerCase();
    // Place a proxy mesh; if OBJ text available try simple parse, else colored box labeled as model
    const placeProxy = (extra = {}) => {
      const geo = new THREE.BoxGeometry(1.5, 1.5, 1.5);
      const mat = new THREE.MeshStandardMaterial({ color: 0x6a8cff, roughness: 0.5 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(0, 0.75, 0);
      studioScene.add(mesh);
      studioObjects.push({
        id: 'model_' + Date.now(),
        name: item.name || 'Model',
        className: 'Model',
        shape: 'Model',
        mesh,
        canCollide: true,
        anchored: true,
        modelId: item.id,
        modelDataUrl: item.dataUrl,
        modelMime: item.mime,
        ...extra
      });
      selectStudioObject(studioObjects[studioObjects.length - 1]);
      renderStudioExplorer();
      alert('Model imported onto Baseplate viewport.');
    };
    const isGltf = name.endsWith('.gltf') || name.endsWith('.glb') || (item.mime || '').includes('gltf') || (item.mime || '').includes('glb');
    if (isGltf && item.dataUrl) {
      try {
        new GLTFLoader().load(item.dataUrl, (gltf) => {
          const root = gltf.scene || (gltf.scenes && gltf.scenes[0]);
          if (!root) { placeProxy(); return; }
          root.traverse(c => { if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; } });
          const box = new THREE.Box3().setFromObject(root);
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z, 0.01);
          const s = 2 / maxDim;
          root.scale.setScalar(s);
          const center = box.getCenter(new THREE.Vector3());
          root.position.sub(center.multiplyScalar(s));
          root.position.y = size.y * s / 2;
          studioScene.add(root);
          studioObjects.push({
            id: 'model_' + Date.now(),
            name: item.name || 'Model',
            className: 'Model',
            shape: 'Model',
            mesh: root,
            canCollide: true,
            anchored: true,
            modelId: item.id,
            modelDataUrl: item.dataUrl,
            modelMime: item.mime || 'model/gltf-binary'
          });
          selectStudioObject(studioObjects[studioObjects.length - 1]);
          renderStudioExplorer();
          alert('Model imported onto Baseplate viewport.');
        }, undefined, () => placeProxy());
        return;
      } catch (e) { console.warn(e); }
    }
    if (name.endsWith('.obj') || (item.mime || '').includes('obj')) {
      try {
        const base64 = (item.dataUrl || '').split(',')[1];
        if (base64) {
          const textObj = atob(base64);
          const loader = new OBJLoader();
          const obj = loader.parse(textObj);
          const box = new THREE.Box3().setFromObject(obj);
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z) || 1;
          const s = 2 / maxDim;
          obj.scale.setScalar(s);
          const center = box.getCenter(new THREE.Vector3());
          obj.position.sub(center.multiplyScalar(s));
          obj.position.y = size.y * s / 2;
          studioScene.add(obj);
          studioObjects.push({
            id: 'model_' + Date.now(),
            name: item.name || 'Model',
            className: 'Model',
            shape: 'Model',
            mesh: obj,
            canCollide: true,
            anchored: true,
            modelId: item.id,
            modelDataUrl: item.dataUrl,
            modelMime: item.mime
          });
          selectStudioObject(studioObjects[studioObjects.length - 1]);
          renderStudioExplorer();
          alert('Model imported onto Baseplate viewport.');
          return;
        }
      } catch (e) { console.warn(e); }
    }
    placeProxy();
  }
}

function openStudio3DTextPanel() {
  const panel = document.getElementById('studio-3dtext-panel');
  if (!panel) return;
  panel.classList.add('open');
  // simple drag
  const head = document.getElementById('studio-3dtext-drag');
  if (head && !head._dragBound) {
    head._dragBound = true;
    let ox = 0, oy = 0, dragging = false;
    head.addEventListener('pointerdown', (e) => {
      dragging = true;
      ox = e.clientX - panel.offsetLeft;
      oy = e.clientY - panel.offsetTop;
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      panel.style.left = Math.max(0, e.clientX - ox) + 'px';
      panel.style.top = Math.max(0, e.clientY - oy) + 'px';
      panel.style.right = 'auto';
    });
    head.addEventListener('pointerup', () => { dragging = false; });
  }
  document.getElementById('studio-3dtext-close')?.addEventListener('click', () => {
    panel.classList.remove('open');
  });
}


function openDLStudio(existing, index) {
  studioOpen = true;
  showJoiningScreen('Opening Studio…', 'Preparing viewport…');
  lockOrientation('portrait');
  setTimeout(function(){
    hideJoiningScreen();
    lockOrientation('landscape');
    try { if (typeof wireStudioEnhancements === 'function') wireStudioEnhancements(); } catch(e) { console.warn(e); }
  }, 600);
  document.querySelectorAll('.studio-tab').forEach(b=>b.onclick=()=>setStudioTab(b.dataset.studioTab));
  document.getElementById('studio-avatar-add')?.addEventListener('click',()=>addStudioAvatarByQuery(document.getElementById('studio-avatar-query')?.value));
  document.getElementById('studio-ui-apply')?.addEventListener('click',()=>{
    const c=document.getElementById('studio-ui-color')?.value||'#8c50ff', r=document.getElementById('studio-ui-radius')?.value||12, t=document.getElementById('studio-ui-transparency')?.value||0;
    studioScene.background=new THREE.Color(c); document.getElementById('studio-tab-panel').style.borderRadius=r+'px'; document.getElementById('studio-tab-panel').style.opacity=1-(t/100);
  });
  document.querySelectorAll('.studio-plugin-add').forEach(b => b.onclick = () => {
    if (b.dataset.plugin === '3dtext') {
      openStudio3DTextPanel();
      b.textContent = '✓ Added';
    } else {
      b.textContent = '✓ Added';
    }
  });
  document.getElementById('studio-plugin-search-btn')?.addEventListener('click', () => {
    const q = (document.getElementById('studio-plugin-search')?.value || '').toLowerCase();
    const results = ['3D Text', 'UI Builder', 'Model Tools', 'Terrain Tools', 'Animation Tools'].filter(x => x.toLowerCase().includes(q) || !q);
    document.getElementById('studio-plugin-results').innerHTML = results.map(x =>
      `<div class="studio-plugin-result">${x}<button class="btn btn-dark" data-result-plugin="${x}">Add</button></div>`
    ).join('');
    document.querySelectorAll('[data-result-plugin]').forEach(btn => {
      btn.onclick = () => {
        if (btn.dataset.resultPlugin === '3D Text') openStudio3DTextPanel();
        btn.textContent = '✓';
      };
    });
  });
  document.getElementById('studio-3dtext-create')?.addEventListener('click', () =>
    addStudio3DText(document.getElementById('studio-3dtext-input')?.value, document.getElementById('studio-3dtext-color')?.value)
  );
  document.getElementById('studio-import-btn')?.addEventListener('click', () => {
    const type = document.getElementById('studio-import-type')?.value || 'decal';
    const id = document.getElementById('studio-import-id')?.value || '';
    importStudioAssetById(type, id);
  });
  setStudioTab('home');

  studioPlaying = false;
  studioGameIndex = (typeof index === 'number') ? index : null;
  document.getElementById('ui-root').style.display = 'none';
  document.getElementById('dlstudio')?.classList.remove('hidden');
  document.getElementById('publish-page')?.classList.add('hidden');
  lockOrientation('landscape');

  const canvasEl = document.getElementById('studio-canvas');
  if (!canvasEl) return;
  if (studioAnim) cancelAnimationFrame(studioAnim);
  if (studioTransform) { try { studioTransform.dispose(); } catch {} studioTransform = null; }
  if (studioOrbit) { try { studioOrbit.dispose(); } catch {} studioOrbit = null; }
  if (studioRenderer) studioRenderer.dispose();

  const w = canvasEl.clientWidth || Math.max(320, window.innerWidth - 40);
  const h = canvasEl.clientHeight || Math.max(240, window.innerHeight - 80);
  studioRenderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true });
  studioRenderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  studioRenderer.setSize(w, h, false);
  studioRenderer.outputColorSpace = THREE.SRGBColorSpace;
  studioScene = new THREE.Scene();
  studioScene.background = new THREE.Color(0x87ceeb);
  try { if (typeof applyStudioSkybox === 'function') applyStudioSkybox('clouds'); } catch (_) {}
  studioScene.add(new THREE.AmbientLight(0xffffff, 0.75));
  const light = new THREE.DirectionalLight(0xffffff, 0.95);
  light.position.set(12, 22, 10);
  studioScene.add(light);
  const grid = new THREE.GridHelper(40, 40, 0x444466, 0x333355);
  studioScene.add(grid);
  const base = new THREE.Mesh(
    new THREE.BoxGeometry(40, 0.2, 40),
    new THREE.MeshStandardMaterial({ color: 0x5a5a6a, roughness: 0.9 })
  );
  base.position.y = -0.1;
  base.receiveShadow = true;
  studioScene.add(base);

  studioCam = new THREE.PerspectiveCamera(50, w / Math.max(h, 1), 0.1, 300);
  studioCam.position.set(10, 8, 12);
  studioCam.lookAt(0, 0, 0);

  studioOrbit = new OrbitControls(studioCam, canvasEl);
  studioOrbit.enableDamping = true;
  studioOrbit.dampingFactor = 0.08;
  studioOrbit.target.set(0, 1, 0);
  studioOrbit.minDistance = 2;
  studioOrbit.maxDistance = 80;
  studioOrbit.maxPolarAngle = Math.PI * 0.92;

  studioObjects = [];
  studioSelected = null;
  studioPlayerMesh = null;
  if (existing && existing.parts) {
    existing.parts.forEach(pd => {
      const cls = pd.className || pd.shape || 'Part';
      const { mesh, meta } = rebuildStudioObjectFromPd({
        ...pd,
        // ensure scales applied after rebuild defaults
      });
      const def = defaultStudioScale(cls);
      const sx = (pd.sx != null && pd.sx > 0) ? pd.sx : (mesh.scale.x || def.x);
      const sy = (pd.sy != null && pd.sy > 0) ? pd.sy : (mesh.scale.y || def.y);
      const sz = (pd.sz != null && pd.sz > 0) ? pd.sz : (mesh.scale.z || def.z);
      mesh.scale.set(sx, sy, sz);
      mesh.position.set(pd.x != null ? pd.x : 0, pd.y != null ? pd.y : sy / 2, pd.z != null ? pd.z : 0);
      mesh.rotation.y = pd.ry || 0;
      studioScene.add(mesh);
      studioObjects.push({
        id: pd.id || ('p' + Math.random().toString(36).slice(2, 8)),
        name: pd.name || cls,
        className: cls,
        shape: pd.shape || cls,
        mesh,
        canCollide: pd.canCollide !== false,
        anchored: pd.anchored !== false,
        vy: 0,
        ...meta
      });
    });
  } else {
    addStudioPart('SpawnLocation');
  }

  buildStudioGizmo();
  renderStudioExplorer();
  selectStudioObject(studioObjects[0] || null);

  document.querySelectorAll('.studio-tool').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.studio-tool').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      studioTool = btn.dataset.tool || 'select';
      updateStudioGizmo();
    };
  });

  document.getElementById('studio-play').onclick = () => startStudioPlay();
  document.getElementById('studio-stop').onclick = () => stopStudioPlay();
  document.getElementById('studio-play').disabled = false;
  document.getElementById('studio-stop').disabled = true;

  const fileBtn = document.getElementById('studio-file-btn');
  const fileMenu = document.getElementById('studio-file-menu');
  fileBtn.onclick = (e) => {
    e.stopPropagation();
    fileMenu.classList.toggle('hidden');
  };
  fileMenu.querySelectorAll('button').forEach(b => {
    b.onclick = () => {
      fileMenu.classList.add('hidden');
      const act = b.dataset.studioAction;
      if (act === 'close') closeDLStudio();
      else if (act === 'new') {
        stopStudioPlay();
        studioObjects.forEach(o => studioScene.remove(o.mesh));
        studioObjects = [];
        addStudioPart('SpawnLocation');
        renderStudioExplorer();
        selectStudioObject(studioObjects[0] || null);
      } else if (act === 'save' || act === 'saveas') {
        try {
          const payload = {
            title: (document.getElementById('pub-title')?.value || 'Untitled').trim() || 'Untitled',
            savedAt: Date.now(),
            objects: studioObjects.map(o => ({
              id: o.id, name: o.name, className: o.className, shape: o.shape,
              position: o.mesh ? { x: o.mesh.position.x, y: o.mesh.position.y, z: o.mesh.position.z } : null,
              scale: o.mesh ? { x: o.mesh.scale.x, y: o.mesh.scale.y, z: o.mesh.scale.z } : null,
              anchored: o.anchored !== false, canCollide: o.canCollide !== false
            }))
          };
          localStorage.setItem('dolex_studio_save_v1', JSON.stringify(payload));
          alert(act === 'saveas' ? 'Saved as local Studio project.' : 'Studio project saved.');
        } catch (err) {
          alert('Could not save: ' + (err && err.message ? err.message : 'storage error'));
        }
      } else if (act === 'publish') openPublishPage();
    };
  });
  // Click outside closes File menu but keep it above viewport while open
  document.addEventListener('click', (ev) => {
    if (!fileMenu || fileMenu.classList.contains('hidden')) return;
    if (fileBtn?.contains(ev.target) || fileMenu.contains(ev.target)) return;
    fileMenu.classList.add('hidden');
  });
  document.getElementById('studio-exit').onclick = closeDLStudio;

  // Edit tools (Cut/Copy/Paste/Delete/Group etc. on context menu only – Roblox Studio style)
  document.getElementById('studio-undo')?.addEventListener('click', studioUndo);
  document.getElementById('studio-redo')?.addEventListener('click', studioRedo);
  document.getElementById('studio-script-editor')?.addEventListener('click', () => {
    alert('Script Editor\n\nInsert a Script under Workspace (Insert menu → Script), then edit in Properties.');
  });
  const ctxMenuEl = document.getElementById('studio-ctx-menu');
  ctxMenuEl?.querySelectorAll('[data-ctx]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const act = btn.dataset.ctx;
      ctxMenuEl.classList.add('hidden');
      if (act === 'insert') {
        const parent = (studioSelected && studioSelected.parent) || studioSelectedService || 'Workspace';
        openClassPicker(parent);
      } else if (act === 'cut') { studioPushUndo(); studioCutSelected(); }
      else if (act === 'copy') { studioCopySelected(); }
      else if (act === 'move') {
        studioTool = 'move';
        document.querySelectorAll('.studio-tool').forEach(b => b.classList.remove('active'));
        document.querySelector('.studio-tool[data-tool="move"]')?.classList.add('active');
        if (typeof updateStudioGizmo === 'function') updateStudioGizmo();
      } else if (act === 'paste') { studioPushUndo(); studioPasteClipboard(); }
      else if (act === 'duplicate') { studioPushUndo(); studioDuplicateSelected(); }
      else if (act === 'selectall') { studioSelectAll(); }
      else if (act === 'selectmulti') { studioToggleMulti(); }
      else if (act === 'delete') { studioPushUndo(); studioDeleteSelected(); }
      else if (act === 'group') { studioGroupSelected(); }
      else if (act === 'ungroup') { studioUngroupSelected(); }
    });
  });
  document.getElementById('studio-anchor-btn')?.addEventListener('click', studioToggleAnchor);
  document.getElementById('studio-palette')?.addEventListener('input', (e) => {
    // live preview on selected only
    studioApplyPaletteColor(e.target.value, 'selected');
  });
  document.querySelectorAll('#studio-swatches button').forEach(btn => {
    btn.addEventListener('click', () => {
      const hex = btn.dataset.hex;
      const pal = document.getElementById('studio-palette');
      if (pal) pal.value = hex;
      studioApplyPaletteColor(hex);
    });
  });
  document.getElementById('studio-color-apply')?.addEventListener('click', () => {
    const hex = document.getElementById('studio-palette')?.value || '#9a9a9a';
    studioApplyPaletteColor(hex);
  });

  // Insert Part / Ball / Cylinder / Wedge
  const insertBtn = document.getElementById('studio-insert-btn');
  const insertMenu = document.getElementById('studio-insert-menu');
  if (insertBtn && insertMenu) {
    insertBtn.onclick = (e) => {
      e.stopPropagation();
      fileMenu?.classList.add('hidden');
      insertMenu.classList.toggle('hidden');
    };
    insertMenu.querySelectorAll('button').forEach(b => {
      b.onclick = () => {
        insertMenu.classList.add('hidden');
        const kind = b.dataset.insert || 'Part';
        if (kind === 'Script') {
          // Virtual Script instance under Workspace (like Roblox Studio)
          const parent = 'Workspace';
          if (!studioInserted[parent]) studioInserted[parent] = [];
          const id = 'ins_' + Date.now().toString(36);
          studioInserted[parent].unshift({ id, name: 'Script', className: 'Script', props: { Source: '-- script' } });
          renderStudioExplorer();
          return;
        }
        addStudioPart(kind);
      };
    });
  }

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  canvasEl.onpointerdown = (e) => {
    if (studioPlaying) return;
    if (studioTransform && studioTransform.dragging) return;
    const rect = canvasEl.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, studioCam);
    const meshes = studioObjects.map(o => o.mesh);
    const hits = raycaster.intersectObjects(meshes, true);
    if (hits.length) {
      const mesh = hits[0].object;
      let found = studioObjects.find(o => o.mesh === mesh);
      if (!found) {
        found = studioObjects.find(o => {
          let ok = false;
          o.mesh.traverse(c => { if (c === mesh) ok = true; });
          return ok;
        });
      }
      if (found) {
        if (studioMultiMode) {
          if (studioSelectedIds.has(found.id)) studioSelectedIds.delete(found.id);
          else studioSelectedIds.add(found.id);
          selectStudioObject(found);
        } else {
          studioSelectedIds.clear();
          selectStudioObject(found);
        }
      }
    }
  };

  canvasEl.ondblclick = () => {
    if (!studioPlaying) addStudioPart('Part');
  };

  const sJoyZone = document.getElementById('studio-joystick-zone');
  const sJoyBase = document.getElementById('studio-joystick-base');
  const sJoyKnob = document.getElementById('studio-joystick-knob');
  let sJoyR = 40;
  const setSKnob = (dx, dy) => {
    sJoyKnob.style.left = '50%';
    sJoyKnob.style.top = '50%';
    sJoyKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  };
  const updateSJoy = (cx, cy) => {
    const rect = sJoyBase.getBoundingClientRect();
    const cx0 = rect.left + rect.width / 2;
    const cy0 = rect.top + rect.height / 2;
    let dx = cx - cx0, dy = cy - cy0;
    const m = Math.hypot(dx, dy);
    if (m > sJoyR) { dx = (dx / m) * sJoyR; dy = (dy / m) * sJoyR; }
    setSKnob(dx, dy);
    studioJoyDX = dx / sJoyR;
    studioJoyDY = dy / sJoyR;
  };
  const sJoyEnd = () => {
    studioJoyActive = false;
    studioJoyDX = 0; studioJoyDY = 0;
    setSKnob(0, 0);
  };
  sJoyZone.onpointerdown = (e) => {
    if (!studioPlaying) return;
    e.preventDefault(); e.stopPropagation();
    studioJoyActive = true;
    sJoyR = Math.min(sJoyBase.getBoundingClientRect().width, sJoyBase.getBoundingClientRect().height) * 0.38;
    updateSJoy(e.clientX, e.clientY);
    sJoyZone.setPointerCapture?.(e.pointerId);
  };
  sJoyZone.onpointermove = (e) => {
    if (!studioJoyActive) return;
    e.preventDefault();
    updateSJoy(e.clientX, e.clientY);
  };
  sJoyZone.onpointerup = sJoyEnd;
  sJoyZone.onpointercancel = sJoyEnd;

  const onResize = () => {
    if (!studioOpen || !studioRenderer || !studioCam) return;
    const ww = canvasEl.clientWidth || 320;
    const hh = canvasEl.clientHeight || 240;
    studioCam.aspect = ww / Math.max(hh, 1);
    studioCam.updateProjectionMatrix();
    studioRenderer.setSize(ww, hh, false);
  };
  window.addEventListener('resize', onResize);

  function tick() {
    if (!studioOpen) return;
    studioAnim = requestAnimationFrame(tick);
    const dt = Math.min(0.05, studioClock.getDelta());

    if (studioOrbit && !studioPlaying) studioOrbit.update();

    if (studioPlaying && studioPlayerMesh) {
      let fx = 0, fz = 0;
      if (keys['KeyW'] || keys['ArrowUp']) fz += 1;
      if (keys['KeyS'] || keys['ArrowDown']) fz -= 1;
      if (keys['KeyA'] || keys['ArrowLeft']) fx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) fx += 1;
      if (studioJoyActive) {
        fx += studioJoyDX;
        fz += -studioJoyDY;
      }
      const mag = Math.hypot(fx, fz);
      if (mag > 1) { fx /= mag; fz /= mag; }
      const camDir = new THREE.Vector3();
      studioCam.getWorldDirection(camDir);
      camDir.y = 0; camDir.normalize();
      const camRight = new THREE.Vector3().crossVectors(camDir, new THREE.Vector3(0, 1, 0)).normalize();
      const speed = 7;
      if (mag > 0.08) {
        studioPlayerMesh.position.x += (camRight.x * fx + camDir.x * fz) * speed * dt;
        studioPlayerMesh.position.z += (camRight.z * fx + camDir.z * fz) * speed * dt;
      }
      studioPlayerMesh.userData.vy = (studioPlayerMesh.userData.vy || 0) - 24 * dt;
      studioPlayerMesh.position.y += studioPlayerMesh.userData.vy * dt;
      if (studioPlayerMesh.position.y < 1) {
        studioPlayerMesh.position.y = 1;
        studioPlayerMesh.userData.vy = 0;
      }
      if (keys['Space'] && studioPlayerMesh.position.y <= 1.05) {
        studioPlayerMesh.userData.vy = 9;
      }
      const px = studioPlayerMesh.position.x;
      const py = studioPlayerMesh.position.y;
      const pz = studioPlayerMesh.position.z;
      studioCam.position.lerp(new THREE.Vector3(px + 5, py + 3.5, pz + 7), 0.08);
      studioCam.lookAt(px, py + 0.8, pz);
    }

    // Unanchored parts fall (studio physics)
    if (!studioPlaying) {
      studioObjects.forEach(o => {
        if (!o.mesh || o.anchored !== false) return;
        o.vy = (o.vy || 0) - 24 * dt;
        o.mesh.position.y += o.vy * dt;
        const halfH = Math.abs(o.mesh.scale.y) / 2;
        // land on y=0 ground plane
        if (o.mesh.position.y - halfH < 0) {
          o.mesh.position.y = halfH;
          o.vy = 0;
        }
      });
    }

    updateStudioSelectionBox();
    if (studioRenderer && studioScene && studioCam) {
      studioRenderer.render(studioScene, studioCam);
    }
  }
  studioClock.getDelta();
  tick();
}

let pubThumbnailData = null;

function setPubThumbPreview(dataUrl) {
  const prev = document.getElementById('pub-thumb-preview');
  if (!prev) return;
  if (dataUrl) {
    prev.innerHTML = `<img src="${dataUrl}" alt="Thumbnail" />`;
  } else {
    prev.innerHTML = '<span class="muted">No image</span>';
  }
}

function openPublishPage() {
  document.getElementById('dlstudio')?.classList.add('hidden');
  document.getElementById('publish-page')?.classList.remove('hidden');
  const games = studioLoadGames();
  const g = (studioGameIndex != null && games[studioGameIndex]) ? games[studioGameIndex] : {};
  document.getElementById('pub-title').value = g.title || '';
  document.getElementById('pub-desc').value = g.desc || '';
  document.getElementById('pub-server-size').value = g.serverSize || 10;
  document.getElementById('pub-category').value = g.category || 'Obby';
  const tagsEl = document.getElementById('pub-tags');
  if (tagsEl) tagsEl.value = g.tags || '';
  const visEl = document.getElementById('pub-visibility');
  if (visEl) visEl.value = g.visibility || 'public';
  pubThumbnailData = g.thumbnail || null;
  setPubThumbPreview(pubThumbnailData);
}

function initStudioUI() {
  document.getElementById('publish-back')?.addEventListener('click', () => {
    document.getElementById('publish-page')?.classList.add('hidden');
    document.getElementById('dlstudio')?.classList.remove('hidden');
  });
  document.getElementById('pub-thumb-btn')?.addEventListener('click', () => {
    document.getElementById('pub-thumb-file')?.click();
  });
  document.getElementById('pub-thumb-file')?.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('Please choose an image file'); return; }
    if (file.size > 2 * 1024 * 1024) { alert('Image must be under 2MB'); return; }
    const reader = new FileReader();
    reader.onload = () => {
      // compress to reasonable size for localStorage
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxW = 320, maxH = 200;
        let w = img.width, h = img.height;
        const r = Math.min(maxW / w, maxH / h, 1);
        w = Math.round(w * r); h = Math.round(h * r);
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        pubThumbnailData = canvas.toDataURL('image/jpeg', 0.82);
        setPubThumbPreview(pubThumbnailData);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('pub-thumb-clear')?.addEventListener('click', () => {
    pubThumbnailData = null;
    setPubThumbPreview(null);
    const f = document.getElementById('pub-thumb-file');
    if (f) f.value = '';
  });
  document.getElementById('pub-submit')?.addEventListener('click', () => {
    const title = (document.getElementById('pub-title').value || '').trim() || 'Untitled Game';
    const desc = (document.getElementById('pub-desc').value || '').trim();
    const serverSize = parseInt(document.getElementById('pub-server-size').value, 10) || 10;
    const category = document.getElementById('pub-category').value || 'Obby';
    const tags = (document.getElementById('pub-tags')?.value || '').trim();
    const visibility = document.getElementById('pub-visibility')?.value || 'public';
    const parts = studioObjects.map(o => ({
      id: o.id, name: o.name, className: o.className, shape: o.shape || o.className,
      x: o.mesh.position.x, y: o.mesh.position.y, z: o.mesh.position.z,
      sx: o.mesh.scale.x, sy: o.mesh.scale.y, sz: o.mesh.scale.z,
      ry: o.mesh.rotation.y,
      color: o.mesh.material?.color?.getHex?.() || 0x9a9a9a,
      canCollide: o.canCollide !== false,
      anchored: o.anchored !== false
    }));
    const games = studioLoadGames();
    const prev = (studioGameIndex != null && games[studioGameIndex]) ? games[studioGameIndex] : null;
    const entry = {
      title, desc, serverSize, category, tags, visibility, parts,
      thumbnail: pubThumbnailData || null,
      updated: Date.now(),
      created: (prev && prev.created) || Date.now(),
      visits: (prev && prev.visits) || 0,
      likes: (prev && prev.likes) || 0,
      events: (prev && prev.events) || [],
      privateServers: (prev && prev.privateServers) || [],
      communityIds: (prev && prev.communityIds) || []
    };
    if (studioGameIndex != null && games[studioGameIndex]) games[studioGameIndex] = entry;
    else games.push(entry);
    studioSaveGames(games);
    // also keep a copy under account for data saving
    account.studioGames = games;
    save(account);
    alert('Published: ' + title);
    document.getElementById('publish-page')?.classList.add('hidden');
    document.getElementById('dlstudio')?.classList.remove('hidden');
  });
  document.addEventListener('click', () => {
    document.getElementById('studio-file-menu')?.classList.add('hidden');
    document.getElementById('studio-insert-menu')?.classList.add('hidden');
  });
}

function setLoadProgress(pct, status, detail) {
  const bar = document.getElementById('load-prog');
  const st = document.getElementById('load-status');
  const det = document.getElementById('load-detail');
  const wrap = document.querySelector('#loading-screen .progress-bar');
  if (bar) bar.style.width = Math.max(0, Math.min(100, pct)) + '%';
  if (wrap) wrap.setAttribute('aria-valuenow', String(Math.round(pct)));
  if (st && status) st.textContent = status;
  if (det && detail != null) det.textContent = detail;
}

function showLoadRetry(msg) {
  const wrap = document.getElementById('load-retry-wrap');
  const err = document.getElementById('load-error-msg');
  if (err) err.textContent = msg || 'Something took too long. Retry or continue with a lightweight setup.';
  if (wrap) wrap.classList.remove('hidden');
}

function hideLoadRetry() {
  document.getElementById('load-retry-wrap')?.classList.add('hidden');
}

function finishBootUI() {
  setLoadProgress(100, 'Ready!', 'All set');
  try {
    characterRoot.position.set(SPAWN.x, SPAWN.y, SPAWN.z);
    updateCamera();
  } catch (_) {}
  setTimeout(() => {
    document.getElementById('loading-screen')?.classList.add('hidden');
    hideLoadRetry();
    if (!checkBrowserOnline()) showOfflineGate('No internet connection.');
    if (isLoggedIn && account.username && account.password) enterLobby();
    else {
      document.getElementById('ui-root')?.classList.add('hidden');
      showAuthScreen('auth-landing');
    }
    updateDlexUI();
  }, 200);
}

function applyLightweightFallback(reason) {
  console.warn('Lightweight fallback:', reason);
  if (!character) {
    try {
      character = createSimpleAvatar(account.avatarColor || account.chatColor || '#5b9dff');
      centerCharacterPivot(character);
      tagCharParts(character);
      characterRoot.add(character);
    } catch (fallbackError) { console.warn(fallbackError); }
  }
  if (!platforms.length) {
    try {
      const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(80, 80),
        new THREE.MeshStandardMaterial({ color: 0x6b8f70 })
      );
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);
      platforms.push({ x: 0, y: -0.05, z: 0, sx: 80, sy: 0.1, sz: 80, mesh: ground, hazard: false });
    } catch (_) {}
  }
  try { buildObby(); } catch (_) {}
}

async function boot(isRetry) {
  lockOrientation('portrait');
  applyTheme(account.settings?.theme || 'light');
  applyGraphics(account.settings?.graphics || 'medium');
  applyQol(account.settings?.qol || 100);
  applyDesktopMode(account.settings?.desktopMode);
  if (!isRetry) {
    initAuthUI();
    initDrawer();
    initStudioUI();
  }
  hideLoadRetry();
  setLoadProgress(5, 'Connecting…', 'Starting engine…');

  // Network is non-blocking – do not stall the UI on it
  try { connectNetwork(); } catch (_) {}

  let failed = false;
  let failMsg = '';

  try {
    setLoadProgress(15, 'Preparing world…', 'Loading baseplate');
    await withLoadTimeout(buildBaseplate(), 6000, 'World setup');
    setLoadProgress(40, 'Building map…', 'Obby platforms');
    try { buildObby(); } catch (e) { console.warn(e); }
    setLoadProgress(55, 'Loading avatar…', 'Character model');
    await withLoadTimeout(loadCharacter(), 6000, 'Avatar setup');
    setLoadProgress(85, 'Almost ready…', 'Finalizing');
  } catch (e) {
    failed = true;
    failMsg = (e && e.message) ? e.message : 'Asset load failed';
    console.warn('Startup issue:', e);
    applyLightweightFallback(e);
  }

  if (failed) {
    setLoadProgress(70, 'Partial load', failMsg);
    showLoadRetry(failMsg + '. You can retry or continue.');
    const retryBtn = document.getElementById('btn-load-retry');
    const contBtn = document.getElementById('btn-load-continue');
    if (retryBtn) {
      retryBtn.onclick = () => {
        hideLoadRetry();
        setLoadProgress(5, 'Retrying…', 'Reloading assets');
        boot(true);
      };
    }
    if (contBtn) {
      contBtn.onclick = () => {
        hideLoadRetry();
        finishBootUI();
      };
    }
    // Auto-continue after a short pause so the user is never stuck forever
    setTimeout(() => {
      if (!document.getElementById('loading-screen')?.classList.contains('hidden')) {
        finishBootUI();
      }
    }, 8000);
  } else {
    finishBootUI();
  }

  if (!window.__dolexLoopStarted) {
    window.__dolexLoopStarted = true;
    requestAnimationFrame(loop);
  }
}

boot(false);


/* === DOLEX STUDIO ENHANCEMENTS V2 === */
const TOOLBOX_KEY = 'dolex_toolbox_inventory_v1';
function loadToolboxInv() {
  try { return JSON.parse(localStorage.getItem(TOOLBOX_KEY) || '[]'); } catch { return []; }
}
function saveToolboxInv(list) {
  try { localStorage.setItem(TOOLBOX_KEY, JSON.stringify(list)); } catch {}
}

function studioLog(msg, cls) {
  const log = document.getElementById('studio-output-log');
  if (!log) return;
  const line = document.createElement('div');
  if (cls) line.className = cls;
  const t = new Date();
  const ts = [t.getHours(),t.getMinutes(),t.getSeconds()].map(n=>String(n).padStart(2,'0')).join(':');
  line.textContent = ts + '  ' + msg;
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}

function renderToolbox() {
  const grid = document.getElementById('toolbox-grid');
  if (!grid) return;
  const cat = document.getElementById('toolbox-cat')?.value || 'inventory';
  const q = (document.getElementById('toolbox-search')?.value || '').toLowerCase();
  const inv = loadToolboxInv();
  let items = inv.filter(x => {
    if (cat === 'models' && x.type !== 'model') return false;
    if (cat === 'decals' && x.type !== 'decal') return false;
    if (q && !(x.name||'').toLowerCase().includes(q)) return false;
    return true;
  });
  if (!items.length && cat !== 'inventory') {
    // demo placeholders
    items = [
      { id: 'demo1', name: 'Part Kit', type: 'model', icon: 'Assets/IconCube.png' },
      { id: 'demo2', name: 'Script Pack', type: 'model', icon: 'Assets/IconScriptEditor.png' },
    ].filter(x => cat === 'models' || cat === 'decals' ? x.type === (cat==='models'?'model':'decal') : true);
  }
  if (!items.length) {
    grid.innerHTML = '<p class="muted" style="grid-column:1/-1;padding:12px;font-size:0.8rem">No items. Create a Model/Decal in Create, then use Add to Toolbox.</p>';
    return;
  }
  grid.innerHTML = items.map(it => `
    <div class="toolbox-item" data-tb-id="${it.id}" title="${escapeHtml(it.name||'')}">
      ${it.dataUrl ? `<img src="${it.dataUrl}" alt=""/>` : (it.icon ? `<img src="${it.icon}" alt=""/>` : `<div class="tb-icon">📦</div>`)}
      <div>${escapeHtml((it.name||'Item').slice(0,18))}</div>
    </div>`).join('');
  grid.querySelectorAll('.toolbox-item').forEach(el => {
    el.onclick = () => {
      const it = loadToolboxInv().find(x => x.id === el.dataset.tbId) || items.find(x => x.id === el.dataset.tbId);
      if (!it) return;
      if (it.type === 'decal' && it.dataUrl && studioSelected && studioSelected.mesh) {
        try {
          const loader = new THREE.TextureLoader();
          loader.load(it.dataUrl, tex => {
            if (studioSelected.mesh.material) {
              studioSelected.mesh.material.map = tex;
              studioSelected.mesh.material.needsUpdate = true;
            }
            studioLog('Applied decal to selected part', 'info');
          });
        } catch (e) { studioLog(String(e), 'err'); }
      } else if (it.type === 'model' || it.dataUrl) {
        // Insert as Model (not Part/Object)
        insertToolboxModel(it);
      } else {
        addStudioPart('Part');
        studioLog('Inserted Part from Toolbox: ' + (it.name || 'Item'), 'info');
      }
    };
  });
}

/** Insert a toolbox model asset as className Model into the Studio scene */
function insertToolboxModel(it) {
  if (!studioScene) return;
  const url = it.dataUrl || '';
  const mime = (it.mime || '').toLowerCase();
  const name = (it.name || 'Model').toLowerCase();
  const isGltf = mime.includes('gltf') || mime.includes('glb') || name.includes('.gltf') || name.includes('.glb') || (url || '').includes('gltf') || (url || '').includes('glb');
  const isObj = mime.includes('obj') || name.includes('.obj') || (url || '').startsWith('data:text');

  const finishAsModel = (root) => {
    root.traverse(c => { if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; } });
    try {
      const box = new THREE.Box3().setFromObject(root);
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z, 0.01);
      root.scale.multiplyScalar(2 / maxDim);
      const center = box.getCenter(new THREE.Vector3());
      root.position.sub(center.multiplyScalar(2 / maxDim));
      root.position.y = (size.y * (2 / maxDim)) / 2;
    } catch (_) {
      root.position.set(0, 1, 0);
    }
    studioScene.add(root);
    const id = 'model_' + Date.now().toString(36);
    const obj = {
      id,
      name: it.name || 'Model',
      className: 'Model',
      shape: 'Model',
      mesh: root,
      canCollide: true,
      anchored: true,
      modelId: it.id,
      modelDataUrl: url,
      modelMime: mime || (isGltf ? 'model/gltf-binary' : 'model/obj')
    };
    studioObjects.push(obj);
    selectStudioObject(obj);
    renderStudioExplorer();
    studioLog('Inserted Model: ' + (it.name || id), 'info');
  };

  if (url && isGltf) {
    try {
      new GLTFLoader().load(url, (gltf) => {
        const root = gltf.scene || (gltf.scenes && gltf.scenes[0]);
        if (root) finishAsModel(root);
        else {
          const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.5, 1.5), new THREE.MeshStandardMaterial({ color: 0x6a8cff }));
          mesh.position.set(0, 0.75, 0);
          finishAsModel(mesh);
        }
      }, undefined, () => {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.5, 1.5), new THREE.MeshStandardMaterial({ color: 0x6a8cff }));
        mesh.position.set(0, 0.75, 0);
        finishAsModel(mesh);
      });
      return;
    } catch (_) {}
  }
  if (url && isObj) {
    try {
      const base64 = url.split(',')[1];
      if (base64) {
        const textObj = atob(base64);
        const objRoot = new OBJLoader().parse(textObj);
        finishAsModel(objRoot);
        return;
      }
    } catch (_) {}
  }
  // Proxy Model box when no loadable data
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(1.5, 1.5, 1.5),
    new THREE.MeshStandardMaterial({ color: 0x6a8cff, roughness: 0.5 })
  );
  mesh.position.set(0, 0.75, 0);
  finishAsModel(mesh);
}

function addCurrentAssetToToolbox() {
  const type = document.getElementById('studio-import-type')?.value || 'model';
  const id = (document.getElementById('studio-import-id')?.value || '').trim();
  // Also pull from Create storage
  let dataUrl = '', name = id || (type + '_' + Date.now().toString(36));
  try {
    if (type === 'decal') {
      const list = JSON.parse(localStorage.getItem('dolex_decals_v1') || '[]');
      const found = list.find(d => d.id === id) || list[0];
      if (found) { dataUrl = found.dataUrl; name = found.name || name; }
    } else {
      const list = JSON.parse(localStorage.getItem('dolex_models_v1') || '[]');
      const found = list.find(d => d.id === id) || list[0];
      if (found) { dataUrl = found.dataUrl || ''; name = found.name || name; }
    }
  } catch {}
  const inv = loadToolboxInv();
  const entry = { id: 'tb_' + Date.now().toString(36), name, type, dataUrl, icon: type==='decal' ? 'Assets/IconPalette.png' : 'Assets/IconCube.png', created: Date.now() };
  inv.unshift(entry);
  saveToolboxInv(inv);
  renderToolbox();
  studioLog('Added to Toolbox: ' + name, 'info');
  alert('Added to Toolbox inventory');
}

// Color palette
const BASIC_COLORS = [
  '#000000','#c0392b','#e67e22','#f1c40f','#2ecc71','#1abc9c','#3498db','#9b59b6',
  '#ffffff','#e74c3c','#e67e22','#f39c12','#27ae60','#16a085','#2980b9','#8e44ad',
  '#7f8c8d','#ff6b9d','#ffc846','#a8e6cf','#00bcd4','#5b9dff','#ce93d8','#795548',
  '#bdc3c7','#ff1744','#ff9100','#ffea00','#00e676','#00e5ff','#2979ff','#d500f9'
];
function initColorPaletteUI() {
  const box = document.getElementById('studio-basic-colors');
  if (!box || box.dataset.ready) return;
  box.dataset.ready = '1';
  box.innerHTML = BASIC_COLORS.map(h => `<button type="button" data-hex="${h}" style="background:${h}"></button>`).join('');
  box.querySelectorAll('button').forEach(b => {
    b.onclick = () => {
      const hex = b.dataset.hex;
      const pal = document.getElementById('studio-palette');
      const hx = document.getElementById('studio-color-hex');
      if (pal) pal.value = hex;
      if (hx) hx.value = hex;
      document.getElementById('studio-color-swatch').style.background = hex;
      if (typeof studioApplyPaletteColor === 'function') studioApplyPaletteColor(hex, 'selected');
    };
  });
  document.getElementById('studio-color-btn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    const pop = document.getElementById('studio-color-popup');
    if (!pop) return;
    pop.classList.toggle('hidden');
    if (!pop.classList.contains('hidden')) {
      const r = e.currentTarget.getBoundingClientRect();
      pop.style.left = r.left + 'px';
      pop.style.top = (r.bottom + 4) + 'px';
    }
  });
  document.getElementById('studio-color-apply')?.addEventListener('click', () => {
    const hex = document.getElementById('studio-color-hex')?.value || document.getElementById('studio-palette')?.value || '#9a9a9a';
    document.getElementById('studio-color-swatch').style.background = hex;
    if (typeof studioApplyPaletteColor === 'function') studioApplyPaletteColor(hex, document.getElementById('studio-color-target')?.value || 'selected');
    document.getElementById('studio-color-popup')?.classList.add('hidden');
  });
  document.getElementById('studio-palette')?.addEventListener('input', (e) => {
    document.getElementById('studio-color-hex').value = e.target.value;
    document.getElementById('studio-color-swatch').style.background = e.target.value;
  });
  document.addEventListener('pointerdown', (e) => {
    const pop = document.getElementById('studio-color-popup');
    if (pop && !pop.classList.contains('hidden') && !pop.contains(e.target) && e.target.id !== 'studio-color-btn') {
      pop.classList.add('hidden');
    }
  });
}

// Script editor
let seActiveScriptId = null;
function openScriptEditor(scriptInst) {
  const ed = document.getElementById('script-editor');
  if (!ed) return;
  ed.classList.remove('hidden');
  const code = document.getElementById('se-code');
  const name = document.getElementById('se-tab-name');
  if (scriptInst) {
    seActiveScriptId = scriptInst.id;
    if (name) name.textContent = scriptInst.name || 'Script';
    if (code) code.value = (scriptInst.props && scriptInst.props.Source) || '-- Script\nprint("Hello from DoLex Studio")\n';
  } else {
    seActiveScriptId = null;
    if (name) name.textContent = 'Script';
    if (code) code.value = code.value || '-- Script\nprint("Hello from DoLex Studio")\n';
  }
  updateSeGutter();
}
function closeScriptEditor() {
  document.getElementById('script-editor')?.classList.add('hidden');
}
function updateSeGutter() {
  const code = document.getElementById('se-code');
  const g = document.getElementById('se-gutter');
  if (!code || !g) return;
  const n = Math.max(1, code.value.split('\n').length);
  g.innerHTML = Array.from({length:n},(_,i)=>i+1).join('<br>');
}
function saveActiveScript() {
  const code = document.getElementById('se-code')?.value || '';
  if (!seActiveScriptId) {
    // create under Workspace
    if (!studioInserted['Workspace']) studioInserted['Workspace'] = [];
    const id = 'ins_' + Date.now().toString(36);
    studioInserted['Workspace'].unshift({ id, name: 'Script', className: 'Script', props: { Source: code } });
    seActiveScriptId = id;
    renderStudioExplorer();
    studioLog('Script created & saved', 'info');
    return;
  }
  for (const parent of Object.keys(studioInserted)) {
    const inst = (studioInserted[parent]||[]).find(x => x.id === seActiveScriptId);
    if (inst) {
      if (!inst.props) inst.props = {};
      inst.props.Source = code;
      studioLog('Script saved: ' + (inst.name||'Script'), 'info');
      return;
    }
  }
  studioLog('Script saved (local)', 'info');
}
function runActiveScript() {
  const code = document.getElementById('se-code')?.value || '';
  // Safe sandbox: only support print() and simple assignments shown in Output
  try {
    const print = (...args) => studioLog(args.map(String).join(' '), 'info');
    // strip Luau-ish and run limited JS eval of print lines only
    const lines = code.split('\n');
    let ran = false;
    lines.forEach(line => {
      const m = line.match(/print\s*\(\s*(.+)\s*\)/);
      if (m) {
        let arg = m[1].trim();
        if ((arg.startsWith('"') && arg.endsWith('"')) || (arg.startsWith("'") && arg.endsWith("'"))) {
          print(arg.slice(1,-1));
        } else {
          print(arg);
        }
        ran = true;
      }
    });
    if (!ran) studioLog('Script finished (no print calls). Use print("text") to log.', 'info');
  } catch (e) {
    studioLog(String(e), 'err');
  }
}

// ScreenGui / UI classes
function hasScreenGui() {
  const all = [];
  Object.keys(studioInserted||{}).forEach(k => (studioInserted[k]||[]).forEach(i => all.push(i)));
  return all.some(i => i.className === 'ScreenGui');
}
function renderStudioUIPreview() {
  const prev = document.getElementById('studio-ui-preview');
  if (!prev) return;
  if (!hasScreenGui()) {
    prev.classList.add('hidden');
    prev.innerHTML = '';
    return;
  }
  prev.classList.remove('hidden');
  const nodes = [];
  Object.keys(studioInserted||{}).forEach(k => {
    (studioInserted[k]||[]).forEach(i => {
      if (['Frame','TextLabel','TextButton','ImageButton','TextBox'].includes(i.className)) nodes.push(i);
    });
  });
  if (!nodes.length) {
    prev.innerHTML = '<div class="sui-frame" style="left:20%;top:20%;width:200px;height:80px">ScreenGui (empty)</div>';
    return;
  }
  prev.innerHTML = nodes.map((n, idx) => {
    const left = 10 + (idx % 3) * 28;
    const top = 15 + Math.floor(idx / 3) * 20;
    if (n.className === 'TextButton' || n.className === 'ImageButton') {
      return `<button class="sui-btn" style="position:absolute;left:${left}%;top:${top}%">${escapeHtml(n.name||n.className)}</button>`;
    }
    return `<div class="sui-frame" style="left:${left}%;top:${top}%;width:160px;height:48px">${escapeHtml(n.name||n.className)}</div>`;
  }).join('');
}

// Hook insert for UI classes
function studioInsertUIClass(className) {
  const parent = hasScreenGui() && className !== 'ScreenGui' ? findScreenGuiParent() : (className === 'ScreenGui' ? 'StarterGui' : 'Workspace');
  if (className !== 'ScreenGui' && !hasScreenGui() && ['Frame','TextLabel','TextButton','ImageButton','TextBox'].includes(className)) {
    alert('Add a ScreenGui under StarterGui first. UI elements stay hidden until ScreenGui exists.');
    return;
  }
  if (!studioInserted[parent]) studioInserted[parent] = [];
  const id = 'ins_' + Date.now().toString(36);
  const count = (studioInserted[parent].filter(x => x.className === className).length) + 1;
  studioInserted[parent].unshift({
    id,
    name: className + count,
    className,
    props: className === 'Script' ? { Source: '-- Script\nprint("Hello")\n' } : { Text: className }
  });
  renderStudioExplorer();
  renderStudioUIPreview();
  studioLog('Inserted ' + className + ' under ' + parent, 'info');
  if (className === 'Script') {
    openScriptEditor(studioInserted[parent][0]);
  }
}
function findScreenGuiParent() {
  for (const k of Object.keys(studioInserted||{})) {
    const g = (studioInserted[k]||[]).find(x => x.className === 'ScreenGui');
    if (g) return k; // children listed under same parent tree; use StarterGui
  }
  return 'StarterGui';
}

// Wire once when studio opens – patch openDLStudio end via global hooks
function wireStudioEnhancements() {
  if (window.__dolexStudioEnhWired) { renderToolbox(); renderStudioUIPreview(); return; }
  window.__dolexStudioEnhWired = true;
  initColorPaletteUI();
  // View panel show/hide
  document.querySelectorAll('#view-toggles input[data-panel]').forEach(cb => {
    cb.addEventListener('change', () => {
      // Prefer the desktop-mode toggle (expands viewport, no glitch)
      if (typeof toggleStudioPanel === 'function') {
        toggleStudioPanel(cb.dataset.panel, cb.checked);
        return;
      }
      const map = {
        toolbox: document.getElementById('studio-toolbox'),
        explorer: document.querySelector('.studio-explorer'),
        properties: document.querySelector('.studio-properties'),
        output: document.getElementById('studio-output')
      };
      const el = map[cb.dataset.panel];
      if (el) el.classList.toggle('hide-panel', !cb.checked);
      const side = document.getElementById('studio-side-right');
      const expEl = document.querySelector('.studio-explorer');
      const propEl = document.querySelector('.studio-properties');
      if (side && expEl && propEl) {
        side.classList.toggle('hide-panel', expEl.classList.contains('hide-panel') && propEl.classList.contains('hide-panel'));
      }
      if (typeof scheduleStudioResize === 'function') scheduleStudioResize(true);
      else {
        try {
          const wrap = document.querySelector('#dlstudio .studio-viewport-wrap');
          const w = wrap?.clientWidth || window.innerWidth;
          const h = wrap?.clientHeight || window.innerHeight;
          studioRenderer && studioRenderer.setSize(w, h, false);
        } catch (_) {}
      }
    });
  });
  renderToolbox();
  document.getElementById('toolbox-cat')?.addEventListener('change', renderToolbox);
  document.getElementById('toolbox-search')?.addEventListener('input', renderToolbox);
  document.getElementById('studio-add-toolbox')?.addEventListener('click', addCurrentAssetToToolbox);
  document.getElementById('se-close')?.addEventListener('click', closeScriptEditor);
  document.getElementById('se-save')?.addEventListener('click', saveActiveScript);
  document.getElementById('se-run')?.addEventListener('click', runActiveScript);
  document.getElementById('se-format')?.addEventListener('click', () => {
    const c = document.getElementById('se-code');
    if (!c) return;
    // simple indent normalize
    c.value = c.value.split('\n').map(l => l.replace(/\t/g,'  ')).join('\n');
    updateSeGutter();
  });
  document.getElementById('se-code')?.addEventListener('input', updateSeGutter);
  document.getElementById('studio-open-script-panel')?.addEventListener('click', () => openScriptEditor(null));
  document.getElementById('studio-script-editor')?.addEventListener('click', () => openScriptEditor(null));
  document.getElementById('studio-output-clear')?.addEventListener('click', () => {
    const log = document.getElementById('studio-output-log');
    if (log) log.innerHTML = '';
  });
  document.getElementById('studio-cmd')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      studioLog('> ' + e.target.value, 'info');
      e.target.value = '';
    }
  });

  // Override insert menu for UI/Script
  const insertMenu = document.getElementById('studio-insert-menu');
  insertMenu?.querySelectorAll('button').forEach(b => {
    const kind = b.dataset.insert;
    if (['Script','ScreenGui','Frame','TextLabel','TextButton','ImageButton'].includes(kind)) {
      b.onclick = (e) => {
        e.stopPropagation();
        insertMenu.classList.add('hidden');
        studioInsertUIClass(kind);
      };
    }
  });

  // Double-click Script in explorer opens editor – monkey-patch after render
  const _rse = window.renderStudioExplorer;
  // wrap after original exists
  setTimeout(() => {
    const tree = document.getElementById('studio-explorer-tree');
    if (!tree) return;
    tree.addEventListener('dblclick', (e) => {
      const li = e.target.closest('li[data-inserted]');
      if (!li) return;
      const parent = li.dataset.parent;
      const id = li.dataset.inserted;
      const inst = (studioInserted[parent]||[]).find(x => x.id === id);
      if (inst && inst.className === 'Script') openScriptEditor(inst);
    });
  }, 500);

  renderStudioUIPreview();
  studioLog('DLStudio ready', 'info');
}

// Call after openDLStudio
const _openDL = typeof openDLStudio === 'function' ? openDLStudio : null;
if (_openDL) {
  window.openDLStudio = function(existing, index) {
    _openDL(existing, index);
    setTimeout(wireStudioEnhancements, 100);
  };
} else {
  // openDLStudio defined later – hook via MutationObserver on #dlstudio
  const obs = new MutationObserver(() => {
    const el = document.getElementById('dlstudio');
    if (el && !el.classList.contains('hidden') && !el.dataset.enhWired) {
      el.dataset.enhWired = '1';
      wireStudioEnhancements();
    }
  });
  document.addEventListener('DOMContentLoaded', () => {
    const el = document.getElementById('dlstudio');
    if (el) obs.observe(el, { attributes: true, attributeFilter: ['class'] });
  });
  // also try immediate
  setTimeout(() => {
    const el = document.getElementById('dlstudio');
    if (el) obs.observe(el, { attributes: true, attributeFilter: ['class'] });
  }, 0);
}

// Also expose Add to Toolbox from Create development uploads
window.dolexAddToToolbox = function(entry) {
  const inv = loadToolboxInv();
  inv.unshift(Object.assign({ id: 'tb_'+Date.now().toString(36), created: Date.now() }, entry));
  saveToolboxInv(inv);
};


/* === Studio Skyboxes under Lighting === */
const STUDIO_SKYBOXES = [
  { id: 'cross', name: 'Skybox Cross', url: 'Assets/Skyboxes/Skybox_Cross.jpg' },
  { id: 'clouds', name: 'Cloudy Sky', url: 'Assets/Skyboxes/Sky_Clouds.jpg' },
];
let studioSkyMesh = null;
let studioCurrentSky = 'clouds';

function applyStudioSkybox(id) {
  if (!studioScene || typeof THREE === 'undefined') return;
  const entry = STUDIO_SKYBOXES.find(s => s.id === id) || STUDIO_SKYBOXES[1];
  studioCurrentSky = entry.id;
  const loader = new THREE.TextureLoader();
  loader.load(entry.url, (tex) => {
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.colorSpace = THREE.SRGBColorSpace || THREE.sRGBEncoding;
    // Prefer environment + background
    studioScene.background = tex;
    studioScene.environment = tex;
    // Optional large sphere fallback for older three
    if (studioSkyMesh) {
      studioScene.remove(studioSkyMesh);
      studioSkyMesh.geometry?.dispose?.();
      studioSkyMesh.material?.dispose?.();
      studioSkyMesh = null;
    }
    try {
      const geo = new THREE.SphereGeometry(400, 32, 16);
      const mat = new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, depthWrite: false });
      studioSkyMesh = new THREE.Mesh(geo, mat);
      studioSkyMesh.name = 'StudioSky';
      studioScene.add(studioSkyMesh);
    } catch (_) {}
    // Sync Lighting service props
    if (studioServiceProps && studioServiceProps.Lighting) {
      studioServiceProps.Lighting.SkyboxId = entry.id;
      studioServiceProps.Lighting.SkyboxName = entry.name;
    }
    if (typeof renderStudioProps === 'function') renderStudioProps();
    if (typeof studioLog === 'function') studioLog('Skybox: ' + entry.name, 'info');
  }, undefined, (err) => {
    console.warn('Skybox load failed', err);
    if (studioScene) studioScene.background = new THREE.Color(0x87ceeb);
  });
}

function ensureLightingSkyChildren() {
  if (!studioInserted) return;
  if (!studioInserted['Lighting']) studioInserted['Lighting'] = [];
  const list = studioInserted['Lighting'];
  // Ensure Sky instances for each skybox
  STUDIO_SKYBOXES.forEach(sb => {
    if (!list.some(x => x.className === 'Sky' && x.props && x.props.SkyboxId === sb.id)) {
      list.push({
        id: 'sky_' + sb.id,
        name: sb.name,
        className: 'Sky',
        props: { SkyboxId: sb.id, SkyboxName: sb.name, CelestialBodiesShown: true }
      });
    }
  });
}

// Hook selection of Sky in explorer to apply skybox
const _origSelectService = typeof selectStudioService === 'function' ? selectStudioService : null;

function onStudioSkySelected(inst) {
  if (inst && inst.className === 'Sky' && inst.props && inst.props.SkyboxId) {
    applyStudioSkybox(inst.props.SkyboxId);
  }
}

// Patch into wireStudioEnhancements / openDLStudio
(function patchSkyOnOpen() {
  const prev = window.openDLStudio;
  // openDLStudio is function declaration; wrap via prototype style after load
  const tryWrap = () => {
    if (typeof openDLStudio !== 'function') return;
    if (openDLStudio.__skyPatched) return;
    const orig = openDLStudio;
    window.openDLStudio = function(existing, index) {
      const r = orig.apply(this, arguments);
      setTimeout(() => {
        try {
          ensureLightingSkyChildren();
          applyStudioSkybox(studioCurrentSky || 'clouds');
          if (typeof renderStudioExplorer === 'function') renderStudioExplorer();
        } catch (e) { console.warn(e); }
      }, 200);
      return r;
    };
    window.openDLStudio.__skyPatched = true;
  };
  tryWrap();
  setTimeout(tryWrap, 500);
})();


/* === BG Music (Settings on/off) === */
const bgMusic = new Audio('Audio/Leaving_AERØHEAD_Looped.mp3');
bgMusic.loop = true;
bgMusic.preload = 'auto';
bgMusic.volume = 0.5;
function syncBgMusic() {
  try {
    const on = !!(account && account.settings && account.settings.music);
    const vol = (account && account.settings && account.settings.musicVol != null) ? account.settings.musicVol : 0.5;
    bgMusic.volume = Math.max(0, Math.min(1, vol));
    if (on) {
      bgMusic.play().catch(() => {});
    } else {
      bgMusic.pause();
    }
  } catch (_) {}
}


/* One-sided scale: opposite face stays put when scaling with a handle */
let _scalePrev = null;
function enableOneSidedScale() {
  if (!studioTransform || studioTransform.__oneside) return;
  studioTransform.__oneside = true;
  studioTransform.addEventListener('mouseDown', () => {
    if (studioTool !== 'scale' || !studioSelected || !studioSelected.mesh) return;
    const m = studioSelected.mesh;
    _scalePrev = {
      sx: m.scale.x, sy: m.scale.y, sz: m.scale.z,
      px: m.position.x, py: m.position.y, pz: m.position.z
    };
  });
  studioTransform.addEventListener('objectChange', () => {
    if (studioTool !== 'scale' || !_scalePrev || !studioSelected || !studioSelected.mesh) return;
    const m = studioSelected.mesh;
    const dsx = m.scale.x - _scalePrev.sx;
    const dsy = m.scale.y - _scalePrev.sy;
    const dsz = m.scale.z - _scalePrev.sz;
    // Shift position by half the size delta so the opposite side stays fixed
    // (scale is from center by default in Three.js)
    m.position.x = _scalePrev.px + dsx * 0.5 * Math.sign(m.scale.x);
    m.position.y = _scalePrev.py + dsy * 0.5 * Math.sign(m.scale.y);
    m.position.z = _scalePrev.pz + dsz * 0.5 * Math.sign(m.scale.z);
    _scalePrev = {
      sx: m.scale.x, sy: m.scale.y, sz: m.scale.z,
      px: m.position.x, py: m.position.y, pz: m.position.z
    };
  });
  studioTransform.addEventListener('mouseUp', () => { _scalePrev = null; });
}


/* === Joining screen + orientation flow === */
function showJoiningScreen(title, sub) {
  let ov = document.getElementById('joining-overlay');
  if (!ov) {
    ov = document.createElement('div');
    ov.id = 'joining-overlay';
    ov.className = 'joining-overlay';
    ov.innerHTML = '<div class="joining-spinner"></div><div class="joining-title" id="joining-title">Joining…</div><div class="joining-sub" id="joining-sub"></div>';
    document.body.appendChild(ov);
  }
  ov.classList.remove('hidden');
  const ti = document.getElementById('joining-title');
  const su = document.getElementById('joining-sub');
  if (ti) ti.textContent = title || 'Joining…';
  if (su) su.textContent = sub || 'Please wait';
  lockOrientation('portrait');
}
function hideJoiningScreen() {
  document.getElementById('joining-overlay')?.classList.add('hidden');
}


/* ============================================================
   DOLEX 2.1 FEATURE UPGRADE SYSTEMS
   Buy Item Frame · Hotbar · Material Panel · Game Pass support
   ============================================================ */

// ---------- BUY ITEM FRAME (Roblox-style) ----------
const BUY_ITEM_CATALOG = [
  { id: 'visor_hat', name: 'Visor', desc: 'Cool futuristic visor accessory for your avatar.', price: 75, img: 'Assets/DoLex.png', type: 'dlex', category: 'accessory' },
  { id: 'sword_tool', name: 'Classic Sword', desc: 'A sharp sword tool. Appears in your hotbar when equipped.', price: 150, img: 'Assets/Backpack.png', type: 'dlex', category: 'tool' },
  { id: 'pistol_tool', name: 'Pistol', desc: 'Lightweight pistol tool for adventure experiences.', price: 200, img: 'Assets/Backpack.png', type: 'dlex', category: 'tool' },
  { id: 'medkit_tool', name: 'Medkit', desc: 'Heal yourself during gameplay. Limited uses.', price: 50, img: 'Assets/Backpack.png', type: 'dlex', category: 'tool' },
  { id: 'gp_vip', name: 'VIP Game Pass', desc: 'Unlock exclusive VIP areas, chat tag, and special effects.', price: 400, img: 'Assets/Dlex_Coin_Gold.png', type: 'gamepass', category: 'pass' },
  { id: 'gp_double_dlex', name: 'Double Dlex Pass', desc: 'Earn 2× Dlex from all in-game rewards while owned.', price: 250, img: 'Assets/Dlex_Coin_Gold.png', type: 'gamepass', category: 'pass' },
];

let _pendingBuyItem = null;

function openBuyItemFrame(itemOrId) {
  const item = typeof itemOrId === 'string'
    ? BUY_ITEM_CATALOG.find(i => i.id === itemOrId) || { id: itemOrId, name: itemOrId, desc: '', price: 0, img: 'Assets/DoLex.png', type: 'dlex' }
    : itemOrId;
  _pendingBuyItem = item;

  const overlay = document.getElementById('buy-item-overlay');
  if (!overlay) return;

  document.getElementById('buy-item-img').src = item.img || 'Assets/DoLex.png';
  document.getElementById('buy-item-title').textContent = item.name || 'Item';
  document.getElementById('buy-item-desc').textContent = item.desc || '';
  document.getElementById('buy-item-price').textContent = (item.price || 0).toLocaleString();
  document.getElementById('buy-item-currency-label').textContent = item.type === 'gamepass' ? 'Dlex (Game Pass)' : 'Dlex';

  const inv = account.inventory || [];
  const owned = inv.includes(item.id) || (account.ownedPasses || []).includes(item.id);
  const ownedEl = document.getElementById('buy-item-owned');
  const errEl = document.getElementById('buy-item-error');
  const confirmBtn = document.getElementById('buy-item-confirm');

  ownedEl.classList.toggle('hidden', !owned);
  errEl.classList.add('hidden');
  errEl.textContent = '';
  confirmBtn.disabled = owned;
  confirmBtn.textContent = owned ? 'Owned' : 'Get';
  confirmBtn.style.opacity = owned ? '0.55' : '1';

  overlay.classList.remove('hidden');
  overlay.setAttribute('aria-hidden', 'false');
}

function closeBuyItemFrame() {
  const overlay = document.getElementById('buy-item-overlay');
  if (overlay) {
    overlay.classList.add('hidden');
    overlay.setAttribute('aria-hidden', 'true');
  }
  _pendingBuyItem = null;
}

function confirmBuyItem() {
  if (!_pendingBuyItem) return;
  const item = _pendingBuyItem;
  const inv = account.inventory || [];
  const ownedPasses = account.ownedPasses || [];

  if (inv.includes(item.id) || ownedPasses.includes(item.id)) {
    const err = document.getElementById('buy-item-error');
    err.textContent = 'You already own this item.';
    err.classList.remove('hidden');
    return;
  }

  const bal = account.dlex || 0;
  if (bal < (item.price || 0)) {
    const err = document.getElementById('buy-item-error');
    err.textContent = `Insufficient Dlex. You need ${(item.price || 0).toLocaleString()} Dlex.`;
    err.classList.remove('hidden');
    return;
  }

  // Deduct
  account.dlex = bal - (item.price || 0);
  if (item.type === 'gamepass') {
    account.ownedPasses = ownedPasses;
    if (!account.ownedPasses.includes(item.id)) account.ownedPasses.push(item.id);
  } else {
    account.inventory = inv;
    if (!account.inventory.includes(item.id)) account.inventory.push(item.id);
    // Auto-add tools to hotbar
    if (item.category === 'tool') {
      addToolToHotbar({ id: item.id, name: item.name, icon: item.img });
    }
  }

  if (typeof save === 'function') save(account);
  if (typeof updateDlexUI === 'function') updateDlexUI();
  else document.querySelectorAll('.dlex-val').forEach(el => { el.textContent = account.dlex; });

  closeBuyItemFrame();
  alert(`Successfully purchased "${item.name}"!\n${item.price} Dlex deducted.\n${item.category === 'tool' ? 'Tool added to your hotbar.' : 'Item added to inventory.'}`);
}

// Wire Buy Item UI once DOM ready
function initBuyItemFrame() {
  document.getElementById('buy-item-close')?.addEventListener('click', closeBuyItemFrame);
  document.getElementById('buy-item-cancel')?.addEventListener('click', closeBuyItemFrame);
  document.getElementById('buy-item-confirm')?.addEventListener('click', confirmBuyItem);
  document.getElementById('buy-item-overlay')?.addEventListener('click', (e) => {
    if (e.target.id === 'buy-item-overlay') closeBuyItemFrame();
  });
  // Expose globally so marketplace cards can call it
  window.openBuyItemFrame = openBuyItemFrame;
  window.BUY_ITEM_CATALOG = BUY_ITEM_CATALOG;
}

// ---------- HOTBAR SYSTEM ----------
const hotbarState = {
  slots: Array(9).fill(null), // { id, name, icon }
  active: -1,
};

function addToolToHotbar(tool) {
  // Find first empty slot or replace if already present
  let idx = hotbarState.slots.findIndex(s => s && s.id === tool.id);
  if (idx === -1) {
    idx = hotbarState.slots.findIndex(s => !s);
    if (idx === -1) idx = 0; // overwrite first if full
  }
  hotbarState.slots[idx] = { id: tool.id, name: tool.name || tool.id, icon: tool.icon || 'Assets/Backpack.png' };
  renderHotbar();
  showHotbar();
}

function renderHotbar() {
  const container = document.getElementById('hotbar-slots');
  if (!container) return;
  container.innerHTML = hotbarState.slots.map((slot, i) => {
    if (!slot) {
      return `<div class="hotbar-slot empty" data-slot="${i}"><span class="slot-num">${i + 1}</span></div>`;
    }
    const active = hotbarState.active === i ? 'active' : '';
    return `<div class="hotbar-slot ${active}" data-slot="${i}" title="${slot.name}">
      <span class="slot-num">${i + 1}</span>
      <img class="slot-icon" src="${slot.icon}" alt="" onerror="this.style.display='none'"/>
      <span class="slot-name">${slot.name}</span>
    </div>`;
  }).join('');

  container.querySelectorAll('.hotbar-slot').forEach(el => {
    el.onclick = () => {
      const i = +el.dataset.slot;
      if (!hotbarState.slots[i]) return;
      if (hotbarState.active === i) {
        hotbarState.active = -1; // unequip
      } else {
        hotbarState.active = i;
      }
      renderHotbar();
    };
  });
}

function showHotbar() {
  const hb = document.getElementById('hotbar');
  if (hb) hb.classList.remove('hidden');
}

function hideHotbar() {
  const hb = document.getElementById('hotbar');
  if (hb) hb.classList.add('hidden');
}

function initHotbar() {
  renderHotbar();
  // Keyboard 1-9
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    const num = parseInt(e.key, 10);
    if (num >= 1 && num <= 9) {
      const i = num - 1;
      if (hotbarState.slots[i]) {
        hotbarState.active = hotbarState.active === i ? -1 : i;
        renderHotbar();
        showHotbar();
      }
    }
  });
  // Demo: seed a couple tools if inventory already has them
  const inv = account?.inventory || [];
  BUY_ITEM_CATALOG.filter(i => i.category === 'tool' && inv.includes(i.id)).forEach(t => {
    addToolToHotbar({ id: t.id, name: t.name, icon: t.img });
  });
  window.addToolToHotbar = addToolToHotbar;
  window.showHotbar = showHotbar;
}

// ---------- MATERIAL PANEL (draggable + apply textures) ----------
let _matDragging = false;
let _matOffsetX = 0, _matOffsetY = 0;

function openMaterialPanel() {
  const panel = document.getElementById('material-panel');
  if (panel) panel.classList.remove('hidden');
}

function closeMaterialPanel() {
  const panel = document.getElementById('material-panel');
  if (panel) panel.classList.add('hidden');
}

function applyMaterialToSelected(matName) {
  // Try to find currently selected object in Studio
  const selected = window.studioSelected || window.selectedObject || null;
  if (!selected) {
    alert('Select a Part in the Explorer or viewport first, then apply a material.');
    return;
  }
  const mesh = selected.isMesh ? selected : (selected.children?.find(c => c.isMesh) || selected);
  if (!mesh || !mesh.material) {
    alert('Selected object has no material to update.');
    return;
  }

  const texLoader = window.THREE ? new THREE.TextureLoader() : null;
  const mat = mesh.material;

  if (matName === 'brick' && texLoader) {
    texLoader.load('Assets/Brick.jpg', (tex) => {
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(2, 2);
      mat.map = tex;
      mat.needsUpdate = true;
    });
  } else if (matName === 'pebble' && texLoader) {
    texLoader.load('Assets/Pebble.jpg', (tex) => {
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(2, 2);
      mat.map = tex;
      mat.needsUpdate = true;
    });
  } else if (matName === 'glass') {
    mat.transparent = true;
    mat.opacity = 0.45;
    mat.color?.set?.('#aaddff');
    mat.needsUpdate = true;
  } else if (matName === 'neon') {
    mat.emissive?.set?.('#ff00aa');
    mat.emissiveIntensity = 1.2;
    mat.color?.set?.('#ff00aa');
    mat.needsUpdate = true;
  } else if (matName === 'metal') {
    mat.metalness = 0.85;
    mat.roughness = 0.25;
    mat.color?.set?.('#aaaaaa');
    mat.needsUpdate = true;
  } else if (matName === 'wood') {
    mat.color?.set?.('#8B5A2B');
    mat.map = null;
    mat.needsUpdate = true;
  } else if (matName === 'concrete') {
    mat.color?.set?.('#888888');
    mat.map = null;
    mat.needsUpdate = true;
  } else { // plastic default
    mat.map = null;
    mat.transparent = false;
    mat.opacity = 1;
    mat.emissive?.set?.('#000000');
    mat.metalness = 0;
    mat.roughness = 0.6;
    mat.color?.set?.('#c8c8c8');
    mat.needsUpdate = true;
  }

  // Visual feedback
  document.querySelectorAll('.material-swatch').forEach(s => s.classList.remove('active'));
  document.querySelector(`.material-swatch[data-mat="${matName}"]`)?.classList.add('active');
}

function removeMaterialFromSelected() {
  applyMaterialToSelected('plastic');
}

function initMaterialPanel() {
  const panel = document.getElementById('material-panel');
  const header = document.getElementById('material-panel-drag');
  if (!panel || !header) return;

  document.getElementById('material-panel-close')?.addEventListener('click', closeMaterialPanel);
  document.getElementById('material-remove')?.addEventListener('click', removeMaterialFromSelected);

  document.querySelectorAll('.material-swatch').forEach(btn => {
    btn.addEventListener('click', () => applyMaterialToSelected(btn.dataset.mat));
  });

  // Drag logic
  header.addEventListener('pointerdown', (e) => {
    _matDragging = true;
    const rect = panel.getBoundingClientRect();
    _matOffsetX = e.clientX - rect.left;
    _matOffsetY = e.clientY - rect.top;
    header.setPointerCapture?.(e.pointerId);
  });
  window.addEventListener('pointermove', (e) => {
    if (!_matDragging) return;
    panel.style.left = (e.clientX - _matOffsetX) + 'px';
    panel.style.top = (e.clientY - _matOffsetY) + 'px';
    panel.style.right = 'auto';
  });
  window.addEventListener('pointerup', () => { _matDragging = false; });

  // Expose open function (can be bound to a Studio toolbar button)
  window.openMaterialPanel = openMaterialPanel;
  window.closeMaterialPanel = closeMaterialPanel;
}

// ---------- INIT ALL NEW SYSTEMS ----------
function initDoLex21Upgrades() {
  initBuyItemFrame();
  initHotbar();
  initMaterialPanel();

  // Hook marketplace cards if they exist later
  document.addEventListener('click', (e) => {
    const card = e.target.closest('[data-mp-id], [data-buy-id]');
    if (!card) return;
    const id = card.dataset.mpId || card.dataset.buyId;
    const item = BUY_ITEM_CATALOG.find(i => i.id === id);
    if (item) {
      e.preventDefault();
      e.stopPropagation();
      openBuyItemFrame(item);
    }
  });

  // Add a Material button to Studio toolbar if present
  const toolbar = document.getElementById('studio-transform-tools') || document.getElementById('studio-toolbar');
  if (toolbar && !document.getElementById('studio-material-btn')) {
    const btn = document.createElement('button');
    btn.id = 'studio-material-btn';
    btn.className = 'studio-tool';
    btn.title = 'Material Panel';
    btn.innerHTML = '🎨 Material';
    btn.addEventListener('click', () => {
      const p = document.getElementById('material-panel');
      if (p?.classList.contains('hidden')) openMaterialPanel();
      else closeMaterialPanel();
    });
    toolbar.appendChild(btn);
  }

  console.log('[DoLex 2.1] Buy Item Frame, Hotbar, Material Panel initialized');
}

// Run after a short delay so DOM + account are ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(initDoLex21Upgrades, 400));
} else {
  setTimeout(initDoLex21Upgrades, 400);
}

/* ============================================================
   STUDIO DESKTOP MODE (Landscape = Computer Layout)
   Applies Roblox Studio desktop layout on landscape screens
   ============================================================ */

function isLandscape() {
  try {
    if (window.matchMedia) {
      return window.matchMedia('(orientation: landscape)').matches
        || window.innerWidth > window.innerHeight;
    }
  } catch (_) {}
  return window.innerWidth > window.innerHeight;
}

let _studioResizeTimer = null;
let _studioLastW = 0;
let _studioLastH = 0;

/** Resize Studio Three.js canvas to the current viewport wrap size (no glitch). */
function resizeStudioViewport(force) {
  try {
    const wrap = document.querySelector('#dlstudio .studio-viewport-wrap');
    const canvas = document.getElementById('studio-canvas');
    if (!wrap || !canvas) return;
    const w = Math.max(1, Math.floor(wrap.clientWidth));
    const h = Math.max(1, Math.floor(wrap.clientHeight));
    if (!force && w === _studioLastW && h === _studioLastH) return;
    _studioLastW = w;
    _studioLastH = h;
    if (typeof studioRenderer !== 'undefined' && studioRenderer) {
      studioRenderer.setSize(w, h, false);
      canvas.style.width = '100%';
      canvas.style.height = '100%';
    }
    if (typeof studioCam !== 'undefined' && studioCam) {
      studioCam.aspect = w / h;
      studioCam.updateProjectionMatrix();
    }
  } catch (_) {}
}

/** Debounced resize — waits for flex layout to settle after panel toggles. */
function scheduleStudioResize(force) {
  if (_studioResizeTimer) clearTimeout(_studioResizeTimer);
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      _studioResizeTimer = setTimeout(() => resizeStudioViewport(!!force), 40);
    });
  });
}

/** Sync body classes for which panels are hidden so CSS expands the viewport. */
function syncPanelHiddenClasses() {
  const tb = document.getElementById('studio-toolbox');
  const side = document.getElementById('studio-side-right');
  const exp = document.querySelector('#dlstudio .studio-explorer');
  const prop = document.querySelector('#dlstudio .studio-properties');
  const out = document.getElementById('studio-output');

  const leftHidden = !tb || tb.classList.contains('hide-panel') || tb.style.display === 'none';
  const expHidden = !exp || exp.classList.contains('hide-panel');
  const propHidden = !prop || prop.classList.contains('hide-panel');
  const rightHidden = !side || side.classList.contains('hide-panel') || (expHidden && propHidden);
  const outHidden = !out || out.classList.contains('hide-panel') || out.style.display === 'none';

  if (side) side.classList.toggle('hide-panel', rightHidden);

  document.body.classList.toggle('panels-left-hidden', leftHidden);
  document.body.classList.toggle('panels-right-hidden', rightHidden);
  document.body.classList.toggle('panels-output-hidden', outHidden);
}

function applyStudioDesktopMode() {
  const studio = document.getElementById('dlstudio');
  if (!studio || studio.classList.contains('hidden')) {
    document.body.classList.remove('studio-desktop-mode', 'studio-open', 'panels-left-hidden', 'panels-right-hidden', 'panels-output-hidden');
    return;
  }
  document.body.classList.add('studio-open');
  if (isLandscape()) {
    document.body.classList.add('studio-desktop-mode');
  } else {
    document.body.classList.remove('studio-desktop-mode');
  }
  syncPanelHiddenClasses();
  scheduleStudioResize(true);
}

function toggleStudioPanel(panelKey, show) {
  const map = {
    toolbox: document.getElementById('studio-toolbox'),
    explorer: document.querySelector('#dlstudio .studio-explorer'),
    properties: document.querySelector('#dlstudio .studio-properties'),
    output: document.getElementById('studio-output')
  };
  const el = map[panelKey];
  if (!el) return;
  if (typeof show === 'boolean') {
    el.classList.toggle('hide-panel', !show);
  } else {
    el.classList.toggle('hide-panel');
  }
  const cb = document.querySelector(`#view-toggles input[data-panel="${panelKey}"]`);
  if (cb) cb.checked = !el.classList.contains('hide-panel');
  syncPanelHiddenClasses();
  scheduleStudioResize(true);
}

function initStudioDesktopMode() {
  if (window.__dolexDesktopModeInit) return;
  window.__dolexDesktopModeInit = true;

  applyStudioDesktopMode();

  let resizeDebounce = null;
  const onWinResize = () => {
    if (resizeDebounce) clearTimeout(resizeDebounce);
    resizeDebounce = setTimeout(() => applyStudioDesktopMode(), 80);
  };
  window.addEventListener('resize', onWinResize, { passive: true });
  window.addEventListener('orientationchange', () => {
    setTimeout(applyStudioDesktopMode, 200);
  });

  const el = document.getElementById('dlstudio');
  if (el && typeof MutationObserver !== 'undefined') {
    const mo = new MutationObserver(() => applyStudioDesktopMode());
    mo.observe(el, { attributes: true, attributeFilter: ['class'] });
  }

  document.querySelectorAll('#view-toggles input[data-panel]').forEach(cb => {
    cb.addEventListener('change', () => {
      toggleStudioPanel(cb.dataset.panel, cb.checked);
    });
  });

  document.getElementById('studio-toolbox-toggle')?.addEventListener('click', () => {
    toggleStudioPanel('toolbox');
  });

  document.getElementById('studio-material-btn')?.addEventListener('click', () => {
    if (typeof openMaterialPanel === 'function') {
      const p = document.getElementById('material-panel');
      if (p?.classList.contains('hidden')) openMaterialPanel();
      else if (typeof closeMaterialPanel === 'function') closeMaterialPanel();
      else openMaterialPanel();
    }
  });

  document.querySelectorAll('[data-insert-quick]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.insertQuick;
      const menuBtn = document.querySelector(`#studio-insert-menu [data-insert="${type}"]`);
      if (menuBtn) menuBtn.click();
      else if (typeof window.insertStudioObject === 'function') window.insertStudioObject(type);
    });
  });

  document.getElementById('studio-ui-btn')?.addEventListener('click', () => {
    document.querySelector('.studio-tab[data-studio-tab="ui"]')?.click();
  });

  document.getElementById('studio-game-settings')?.addEventListener('click', () => {
    alert('Game Settings\n\nConfigure place settings, max players, and thumbnails from Publish.');
  });

  try {
    const wrap = document.querySelector('#dlstudio .studio-viewport-wrap');
    if (wrap && typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => scheduleStudioResize(false));
      ro.observe(wrap);
    }
  } catch (_) {}

  window.toggleStudioPanel = toggleStudioPanel;
  window.resizeStudioViewport = resizeStudioViewport;
  console.log('[DoLex Studio] Desktop Mode v2 ready — viewport scales when panels close');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(initStudioDesktopMode, 600));
} else {
  setTimeout(initStudioDesktopMode, 600);
}
