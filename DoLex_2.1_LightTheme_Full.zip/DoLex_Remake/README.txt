# DoLex 2.1 – Roblox-Style Studio & Platform

## Highlights
- **Reliable loading** – essential assets first, accurate progress, timeouts, retry / continue recovery (no endless freeze).
- **3D profile viewport** – circular WebGL character view of the user’s model (GLTF/OBJ or simple fallback), slow idle spin, safe dispose on navigate.
- **Dlex currency** – gold “D” coin icon; demo packs only (no real payments).
- **Marketplace / Wallet / Studio** – catalog, demo purchases, compact Studio topbar, Explorer, Properties, Toolbox.
- **UI polish** – solid panel backgrounds, consistent rounded corners, pure-white hamburger (no extra plate), smooth hover/transitions.
- **Icons** – Studio_Smooth_Icons refreshed from the provided Icons pack (same-name files replaced).
- **Orientation** – portrait for Home / pages; landscape preferred for Studio & gameplay.
- Background music + ON/OFF setting preserved.

## Run
```bash
cd DoLex_Remake
python -m http.server 8080
# open http://localhost:8080
```
Do **not** use `file://`.

## Demo currency notice
All Dlex pack purchases are **local demo credits only**. No real money is charged and no payment provider is integrated.

## Credits
DoLex · Studio Smooth Icons · Three.js · AERØHEAD looped BGM
